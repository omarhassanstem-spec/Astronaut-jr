/* ============================================================
   AUTH — local cadet accounts (saved on this device)
   Each account gets its own save slot, so several cadets can
   share one device without mixing up their progress.
   ============================================================ */
(function(){
"use strict";
var USERS_KEY="astrocadet.auth.users", SESSION_KEY="astrocadet.auth.session", GUEST="__guest__";
var BASE_SAVE="astrocadet.v3.save";
var ADMIN_EMAIL="astronautjr.space@gmail.com";

function get(store,k){try{return store.getItem(k)}catch(e){return null}}
function set(store,k,v){try{store.setItem(k,v);return true}catch(e){return false}}
function del(store,k){try{store.removeItem(k)}catch(e){}}
function storageOK(){try{var k="__astro_t";localStorage.setItem(k,"1");localStorage.removeItem(k);return true}catch(e){return false}}
function readUsers(){try{var u=JSON.parse(get(localStorage,USERS_KEY)||"{}");return u&&typeof u==="object"?u:{}}catch(e){return {}}}
function writeUsers(u){return set(localStorage,USERS_KEY,JSON.stringify(u))}

function getSession(){
  var raw=get(localStorage,SESSION_KEY)||get(sessionStorage,SESSION_KEY);
  if(!raw)return null;
  try{
    var s=JSON.parse(raw);
    if(!s||!s.user)return null;
    if(s.user===GUEST)return s;
    return readUsers()[s.user]?s:null;
  }catch(e){return null}
}
function setSession(user,remember){
  del(localStorage,SESSION_KEY);del(sessionStorage,SESSION_KEY);
  var val=JSON.stringify({user:user,remember:!!remember});
  set(remember?localStorage:sessionStorage,SESSION_KEY,val);
}
function clearSession(){del(localStorage,SESSION_KEY);del(sessionStorage,SESSION_KEY)}

/* ---- password hashing (PBKDF2 where available) ---- */
function hex(buf){return Array.prototype.map.call(new Uint8Array(buf),function(b){return("0"+b.toString(16)).slice(-2)}).join("")}
function randomSalt(){
  var a=new Uint8Array(16);
  if(window.crypto&&crypto.getRandomValues)crypto.getRandomValues(a);else for(var i=0;i<16;i++)a[i]=Math.floor(Math.random()*256);
  return hex(a.buffer);
}
function hashPw(pw,salt){
  if(window.crypto&&crypto.subtle&&window.TextEncoder){
    var enc=new TextEncoder();
    return crypto.subtle.importKey("raw",enc.encode(pw),"PBKDF2",false,["deriveBits"]).then(function(key){
      return crypto.subtle.deriveBits({name:"PBKDF2",salt:enc.encode(salt),iterations:100000,hash:"SHA-256"},key,256);
    }).then(function(bits){return "p1:"+hex(bits)});
  }
  var s=salt+"|"+pw,h=5381;
  for(var r=0;r<2000;r++)for(var i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;
  return Promise.resolve("f1:"+(h>>>0).toString(16));
}

/* ---- public pieces the app needs BEFORE it boots ---- */
var Auth={
  saveKey:function(){
    var s=getSession();
    return(s&&s.user!==GUEST)?BASE_SAVE+".u."+s.user:BASE_SAVE;
  },
  currentEmail:function(){
    var s=getSession();
    if(!s||s.user===GUEST)return "";
    var u=readUsers()[s.user];
    return u&&u.email?u.email:"";
  },
  ready:function(){return !storageOK()||!!getSession()},
  show:function(){
    var el=document.getElementById("authScreen");
    el.classList.add("is-open");document.body.classList.add("is-locked");
    stars();
    setTimeout(function(){var u=document.getElementById("authUser");if(u)u.focus({preventScroll:true})},120);
  },
  afterInit:function(){
    var s=getSession(),who=document.getElementById("authWho"),out=document.getElementById("btnSignOut");
    var user=s&&s.user!==GUEST?readUsers()[s.user]:null;
    if(who)who.textContent=user?user.display+(isAdmin(user)?" · Admin":""):"Guest (this device)";
    if(out)out.textContent=user?"Sign out":"Sign in";
    mountTabs(user);
    var name=document.getElementById("cadetName");
    if(user&&name&&!name.value&&document.getElementById("setupModal").classList.contains("is-open"))name.value=user.display.slice(0,18);
  }
};
window.AstroAuth=Auth;

/* ---- screen logic ---- */
var mode="signin",busy=false,fails=0,lockUntil=0;
var $=function(s){return document.querySelector(s)};

function setMode(m){
  mode=m;var up=m==="signup";
  $("#tabSignin").setAttribute("aria-selected",String(!up));
  $("#tabSignup").setAttribute("aria-selected",String(up));
  $("#authTitle").textContent=up?"Join the Academy!":"Welcome back, cadet!";
  $("#authLead").textContent=up?"Create your cadet ID to save your stars, outfits and missions.":"Sign in to pick up your training where you left off.";
  $("#authConfirmWrap").hidden=!up;
  $("#authEmailWrap").hidden=!up;
  $("#authUserLabel").textContent=up?"Cadet username":"Username or email";
  $("#authUser").placeholder=up?"e.g. nova_42":"Username or email";
  $("#authMeter").hidden=!up;
  $("#authPass").autocomplete=up?"new-password":"current-password";
  $("#authSubmit").textContent=up?"Create my account ✨":"Sign in 🚀";
  $("#authRemember").checked=true;
  $("#authError").textContent="";
  if(up)meter($("#authPass").value);
}
function meter(v){
  var sc=0;
  if(v.length>=6)sc++;
  if(v.length>=10)sc++;
  if(/[a-z]/.test(v)&&/[A-Z]/.test(v)||/\d/.test(v)&&/[a-z]/i.test(v))sc++;
  if(/[^A-Za-z0-9]/.test(v)&&v.length>=8)sc++;
  if(!v)sc=0;
  $("#authMeter").setAttribute("data-s",String(sc));
  $("#authMeterText").textContent=!v?"":["Too short","Okay","Good","Strong","Stellar!"][Math.min(sc,4)]||"";
}
function fail(msg,focusId){
  $("#authError").textContent=msg;
  var c=$("#authCard");c.classList.remove("shake");void c.offsetWidth;c.classList.add("shake");
  if(focusId)$("#"+focusId).focus();
}
function go(user,remember){setSession(user,remember);setTimeout(function(){location.reload()},NOTIFY_URL?400:0)}

function submit(e){
  e.preventDefault();
  if(busy)return;
  var err=$("#authError");err.textContent="";
  var raw=$("#authUser").value.trim(),key=raw.toLowerCase(),pw=$("#authPass").value;
  if(!storageOK()){fail("This browser is blocking saving, so accounts can’t be used here.");return}
  if(mode==="signin"&&key.indexOf("@")>-1){
    var u0=readUsers(),found=null;
    Object.keys(u0).forEach(function(k){if(u0[k].email&&u0[k].email===key)found=k});
    key=found||"__none__";
  }else if(!/^[a-z0-9_-]{3,16}$/.test(key)){fail("Usernames use 3–16 letters, numbers, _ or -.","authUser");return}
  if(!pw){fail("Type your secret code.","authPass");return}
  var users=readUsers();
  busy=true;$("#authSubmit").disabled=true;

  if(mode==="signup"){
    if(users[key]){busy=false;$("#authSubmit").disabled=false;fail("That username is taken. Try another one!","authUser");return}
    var email=($("#authEmail").value||"").trim().toLowerCase();
    if(!email){busy=false;$("#authSubmit").disabled=false;fail("Email is required to create an account.","authEmail");return}
    if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){busy=false;$("#authSubmit").disabled=false;fail("That email doesn’t look right.","authEmail");return}
    if(email&&Object.keys(users).some(function(k){return users[k].email===email})){busy=false;$("#authSubmit").disabled=false;fail("That email is already used by another account.","authEmail");return}
    if(pw.length<6){busy=false;$("#authSubmit").disabled=false;fail("Secret codes need at least 6 characters.","authPass");return}
    if(pw!==$("#authPass2").value){busy=false;$("#authSubmit").disabled=false;fail("The two secret codes don’t match.","authPass2");return}
    var salt=randomSalt();
    hashPw(pw,salt).then(function(h){
      users[key]={display:raw,email:email,role:email===ADMIN_EMAIL?"admin":"player",salt:salt,hash:h,created:Date.now()};
      if(!writeUsers(users))throw new Error("save");
      logEvent("signup",key,email);
      go(key,$("#authRemember").checked);
    }).catch(function(){busy=false;$("#authSubmit").disabled=false;fail("Couldn’t create the account. Please try again.")});
    return;
  }

  /* sign in */
  var now=Date.now();
  if(now<lockUntil){busy=false;$("#authSubmit").disabled=false;fail("Too many tries. Wait "+Math.ceil((lockUntil-now)/1000)+"s and try again.");return}
  var u=users[key];
  var check=u?hashPw(pw,u.salt).then(function(h){return h===u.hash}):hashPw(pw,"x").then(function(){return false});
  check.then(function(ok){
    if(ok){logEvent("signin",key);go(key,$("#authRemember").checked);return}
    if(u)logEvent("signin_failed",key);fails++;busy=false;$("#authSubmit").disabled=false;
    if(fails>=5){lockUntil=Date.now()+15000;fails=0;fail("Too many tries. Wait 15s and try again.")}
    else fail(u?"Wrong username or secret code.":"No account with that name on this device yet. Tap “Create account” to make one.","authUser");
  }).catch(function(){busy=false;$("#authSubmit").disabled=false;fail("Something went wrong. Please try again.")});
}

/* ---- activity log + admin alerts ---- */
var LOG_KEY="astrocadet.auth.log",SEEN_KEY="astrocadet.auth.logSeen";
/* Optional email alerts: set window.ASTROCADET_NOTIFY_ENDPOINT to a form/webhook URL
   (Formspree, Web3Forms, your own server...) that forwards to the admin's inbox. */
var NOTIFY_URL=window.ASTROCADET_NOTIFY_ENDPOINT||"";
var LABELS={signup:"✨ New account",signin:"🔑 Signed in",signin_failed:"⚠️ Wrong code tried",guest:"🧑‍🚀 Guest started"};
function readLog(){try{var l=JSON.parse(get(localStorage,LOG_KEY)||"[]");return Array.isArray(l)?l:[]}catch(e){return []}}
function logEvent(type,user,extra){
  var t=Date.now();
  var l=readLog();l.push({t:t,type:type,user:user||"",extra:extra||""});
  set(localStorage,LOG_KEY,JSON.stringify(l.slice(-200)));
  if(NOTIFY_URL&&window.fetch&&type!=="guest"){
    try{fetch(NOTIFY_URL,{method:"POST",keepalive:true,headers:{"Content-Type":"application/json",Accept:"application/json"},
      body:JSON.stringify({subject:"Astronaut Jr: "+(LABELS[type]||type),event:type,username:user||"",email:extra||"",time:new Date(t).toISOString(),admin:ADMIN_EMAIL})}).catch(function(){})}catch(e){}
  }
}
function unseenCount(){var s=+get(localStorage,SEEN_KEY)||0;return readLog().filter(function(e){return e.t>s}).length}
function markSeen(){set(localStorage,SEEN_KEY,String(Date.now()));badge()}
var adminTabBtn=null;
function badge(){if(adminTabBtn){var n=unseenCount();adminTabBtn.textContent="🛡️ Admin"+(n?" ("+n+")":"")}}
function adminAlert(){
  var n=unseenCount();if(!n)return;
  var last=readLog().slice(-1)[0],msg="🔔 "+n+" new event"+(n===1?"":"s")+(last?" · "+(LABELS[last.type]||last.type)+(last.user?" @"+last.user:""):"");
  try{AstroCadet.UI.toast(msg,"mint")}catch(e){}
  try{if(window.Notification&&Notification.permission==="granted")new Notification("Astronaut Jr",{body:msg})}catch(e){}
  badge();
}
window.addEventListener("storage",function(e){if(e.key===LOG_KEY&&adminNow())adminAlert()});

/* ---- leaderboard + admin ---- */
function isAdmin(u){return !!u&&u.role==="admin"&&u.email===ADMIN_EMAIL}
function currentUser(){var s=getSession();return s&&s.user!==GUEST?s.user:null}
function esc(v){return String(v).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function readSave(key){try{return JSON.parse(get(localStorage,BASE_SAVE+".u."+key)||"null")||{}}catch(e){return {}}}
function localEntries(withHidden){
  var users=readUsers();
  return Object.keys(users).map(function(k){
    var u=users[k],s=readSave(k);
    return{id:k,name:String(s.name||u.display||k).slice(0,18),stars:+s.earnedTotal||0,missions:(s.completed||[]).length,
      trophies:(s.achievements||[]).length,hidden:!!u.hidden,created:u.created||0};
  }).filter(function(e){return withHidden||!e.hidden});
}
function sortEntries(list,metric){
  return list.slice().sort(function(a,b){
    var d=metric==="missions"?(b.missions-a.missions)||(b.stars-a.stars):(b.stars-a.stars)||(b.missions-a.missions);
    return d||(a.created-b.created)||a.name.localeCompare(b.name);
  });
}
/* Optional online board: set window.ASTROCADET_LB_ENDPOINT to your own server.
   POST {id,name,stars,missions,trophies}  ·  GET -> {players:[...same fields]} */
function remoteBoard(me){
  var url=window.ASTROCADET_LB_ENDPOINT;
  if(!url||!window.fetch)return Promise.resolve(null);
  var post=me?fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(me)}).catch(function(){}):Promise.resolve();
  return post.then(function(){return fetch(url)}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(d){
    return(d.players||[]).slice(0,100).map(function(x){
      return{id:String(x.id||""),name:String(x.name||"Cadet").slice(0,18),stars:+x.stars||0,missions:+x.missions||0,trophies:+x.trophies||0,created:0};
    });
  }).catch(function(){return null});
}

var lbMetric="stars";
function renderLB(){
  var el=document.getElementById("extra-leaderboard");if(!el)return;
  var me=currentUser(),all=localEntries(true),mine=all.filter(function(e){return e.id===me})[0];
  paint(sortEntries(all.filter(function(e){return !e.hidden}),lbMetric),false);
  remoteBoard(mine&&!mine.hidden?{id:mine.id,name:mine.name,stars:mine.stars,missions:mine.missions,trophies:mine.trophies}:null)
    .then(function(list){if(list&&document.getElementById("extra-leaderboard").classList.contains("active"))paint(sortEntries(list,lbMetric),true)});

  function val(e){return lbMetric==="missions"?e.missions+" missions":e.stars.toLocaleString()+" ★"}
  function sub(e){return lbMetric==="missions"?e.stars.toLocaleString()+" stars":e.missions+" missions · "+e.trophies+" trophies"}
  function paint(list,online){
    var top=list.slice(0,3),rest=list.slice(3,50),medals=["🥇","🥈","🥉"];
    var idx=-1;list.forEach(function(e,i){if(e.id===me)idx=i});
    var meLine;
    if(!me)meLine="Sign in to put your name on the board. Guests don’t appear here.";
    else if(mine&&mine.hidden)meLine="An admin has hidden your name from the board.";
    else if(idx>-1)meLine="You are #"+(idx+1)+" of "+list.length+" · "+val(list[idx]);
    else meLine="Complete a mission to climb the board!";
    var html='<div class="extra-hero"><h2>🏅 Leaderboard</h2><p>'+(online?"Cadets from everywhere, ranked live.":"Top cadets on this device.")+'</p>'+
      '<div class="lb-tools"><button class="extra-btn" data-metric="stars" aria-pressed="'+(lbMetric==="stars")+'">★ Stars earned</button>'+
      '<button class="extra-btn" data-metric="missions" aria-pressed="'+(lbMetric==="missions")+'">🚀 Missions</button>'+
      '<button class="extra-btn" data-refresh="1">↻ Refresh</button></div></div>'+
      '<p class="lb-me">'+esc(meLine)+'</p>';
    if(!list.length)html+='<div class="lb-empty">No cadets yet. Create an account and be the first on the board!</div>';
    else{
      html+='<div class="lb-podium">'+top.map(function(e,i){
        return'<div class="lb-pod p'+(i+1)+(e.id===me?' me':'')+'"><div class="lb-medal">'+medals[i]+'</div><div class="lb-name">'+esc(e.name)+(e.id===me?' (you)':'')+'</div><div class="lb-score">'+esc(val(e))+'</div><div class="lb-sub">'+esc(sub(e))+'</div></div>';
      }).join("")+'</div>';
      if(rest.length)html+='<div class="lb-list">'+rest.map(function(e,i){
        return'<div class="lb-row'+(e.id===me?' me':'')+'"><div class="lb-rank">#'+(i+4)+'</div><div style="min-width:0"><div class="lb-name">'+esc(e.name)+(e.id===me?' (you)':'')+'</div><div class="lb-sub">'+esc(sub(e))+'</div></div><div class="lb-score">'+esc(val(e))+'</div></div>';
      }).join("")+'</div>';
    }
    el.innerHTML=html;
  }
}

function adminNow(){var u=currentUser();return u&&isAdmin(readUsers()[u])?u:null}
function renderAdmin(){
  var el=document.getElementById("extra-admin");if(!el)return;
  if(!adminNow()){el.innerHTML='<div class="lb-empty">Admins only.</div>';return}
  var users=readUsers(),list=sortEntries(localEntries(true),"stars"),total=list.reduce(function(a,e){return a+e.stars},0);
  var rows=list.map(function(e){
    var u=users[e.id],self=e.id===adminNow();
    return'<tr><td><b>'+esc(e.name)+'</b>'+(isAdmin(u)?'<span class="adm-badge">ADMIN</span>':'')+(e.hidden?'<span class="adm-badge" style="background:rgba(255,125,125,.18);color:var(--coral)">HIDDEN</span>':'')+'<div class="lb-sub">@'+esc(e.id)+'</div></td>'+
      '<td>'+esc(u.email||"—")+'</td><td>'+e.stars.toLocaleString()+'</td><td>'+e.missions+'</td>'+
      '<td><div class="adm-actions">'+
      '<button class="extra-btn" data-act="hide" data-id="'+esc(e.id)+'">'+(e.hidden?"Show":"Hide")+'</button>'+
      '<button class="extra-btn" data-act="code" data-id="'+esc(e.id)+'">New code</button>'+
      '<button class="extra-btn adm-danger" data-act="reset" data-id="'+esc(e.id)+'">Reset progress</button>'+
      (self?'':'<button class="extra-btn adm-danger" data-act="delete" data-id="'+esc(e.id)+'">Delete</button>')+
      '</div></td></tr>';
  }).join("");
  el.innerHTML='<div class="extra-hero"><h2>🛡️ Admin panel</h2><p>'+list.length+' account'+(list.length===1?"":"s")+' on this device · '+total.toLocaleString()+' stars earned in total.</p>'+
    '<div class="lb-tools"><button class="extra-btn adm-danger" data-act="wipe">Reset the whole leaderboard</button></div></div>'+
    '<div class="extra-card adm-wrap"><table class="adm-table"><thead><tr><th>Cadet</th><th>Email</th><th>Stars</th><th>Missions</th><th>Actions</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
    activityHTML();
  markSeen();
}
function activityHTML(){
  var seen=+get(localStorage,SEEN_KEY)||0,log=readLog().slice(-30).reverse();
  var notif=window.Notification&&Notification.permission==="default"?'<button class="extra-btn" data-act="notif">Turn on desktop alerts</button>':"";
  var rows=log.length?log.map(function(e){
    return'<div class="lb-row" style="grid-template-columns:minmax(0,1fr) auto'+(e.t>seen?';border-color:var(--cyan)':'')+'"><div><b>'+esc(LABELS[e.type]||e.type)+'</b>'+(e.user?' <span class="lb-sub">@'+esc(e.user)+'</span>':'')+(e.type==="signup"&&e.extra?'<div class="lb-sub">'+esc(e.extra)+'</div>':'')+'</div><div class="lb-sub">'+esc(new Date(e.t).toLocaleString())+'</div></div>';
  }).join(""):'<div class="lb-empty">No activity yet.</div>';
  return'<div class="extra-card" style="margin-top:14px"><h3 style="margin-bottom:6px">🔔 Activity</h3><p class="lb-sub" style="margin-bottom:10px">'+
    (NOTIFY_URL?"Email alerts are ON — each sign-up and sign-in is also sent to your alert endpoint.":"Email alerts are OFF — set <code>window.ASTROCADET_NOTIFY_ENDPOINT</code> to get these in your inbox.")+'</p>'+
    '<div class="lb-tools" style="margin:0 0 10px">'+notif+'<button class="extra-btn adm-danger" data-act="clearlog">Clear log</button></div><div class="lb-list">'+rows+'</div></div>';
}
function adminAct(act,id){
  var me=adminNow();if(!me)return;
  var users=readUsers();
  if(act==="clearlog"){set(localStorage,LOG_KEY,"[]");renderAdmin();return}
  if(act==="notif"){try{Notification.requestPermission().then(renderAdmin)}catch(e){}return}
  if(act==="wipe"){
    if(!confirm("Reset progress for EVERY account? This clears all stars and missions."))return;
    Object.keys(users).forEach(function(k){del(localStorage,BASE_SAVE+".u."+k)});
    location.reload();return;
  }
  if(!users[id])return;
  if(act==="hide"){users[id].hidden=!users[id].hidden;writeUsers(users);renderAdmin();return}
  if(act==="reset"){
    if(!confirm("Reset all progress for @"+id+"?"))return;
    del(localStorage,BASE_SAVE+".u."+id);
    if(id===me){location.reload();return}
    renderAdmin();return;
  }
  if(act==="delete"){
    if(id===me||!confirm("Delete the account @"+id+" and all its progress?"))return;
    delete users[id];writeUsers(users);del(localStorage,BASE_SAVE+".u."+id);renderAdmin();return;
  }
  if(act==="code"){
    var pw=prompt("New secret code for @"+id+" (at least 6 characters):");
    if(pw===null)return;
    if(pw.length<6){alert("Secret codes need at least 6 characters.");return}
    var salt=randomSalt();
    hashPw(pw,salt).then(function(hs){var us=readUsers();if(us[id]){us[id].salt=salt;us[id].hash=hs;writeUsers(us);alert("Done. Give @"+id+" the new code.")}});
  }
}

function addExtraTab(nav,app,id,label,fn){
  if(document.getElementById("extra-"+id))return;
  var b=document.createElement("button");b.className="tab";b.dataset.extraView=id;b.textContent=label;nav.appendChild(b);
  var sec=document.createElement("section");sec.id="extra-"+id;sec.className="extra-view";sec.dataset.extraView=id;app.appendChild(sec);
  b.addEventListener("click",function(){
    document.querySelectorAll(".view").forEach(function(v){v.classList.remove("is-active")});
    document.querySelectorAll(".extra-view").forEach(function(v){v.classList.toggle("active",v===sec)});
    document.querySelectorAll(".tabs .tab").forEach(function(t){t.classList.toggle("is-active",t===b)});
    fn();window.scrollTo(0,0);
  });
  sec._tab=b;return sec;
}
function mountTabs(user){
  var nav=$(".tabs"),app=$("#app");if(!nav||!app)return;
  var lb=addExtraTab(nav,app,"leaderboard","🏅 Leaderboard",renderLB);
  if(lb)lb.addEventListener("click",function(e){
    var m=e.target.closest("[data-metric]");
    if(m){lbMetric=m.dataset.metric;renderLB();return}
    if(e.target.closest("[data-refresh]"))renderLB();
  });
  if(isAdmin(user)){
    var ad=addExtraTab(nav,app,"admin","🛡️ Admin",renderAdmin);
    if(ad){
      adminTabBtn=ad._tab;badge();
      ad.addEventListener("click",function(e){var b=e.target.closest("[data-act]");if(b)adminAct(b.dataset.act,b.dataset.id)});
    }
    setTimeout(function(){
      if(unseenCount())adminAlert();
      else try{AstroCadet.UI.toast("🛡️ Welcome back, admin","mint")}catch(e){}
    },700);
  }
}

/* ---- twinkling stars behind the card ---- */
var starsOn=false;
function stars(){
  if(starsOn)return;starsOn=true;
  var c=$("#authStars");if(!c)return;
  var x=c.getContext("2d"),w=0,h=0,st=[],t=0;
  var calm=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
  function size(){
    w=c.width=window.innerWidth;h=c.height=window.innerHeight;
    var n=Math.min(150,Math.round(w*h/9000));st=[];
    for(var i=0;i<n;i++)st.push({x:Math.random()*w,y:Math.random()*h,r:.5+Math.random()*1.7,a:.3+Math.random()*.6,p:Math.random()*6.28,s:.04+Math.random()*.12,
      c:Math.random()>.85?"79,227,255":(Math.random()>.9?"255,200,87":"220,235,255")});
  }
  function draw(){
    t+=.012;x.clearRect(0,0,w,h);
    for(var i=0;i<st.length;i++){
      var s=st[i],tw=calm?1:.7+.3*Math.sin(t*1.6+s.p);
      x.beginPath();x.arc(s.x,s.y,s.r,0,6.283);x.fillStyle="rgba("+s.c+","+(s.a*tw).toFixed(3)+")";x.fill();
      if(!calm){s.y+=s.s;if(s.y>h+2){s.y=-2;s.x=Math.random()*w}}
    }
    requestAnimationFrame(draw);
  }
  size();window.addEventListener("resize",size);draw();
}

document.addEventListener("DOMContentLoaded",function(){
  var f=$("#authForm");if(!f)return;
  f.addEventListener("submit",submit);
  $("#tabSignin").addEventListener("click",function(){setMode("signin")});
  $("#tabSignup").addEventListener("click",function(){setMode("signup")});
  $("#authPass").addEventListener("input",function(){if(mode==="signup")meter(this.value)});
  $("#authEye").addEventListener("click",function(){
    var p=$("#authPass"),p2=$("#authPass2"),show=p.type==="password";
    p.type=show?"text":"password";p2.type=show?"text":"password";
    this.setAttribute("aria-pressed",String(show));
    this.setAttribute("aria-label",show?"Hide secret code":"Show secret code");
    this.textContent=show?"🙈":"👁";
  });
  $("#authGuest").addEventListener("click",function(){logEvent("guest","");go(GUEST,true)});
  var out=$("#btnSignOut");
  if(out)out.addEventListener("click",function(){clearSession();location.reload()});
});
})();
;
/* ============================================================
   1. CONTENT DATA
   ============================================================ */
"use strict";

const PLANETS = [
  {
    id:"mercury", name:"Mercury", type:"Rocky planet · 1st from the Sun", hue:"#b9b3a8",
    art:"mercury",
    blurb:"The smallest planet and the fastest one around the Sun. Mercury is a rocky world covered in craters, with almost no air to protect it.",
    stats:{
      "Diameter":"4,879 km","Distance from Sun":"58 million km","Day length":"59 Earth days",
      "Year length":"88 Earth days","Moons":"0","Temperature":"-180 °C to 430 °C"
    },
    facts:[
      ["Speed racer","Mercury races around the Sun at about 47 km per second — faster than any other planet."],
      ["Two kinds of hot","By day the surface can bake at 430 °C, then drop to -180 °C at night. No blanket of air keeps the heat in."],
      ["Crater face","With no wind or rain to smooth it out, Mercury wears billions of years of crash marks."]
    ],
    alt:"A grey cratered planet lit from the left."
  },
  {
    id:"venus", name:"Venus", type:"Rocky planet · 2nd from the Sun", hue:"#e8c98a",
    art:"venus",
    blurb:"Venus is almost the same size as Earth, but a thick blanket of carbon-dioxide clouds makes it the hottest planet of all.",
    stats:{
      "Diameter":"12,104 km","Distance from Sun":"108 million km","Day length":"243 Earth days",
      "Year length":"225 Earth days","Moons":"0","Temperature":"about 465 °C"
    },
    facts:[
      ["Backwards spinner","Venus turns the opposite way to most planets — on Venus the Sun would rise in the west."],
      ["Slowest day ever","One spin takes longer than one trip around the Sun, so a Venus day is longer than its year."],
      ["Clouds of acid","Its clouds are made of sulphuric acid droplets. Spacecraft only survive on the surface for about an hour."]
    ],
    alt:"A creamy yellow planet wrapped in swirling clouds."
  },
  {
    id:"earth", name:"Earth", type:"Rocky planet · 3rd from the Sun", hue:"#5aa9ff",
    art:"earth",
    blurb:"Our home. Earth is the only place we know of with liquid oceans, breathable air and living things — that makes it very special.",
    stats:{
      "Diameter":"12,742 km","Distance from Sun":"150 million km","Day length":"24 hours",
      "Year length":"365.25 days","Moons":"1 (the Moon)","Temperature":"about 15 °C average"
    },
    facts:[
      ["Water world","About 71% of Earth's surface is covered by water — that's why astronauts call it the Blue Marble."],
      ["A protective bubble","Earth's magnetic field deflects most of the Sun's charged particles, and the atmosphere burns up small space rocks."],
      ["Perfect distance","Earth sits in the 'habitable zone' — not too hot, not too cold — so water can stay liquid."]
    ],
    alt:"A blue and green planet with white clouds."
  },
  {
    id:"mars", name:"Mars", type:"Rocky planet · 4th from the Sun", hue:"#e2703f",
    art:"mars",
    blurb:"The Red Planet gets its colour from rusty iron dust. Robots from Earth are exploring it right now, and its canyons and volcanoes are enormous.",
    stats:{
      "Diameter":"6,779 km","Distance from Sun":"228 million km","Day length":"24.6 hours",
      "Year length":"687 Earth days","Moons":"2 (Phobos, Deimos)","Temperature":"about -60 °C average"
    },
    facts:[
      ["Tallest volcano","Olympus Mons rises about 22 km high — roughly two and a half times the height of Mount Everest."],
      ["Grand canyon","Valles Marineris is a canyon system about 4,000 km long, long enough to stretch across the USA."],
      ["Two tiny moons","Phobos and Deimos are lumpy and small. Phobos circles Mars three times a day and is slowly drifting closer."]
    ],
    alt:"A rusty red planet with a white polar cap and dark patches."
  },
  {
    id:"jupiter", name:"Jupiter", type:"Gas giant · 5th from the Sun", hue:"#d9a06a",
    art:"jupiter",
    blurb:"The biggest planet in the solar system — a huge ball of swirling gas with a storm that has been spinning for hundreds of years.",
    stats:{
      "Diameter":"139,820 km","Distance from Sun":"778 million km","Day length":"9.9 hours",
      "Year length":"11.9 Earth years","Moons":"95+ known","Temperature":"about -110 °C at the cloud tops"
    },
    facts:[
      ["King of planets","Jupiter could hold more than 1,300 Earths inside it, yet it spins fastest of all — one day lasts under 10 hours."],
      ["Great Red Spot","A storm wider than Earth that has been raging for at least 150 years, maybe far longer."],
      ["Its own mini solar system","Jupiter has dozens of moons; four big ones — Io, Europa, Ganymede and Callisto — are visible with binoculars."]
    ],
    alt:"A banded orange and cream gas giant with a great red spot."
  },
  {
    id:"saturn", name:"Saturn", type:"Gas giant · 6th from the Sun", hue:"#e8d3a0",
    art:"saturn",
    blurb:"Saturn's rings make it the most recognisable planet. The rings are not solid — they are billions of pieces of ice and rock, some tiny, some house-sized.",
    stats:{
      "Diameter":"116,460 km","Distance from Sun":"1.4 billion km","Day length":"10.7 hours",
      "Year length":"29.4 Earth years","Moons":"140+ known","Temperature":"about -140 °C at the cloud tops"
    },
    facts:[
      ["Paper-thin rings","The rings stretch about 280,000 km wide but in most places are only about 10 metres thick."],
      ["It would float","Saturn is less dense than water, so a giant bath would let it float (if you could find one)."],
      ["Moon with weather","Titan, its largest moon, has lakes and rivers — made of liquid methane, not water."]
    ],
    alt:"A pale gold planet with wide tilted rings."
  },
  {
    id:"uranus", name:"Uranus", type:"Ice giant · 7th from the Sun", hue:"#a8e6ef",
    art:"uranus",
    blurb:"An ice giant that rolls around the Sun on its side, probably after a giant collision long ago. Its blue-green colour comes from methane gas.",
    stats:{
      "Diameter":"50,724 km","Distance from Sun":"2.9 billion km","Day length":"17.2 hours",
      "Year length":"84 Earth years","Moons":"28 known","Temperature":"about -195 °C"
    },
    facts:[
      ["Sideways planet","Uranus is tipped over by nearly 98°, so it seems to roll along its orbit like a ball."],
      ["Crazy seasons","Each pole gets about 42 years of sunlight, then 42 years of darkness."],
      ["First spotted with a telescope","William Herschel found Uranus in 1781 — the first planet discovered that way."]
    ],
    alt:"A pale cyan ice giant with faint bands."
  },
  {
    id:"neptune", name:"Neptune", type:"Ice giant · 8th from the Sun", hue:"#4d7bff",
    art:"neptune",
    blurb:"The farthest planet from the Sun, and the windiest. Neptune is so far away that sunlight takes more than four hours to reach it.",
    stats:{
      "Diameter":"49,244 km","Distance from Sun":"4.5 billion km","Day length":"16.1 hours",
      "Year length":"165 Earth years","Moons":"16 known","Temperature":"about -200 °C"
    },
    facts:[
      ["Supersonic winds","Winds on Neptune can blow faster than 2,000 km/h — faster than a passenger jet, times three."],
      ["Found with maths","Astronomers predicted Neptune's position from wobbles in Uranus's orbit, then found it in 1846."],
      ["A moon that goes backwards","Triton orbits the wrong way, so it was probably a captured icy world."]
    ],
    alt:"A deep blue planet with dark storms and faint streaks."
  }
];

const SUN_INFO = {
  id:"sun", name:"The Sun", type:"Our star", hue:"#ffc857", art:"sun",
  blurb:"The Sun is a star — a giant ball of super-hot gas. It holds the whole solar system together and gives us light, warmth and almost all of our energy.",
  stats:{
    "Diameter":"1.39 million km","Distance from Earth":"150 million km","Day length":"about 27 Earth days",
    "Surface temperature":"5,500 °C","Core temperature":"15 million °C","Age":"4.6 billion years"
  },
  facts:[
    ["99.8% of everything","The Sun contains almost all the mass in the solar system. Every planet could fit inside it with room to spare."],
    ["Light with a delay","Sunlight takes about 8 minutes and 20 seconds to reach Earth."],
    ["Not yellow","Seen from space the Sun is actually white — our air makes it look yellow and red near the horizon."]
  ],
  alt:"A bright glowing sun."
};

/* ---------------- MISSIONS ---------------- */
const STAGES = [
  {
    id:1, hue:42, emoji:"✦", title:"Early Stargazers",
    subtitle:"How ancient sky-watchers turned dots of light into stories.",
    skill:"Constellations",
    intro:"Long before telescopes, people looked up and joined the stars like dots in a drawing. Those pictures are called constellations — and we still use them today!",
    lessons:[
      {
        h:"The sky as a storybook",
        p:["Thousands of years ago, farmers, sailors and travellers needed the sky. It told them when to plant crops, when winter was coming, and which way was north.",
           "With no maps, they invented a trick: connect bright stars with imaginary lines and give the shapes names. A hunter, a bear, a swan, a scorpion. If you can remember the story, you can remember the way home."],
        note:"A constellation is an official region of the sky. There are 88 of them, and every star you can see belongs to one."
      },
      {
        h:"Meet the Big Dipper",
        p:["Seven bright stars in the constellation Ursa Major look like a soup ladle with a bent handle. In North America it is called the Big Dipper; in the UK, the Plough.",
           "Follow the two stars at the far edge of the bowl and keep going straight about five times that distance. You will land on Polaris, the North Star — which sits almost exactly above Earth's north pole."],
        note:"Because Polaris barely moves during the night, finding it is like finding north. It has guided travellers for centuries."
      },
      {
        h:"Why the stars seem to move",
        p:["Stars do drift, but they are so far away that your whole life would barely show it. What you actually see is Earth turning.",
           "Earth spins once about every 24 hours, so the whole sky appears to sweep past overhead — while the North Star stays still because it is lined up with Earth's axis."],
        note:"The star trails in long-exposure photos are not stars racing — they are proof that Earth is spinning."
      }
    ],
    art:"constellation",
    activity:{
      type:"constellation",
      title:"Connect the Big Dipper",
      hint:"Tap the stars in order, starting at number 1, to draw the dipper's bowl and handle."
    },
    quiz:[
      { q:"What do we call a group of stars that forms a picture in the sky?",
        options:["A constellation","A galaxy","A crater","A comet"],
        correct:0, hint:"The word starts with 'con-' and sounds a bit like 'constellation'.",
        explain:"A constellation is a named pattern of stars. There are 88 official constellations covering the whole sky." },
      { q:"Which star sits almost exactly above Earth's north pole?",
        options:["Polaris (the North Star)","Sirius","The Sun","Betelgeuse"],
        correct:0, hint:"It is named after the direction it marks.",
        explain:"Polaris stays in nearly the same spot all night, which is why it has been used for navigation for centuries." },
      { q:"Why do the stars appear to move across the sky during the night?",
        options:["Because Earth is spinning","Because the stars are running away","Because the Moon pushes them","Because the sky is moving"],
        correct:0, hint:"Look at what your own planet is doing while you stand still.",
        explain:"Earth rotates once every 24 hours, so the night sky sweeps past us. The stars themselves barely move." }
    ],
    reward:{ label:"Stargazer Badge", icon:"✦" }
  },
  {
    id:2, hue:190, emoji:"🚀", title:"Rocket Pioneers",
    subtitle:"Why a rocket needs nothing to push against — and how thrust works.",
    skill:"Thrust & motion",
    intro:"A rocket is a machine that throws hot gas backwards extremely fast. The gas pushes back, and the rocket goes forward. Simple idea, enormous engineering.",
    lessons:[
      {
        h:"Newton's third law",
        p:["Isaac Newton wrote it down in 1687: for every action there is an equal and opposite reaction.",
           "Push a wall, and the wall pushes back on your hand. A rocket throws gas down; the gas throws the rocket up. It does not need air to push against — that is exactly why rockets work in the emptiness of space."],
        note:"The force on the rocket equals the force on the gas. Rockets work in a vacuum because the reaction is between the rocket and its own exhaust."
      },
      {
        h:"Building enough push",
        p:["The Saturn V rocket that carried astronauts to the Moon weighed about 2,970 tonnes at launch, and most of that was fuel.",
           "To get away from Earth you need a speed of about 11.2 km per second — 40,000 km/h. Nothing you can do with wheels gets close; you must carry your own oxygen and burn hard for minutes."],
        note:"Rockets are built in stages: empty fuel tanks are dropped off so the rest of the rocket does not have to carry dead weight."
      },
      {
        h:"Gravity is a hill, not a wall",
        p:["Getting to orbit is not about going high — it is about going sideways fast enough to keep missing the ground.",
           "At about 7.8 km per second, an object falls towards Earth exactly as fast as the curved Earth drops away beneath it. That is orbit: falling forever, and never landing."],
        note:"Try it in the orbit mission later — this is the same idea that keeps the Moon circling Earth."
      }
    ],
    art:"rocket",
    activity:{
      type:"thrust",
      title:"Launch console",
      hint:"Slide the throttle up to <b>100% thrust</b> and feel the rocket climb."
    },
    quiz:[
      { q:"Which law explains why hot gas shooting downwards pushes a rocket upwards?",
        options:["Newton's third law of motion","The law of magnetism","The law of buoyancy","The law of reflection"],
        correct:0, hint:"It is the 'equal and opposite reaction' one.",
        explain:"Action: gas is pushed down. Reaction: the rocket is pushed up with the same force. This works even where there is no air." },
      { q:"Why can a rocket fly in space where there is no air?",
        options:["It carries its own oxidiser and pushes against its exhaust","It pushes against the air","Its wings create lift","Space has extra gravity"],
        correct:0, hint:"Think about what comes out of the engine.",
        explain:"A rocket carries both fuel and oxygen, and the reaction force comes from throwing its own exhaust backwards — no air required." },
      { q:"Roughly how fast must you travel to stay in low Earth orbit?",
        options:["About 7.8 km per second","About 100 km per hour","About 1 km per second","About 300 km per hour"],
        correct:0, hint:"It is many times faster than a speeding bullet.",
        explain:"At around 7.8 km/s you fall around Earth as fast as the ground curves away, so you keep orbiting instead of landing." }
    ],
    reward:{ label:"Rocket Wings", icon:"🚀" }
  },
  {
    id:3, hue:265, emoji:"🛰", title:"Spacecraft Pilot",
    subtitle:"Life support, power and the systems that keep a crew alive.",
    skill:"Systems & power",
    intro:"A spacecraft is a tiny, sealed world. Air, water, power and temperature are all managed by machines — and a pilot has to watch every one of them.",
    lessons:[
      {
        h:"The air you carry",
        p:["There is no air in space, so a spacecraft brings its own. Most stations use a mix of oxygen and nitrogen at about the pressure you feel at sea level.",
           "Oxygen is often made by splitting water with electricity, and carbon-dioxide scrubbers remove the gas you breathe out. Without those two systems, the air would go bad within hours."],
        note:"The station's life-support system is called ECLSS — Environmental Control and Life Support System."
      },
      {
        h:"Power from sunlight",
        p:["Solar panels turn sunlight into electricity. Near Earth, each square metre can collect about 1,360 watts of sunlight — enough, with good panels, to run pumps, computers and lights.",
           "The panels also charge batteries, because a spacecraft in low orbit spends about 45 minutes of every 90-minute loop in Earth's shadow."],
        note:"Solar panels work better in space than on the ground: there is no cloud, no night-time air, and no atmosphere to dim the light."
      },
      {
        h:"A cockpit built for mistakes",
        p:["Everything important has a backup, and the important alarms are hard to ignore. Pilots run checklists out loud, in pairs, so a tired voice cannot skip a step.",
           "Modern spacecraft can fly themselves most of the time — but crews still train manually, because computers fail and because a human can notice something a sensor cannot."],
        note:"Checklists are not a sign of forgetting. They are how professionals make sure nothing is missed when they are tired or busy."
      }
    ],
    art:"cockpit",
    activity:{
      type:"systems",
      title:"Bring the ship online",
      hint:"Switch on <b>all three</b> systems. Keep them green."
    },
    quiz:[
      { q:"Why does a spacecraft need solar panels and batteries?",
        options:["Panels make power from sunlight and batteries store it for the dark half of the orbit","To look shiny","To keep the ship cool","To send radio waves"],
        correct:0, hint:"One collects, the other saves it for later.",
        explain:"Sunlight makes electricity through the panels, and batteries keep the ship running while it is in Earth's shadow." },
      { q:"What does a carbon-dioxide scrubber do?",
        options:["Removes the CO₂ that the crew breathes out","Makes the ship heavier","Cools the engines","Creates gravity"],
        correct:0, hint:"Breathing out too much of one gas is the problem.",
        explain:"Crews breathe out carbon dioxide. Scrubbers remove it so the cabin air stays safe to breathe." },
      { q:"Why do pilots use checklists even for tasks they know well?",
        options:["To make sure no step gets missed under pressure","Because they forget everything","To waste time","Because computers cannot count"],
        correct:0, hint:"Think about being tired and busy during a critical moment.",
        explain:"Checklists turn memory into a reliable procedure, so important steps are never skipped when the crew is busy or stressed." }
    ],
    reward:{ label:"Pilot Wings", icon:"🛰" }
  },
  {
    id:4, hue:150, emoji:"🌱", title:"Living in Orbit",
    subtitle:"Eating, sleeping and staying healthy when everything floats.",
    skill:"Microgravity",
    intro:"Orbit feels weightless, but gravity has not switched off. Astronauts are falling around Earth — and everything inside the station falls with them.",
    lessons:[
      {
        h:"Why everything floats",
        p:["The space station is in free fall around Earth. Because the station and everything in it fall at the same rate, nothing presses down on anything else — so nothing stays on a table.",
           "This is called microgravity, or 'weightlessness'. Gravity is still about 90% as strong up there; you just cannot feel it while you fall together."],
        note:"Astronauts on the station orbit about 400 km up — that is roughly the distance from London to Paris, not very far at all."
      },
      {
        h:"Everyday life, rearranged",
        p:["Water forms floating blobs, so drinks come in pouches with straws. Food is often freeze-dried and rehydrated, and salt and pepper are liquids so they do not drift into eyes or vents.",
           "Sleeping bags are strapped to the wall. Astronauts can sleep in any direction — some say they feel like they are standing upright all night."],
        note:"Crumbs are banned on the station. A floating crumb can drift into an electrical panel or someone's lung."
      },
      {
        h:"Bodies need gravity",
        p:["Without weight pressing on bones and muscles, the body starts to weaken. Astronauts lose bone density and muscle mass unless they exercise hard — usually about two hours a day.",
           "Fluids also drift towards the head, which makes faces puffy and can affect eyesight. That is why crews measure their bodies carefully before, during and after a flight."],
        note:"Exercise is not just fitness in space; it is a medical requirement. Bikes and resistance machines are bolted to the station."
      }
    ],
    art:"station",
    activity:{
      type:"zerog",
      title:"Catch the floating snacks",
      hint:"Tap <b>all five</b> floating items before they drift out of reach."
    },
    quiz:[
      { q:"Why do astronauts float inside the space station?",
        options:["The station and everything in it are falling around Earth together","There is no gravity in space","The station spins very fast","Their suits are filled with helium"],
        correct:0, hint:"Free fall, not zero gravity.",
        explain:"They are in continuous free fall around Earth, so nothing presses on anything else. Gravity is still about 90% as strong as on the ground." },
      { q:"Why is exercise a daily requirement on the station?",
        options:["To stop bones and muscles weakening without gravity","To make the crew tired","To generate electricity","To heat the station"],
        correct:0, hint:"Think about what gravity normally does to your body.",
        explain:"Bones and muscles need load to stay strong. Without it they weaken, so astronauts exercise around two hours a day." },
      { q:"Why is loose food like crumbs and salt not allowed?",
        options:["It can float into eyes, lungs and electrical equipment","It tastes bad","It is too heavy","It attracts aliens"],
        correct:0, hint:"Anything that is not tied down goes wherever the air takes it.",
        explain:"In microgravity crumbs drift everywhere, and they can clog filters or damage electronics. Food is packaged to stay put." }
    ],
    reward:{ label:"Orbit Gardener", icon:"🌱" }
  },
  {
    id:5, hue:275, emoji:"🛰️", title:"Space Navigation & Orbits",
    subtitle:"How spacecraft find their way — and why an orbit is a permanent fall.",
    skill:"Orbits & navigation",
    intro:"An orbit is not a road. It is a balance: sideways speed versus the pull of gravity. Change the speed, and you change the whole shape of your path.",
    lessons:[
      {
        h:"Orbits are shaped by speed",
        p:["Too slow, and gravity wins — you fall back down. Fast enough sideways, and you fall around the curve forever. Too fast, and you escape the planet completely.",
           "That is why almost every orbit is an oval, not a circle. Close to the planet you move fastest; far away you slow down. The lowest point is called perigee, the highest point apogee."],
        note:"Speed and height trade places. A satellite that dives low speeds up, exactly like a skateboarder dropping into a bowl."
      },
      {
        h:"Getting from one place to another",
        p:["You cannot fly a spacecraft straight to another planet like a plane. You time a burn of the engine so your new oval path touches both orbits.",
           "Engineers call this a Hohmann transfer. You wait for the two planets to line up, burn once to raise your orbit, coast for months, then burn again to stay at the destination. Fuel is so precious that missions can wait years for the right launch window."],
        note:"Missions to Mars launch roughly every 26 months, when Earth and Mars are in the right positions. Miss it and you wait two more years."
      },
      {
        h:"Finding your way with no signposts",
        p:["There are no street signs in space. A spacecraft works out where it is by measuring radio signals from Earth, and by watching the positions of the Sun and stars with special cameras called star trackers.",
           "It then adjusts using small thrusters — tiny puffs of gas that shift it by millimetres per second. In orbit, a small push, repeated, moves you a very long way."],
        note:"Star trackers compare the sky they see with a stored map of thousands of stars. It is the same trick ancient sailors used, done by a computer."
      }
    ],
    art:"orbit",
    activity:{
      type:"orbit",
      title:"Set a stable orbit",
      hint:"Raise the orbit speed until the satellite circles Earth without falling in or flying away."
    },
    quiz:[
      { q:"What is an orbit really?",
        options:["Falling around a planet fast enough to keep missing it","A road in space","A place where gravity stops","A circle drawn by the Moon"],
        correct:0, hint:"Think of a ball thrown so hard it never lands.",
        explain:"An orbit is continuous free fall. The sideways speed is just right, so the object falls around the curve of the planet instead of into it." },
      { q:"Why does a spacecraft sometimes wait years for a launch window?",
        options:["It needs the destination planet to be in the right position to save fuel","It is not finished being built","Rockets only work in summer","Astronauts need a holiday"],
        correct:0, hint:"The planets keep moving while you plan.",
        explain:"A transfer burn puts you on an oval path that must meet the target's orbit. The planets only line up at certain times, so timing saves enormous amounts of fuel." },
      { q:"How does a spacecraft work out where it is?",
        options:["By radio signals from Earth and star trackers that read the sky","By asking other spacecraft","By counting engine burns","By following a rope"],
        correct:0, hint:"Two methods: one from home, one from the stars.",
        explain:"Radio ranging measures distance from ground stations, and star trackers compare the sky with a stored star map to fix the spacecraft's direction." }
    ],
    reward:{ label:"Navigator Star", icon:"🛰️" }
  },
  {
    id:6, hue:15, emoji:"🎧", title:"Mission Control & Teamwork",
    subtitle:"Hundreds of people, one voice at a time — how a mission actually runs.",
    skill:"Communication",
    intro:"A mission is never one person. Flight controllers, engineers, doctors and scientists all watch different screens. Clear talking is what holds them together.",
    lessons:[
      {
        h:"Who is in the room",
        p:["In Mission Control, each desk owns one system: propulsion, power, life support, communications, weather, crew health. Each one reports to the Flight Director, who makes the final call.",
           "The person who talks to the crew is the CAPCOM — short for Capsule Communicator. One voice goes up, so the crew never has to work out who to listen to."],
        note:"'Flight' is what controllers call the Flight Director. In a real room, the words 'Flight, guidance, go/no-go' mean a decision is about to be made."
      },
      {
        h:"Talking so nothing is lost",
        p:["Radio traffic is short, ordered and repeatable. Controllers say the number, then the unit: 'two hundred, metres per second'. If it matters, the crew reads it back.",
           "Phrases like 'say again', 'stand by' and 'copy' exist so that nobody has to guess. A calm, clear voice is a trained skill, not a personality trait."],
        note:"Read-back is why important information survives noise and stress: the listener proves they heard it correctly."
      },
      {
        h:"When something goes wrong",
        p:["In April 1970 an oxygen tank exploded on Apollo 13, far from home. The crew and controllers had to invent a new plan using what was on board.",
           "They powered up the lunar module as a lifeboat, built a carbon-dioxide filter adapter from plastic and tape, and turned the engine off for hours to save power — then burned it precisely to come home. Everyone came back."],
        note:"The Apollo 13 crew never landed on the Moon. The mission is famous anyway, because the team solved a problem nobody had planned for."
      }
    ],
    art:"control",
    activity:{
      type:"comms",
      title:"Send a clean status report",
      hint:"Pick the <b>clearest and most complete</b> message for each situation."
    },
    quiz:[
      { q:"In Mission Control, who is the only person who speaks directly to the crew?",
        options:["The CAPCOM","The Flight Director","The flight surgeon","The weather officer"],
        correct:0, hint:"The name comes from 'capsule communicator'.",
        explain:"The CAPCOM is the single voice to the crew, so messages never overlap or contradict each other." },
      { q:"Why do crews read important numbers back to the ground?",
        options:["To prove the message was heard correctly","To practise their voices","To fill silence","To slow down the mission"],
        correct:0, hint:"It is a check, not a courtesy.",
        explain:"A read-back confirms that the exact value arrived without being misheard — vital when a number could mean danger." },
      { q:"What made Apollo 13 a successful failure?",
        options:["The team improvised a rescue and brought the crew home","They landed on the Moon anyway","The explosion never happened","They stayed in orbit for a year"],
        correct:0, hint:"The landing was cancelled — but what was saved?",
        explain:"The landing was abandoned. Controllers and crew worked together with limited power and improvised equipment to bring all three astronauts safely back to Earth." }
    ],
    reward:{ label:"Headset of Honour", icon:"🎧" }
  },
  {
    id:7, hue:205, emoji:"🌕", title:"The Moon Landing",
    subtitle:"The final approach: flying a lander with almost no fuel to spare.",
    skill:"Landing & precision",
    intro:"Landing on the Moon is not like landing a plane. There is no air to glide on, gravity is weaker, and the computer is far less powerful than the phone in your pocket.",
    lessons:[
      {
        h:"A very thin margin",
        p:["Apollo 11's lunar module had to slow from about 1.7 km per second to a gentle touchdown in around twelve minutes.",
           "The computer had about 2 kilobytes of usable memory — less than a single photo today. Alarms went off during the descent, and Neil Armstrong took manual control to steer past a boulder field, landing with roughly 20 seconds of fuel left."],
        note:"Armstrong and Aldrin landed on 20 July 1969 in the Sea of Tranquility. Michael Collins waited in orbit above them."
      },
      {
        h:"Flying with no air",
        p:["With no atmosphere there is no parachute and no wing lift. A lander slows down by pointing its engine at the direction of travel and burning.",
           "It also has to arrive upright. Thrusters fire in tiny pulses to tilt the craft, and on the last metres the engine blast kicks up dust that hides the ground — which is why the pilot watches for shadows and boulders instead."],
        note:"The dust problem is real: on later missions, pilots lost sight of the surface in the final seconds and had to land almost by feel."
      },
      {
        h:"What we left behind",
        p:["Six Apollo crews landed between 1969 and 1972. They brought back 382 kg of Moon rock, set up scientific instruments, and left footprints that will stay sharp for millions of years.",
           "The Moon has no wind or rain, so the only thing that slowly changes the surface is micrometeorite dust. Those footprints are a very long-lasting signature."],
        note:"Moon dust is sharp and clingy, like tiny glass. Astronauts tracked it into the cabin and it wore through seals and suits."
      }
    ],
    art:"moon",
    activity:{
      type:"lander",
      title:"Final descent",
      hint:"Tap <b>BURN</b> to slow your fall. Touch down gently at under <b>3 m/s</b>."
    },
    quiz:[
      { q:"Who was the first human to step onto the Moon?",
        options:["Neil Armstrong","Yuri Gagarin","Buzz Aldrin","Michael Collins"],
        correct:0, hint:"His first step came with the words 'one small step'.",
        explain:"Neil Armstrong stepped out on 20 July 1969. Buzz Aldrin followed, while Michael Collins stayed in orbit aboard the command module." },
      { q:"Why can a Moon lander not use a parachute?",
        options:["The Moon has no atmosphere to fill it","Parachutes are too heavy","The Moon is too cold","Gravity is too strong"],
        correct:0, hint:"Parachutes need something to push against.",
        explain:"With essentially no air, a parachute would do nothing. Landers slow down by firing an engine against their direction of travel." },
      { q:"Why will astronaut footprints on the Moon last so long?",
        options:["There is no wind or rain to erase them","The dust is made of glue","The Moon has no gravity","They were covered in plastic"],
        correct:0, hint:"Think about weather — or the lack of it.",
        explain:"Without wind or rain, the prints are only slowly worn away by micrometeorite dust, so they can survive for millions of years." }
    ],
    reward:{ label:"Lunar Medal", icon:"🌕" }
  },
  {
    id:8, hue:48, emoji:"🌞", title:"Space Weather & Solar Storms",
    subtitle:"The Sun throws storms at us — and we can see them coming.",
    skill:"Solar weather",
    intro:"The Sun is not a calm ball of light. It breathes, it flares, and sometimes it throws a billion tonnes of charged particles straight at Earth.",
    lessons:[
      {
        h:"The Sun has weather",
        p:["The Sun's surface boils with tangled magnetic fields. When those fields twist and snap, the Sun releases a burst of X-rays called a solar flare — and sometimes a cloud of charged particles called a coronal mass ejection, or CME.",
           "A CME can cross the 150 million kilometres to Earth in one to three days. When it arrives it shakes our magnetic field, and we call that a geomagnetic storm."],
        note:"Sunlight takes about 8 minutes 20 seconds to reach us. A CME takes a day or more — and that gap is exactly why we can forecast it."
      },
      {
        h:"What a storm does to us",
        p:["Charged particles can build up on satellites and cause sparks, confuse GPS signals, and make radio communication fade out. On the ground, a big storm can push extra current into power lines and damage transformers.",
           "The good news: Earth's magnetic field and atmosphere shield everyone on the surface. Astronauts on the space station are protected too, but a crew travelling to the Moon or Mars would need a storm shelter."],
        note:"In 1859 a huge storm — the Carrington Event — made telegraph wires spark and lit auroras so bright that people could read newspapers at midnight."
      },
      {
        h:"Watching the Sun",
        p:["Spacecraft like SOHO and the Parker Solar Probe watch the Sun every minute, and ground observatories track dark sunspots — cooler patches where the magnetic field is strongest.",
           "Forecasters at space weather centres issue alerts so satellite operators can switch to safe mode, airlines can reroute polar flights, and astronauts can move to a shielded module."],
        note:"Auroras are the beautiful side of space weather: particles funnelled towards the poles make the sky glow green, red and purple."
      }
    ],
    art:"sunstorm",
    activity:{
      type:"shield",
      title:"Ride out the solar storm",
      hint:"A flare is on its way. Switch on <b>all three</b> protections before the timer runs out."
    },
    quiz:[
      { q:"What is a coronal mass ejection (CME)?",
        options:["A huge cloud of charged particles thrown out by the Sun","A hole punched in the Sun","A kind of space telescope","A moon of Jupiter"],
        correct:0, hint:"It is a mass of material, ejected from the Sun's outer atmosphere.",
        explain:"A CME is a billion-tonne cloud of plasma flung from the Sun's corona. If it reaches Earth it can trigger a geomagnetic storm." },
      { q:"Why can we forecast a solar storm a day or more ahead?",
        options:["The particles travel slower than light, so we see the flare first","The Sun sends us a warning message","Storms only ever happen on Mondays","We cannot forecast them at all"],
        correct:0, hint:"Light is the fastest thing there is.",
        explain:"Light from a flare arrives in about 8 minutes, but the particles themselves take one to three days. That gap is our warning time." },
      { q:"What protects people on Earth's surface from solar radiation?",
        options:["Earth's magnetic field and atmosphere","A very large sun hat","The Moon","Nothing at all"],
        correct:0, hint:"Two natural layers of shielding.",
        explain:"The magnetosphere deflects most charged particles and the atmosphere absorbs the rest, so people on the ground stay safe." }
    ],
    reward:{ label:"Storm Shield", icon:"🌞" }
  },
  {
    id:9, hue:200, emoji:"🧑‍🚀", title:"Spacewalks & EVA",
    subtitle:"Stepping outside in a suit that is really a tiny spaceship.",
    skill:"EVA & suits",
    intro:"An EVA — extravehicular activity — is the most dangerous thing astronauts do. Outside the airlock there is nothing between you and space but a few layers of fabric and plastic.",
    lessons:[
      {
        h:"A suit is a one-person spacecraft",
        p:["An EVA suit supplies oxygen, removes carbon dioxide, keeps the temperature steady, and holds pressure around your body. It has its own radio, lights, cameras and a small computer.",
           "It is heavy — around 120 kg on Earth — but in orbit it weighs nothing, so astronauts move it with their arms and legs rather than carrying it."],
        note:"The suit's cooling system circulates water through a tight-fitting garment, because a sealed suit traps a lot of body heat."
      },
      {
        h:"Never let go",
        p:["Every spacewalker wears a safety tether clipped to the station, and often a second one. Tools are tethered too, because a dropped wrench becomes a fast-moving hazard that never comes back.",
           "Astronauts also use a SAFER jetpack as a last-resort rescue device, and they rehearse every task in a giant water tank on Earth, where floating feels similar to orbit."],
        note:"The first spacewalk was by Alexei Leonov in 1965. His suit stiffened so much in vacuum that he had to let air out of it to squeeze back through the airlock."
      },
      {
        h:"Working outside",
        p:["Spacewalks usually last six to eight hours. Astronauts work in pairs, following a checklist read out by a partner inside, and they stop often to check tethers, gloves and suit readings.",
           "The station orbits every 90 minutes, so a spacewalker sees a sunrise or sunset roughly every 45 minutes — and the temperature swings by more than 200 degrees."],
        note:"Gloves are the most fragile part of a suit. They are checked carefully for cuts, because a small tear can damage a hand in vacuum."
      }
    ],
    art:"eva",
    activity:{
      type:"order",
      title:"Prepare for your spacewalk",
      hint:"Tap the steps in the <b>correct order</b>, from first to last."
    },
    quiz:[
      { q:"Why do astronauts wear a tether during a spacewalk?",
        options:["So they cannot drift away from the station","To keep them warm","To charge their suit battery","To talk to Mission Control"],
        correct:0, hint:"Think about what happens if you push off and nothing holds you.",
        explain:"A tether keeps the astronaut attached to the station. Without it, a small push would send them drifting away with no way to return." },
      { q:"What does an EVA suit NOT have to provide?",
        options:["Gravity","Oxygen","Pressure around the body","A radio"],
        correct:0, hint:"One of these is not something a machine can make inside a suit.",
        explain:"A suit supplies air, pressure, cooling and communications — but it cannot create gravity. Astronauts stay weightless the whole time." },
      { q:"Why do astronauts train for spacewalks in a giant water tank?",
        options:["Floating in water feels similar to floating in orbit","Water is good for their skin","It is cheaper than a simulator","To practise swimming"],
        correct:0, hint:"Think about how buoyancy compares to weightlessness.",
        explain:"Neutral buoyancy in water mimics the slow, floating motion of orbit, so crews can rehearse every movement of a real spacewalk." }
    ],
    reward:{ label:"EVA Wings", icon:"🧑‍🚀" }
  },
  {
    id:10, hue:20, emoji:"🔧", title:"Rocket Engineering",
    subtitle:"Why rockets are built in pieces, and why most of it is thrown away.",
    skill:"Engineering",
    intro:"A rocket is mostly fuel tank. Engineers fight one enemy the whole time: weight. Every kilogram you carry is a kilogram you must lift.",
    lessons:[
      {
        h:"The tyranny of the rocket equation",
        p:["To go faster you need more fuel. But more fuel means a bigger tank, and a bigger tank means more weight, which needs even more fuel. This spiral is called the rocket equation, and it is why rockets are enormous.",
           "The trick is staging: build the rocket in sections and drop each empty one as soon as it is used up, so the rest of the vehicle does not have to carry dead weight."],
        note:"The Saturn V that went to the Moon was 110 metres tall and about 85% of its launch mass was propellant."
      },
      {
        h:"Engines, nozzles and thrust",
        p:["A rocket engine burns fuel with an oxidiser and pushes the hot gas out through a bell-shaped nozzle. The nozzle shape matters: it lets the gas expand and speeds it up, which increases thrust.",
           "Engineers measure efficiency as specific impulse — how much push you get per kilogram of fuel per second. Hydrogen and oxygen give a very high value, which is why they are used for upper stages."],
        note:"A nozzle that is too wide for the surrounding air pressure wastes thrust. That is why some engines have two nozzle sizes for different altitudes."
      },
      {
        h:"Reusable rockets",
        p:["For decades every rocket was thrown away after one flight. Modern boosters can fly back, land on their tail, and be refuelled for the next launch — which cuts the cost of reaching orbit dramatically.",
           "Landing a booster is hard: it must slow from thousands of kilometres per hour, steer with grid fins, and touch down on a moving ship at sea, all automatically."],
        note:"Reusability is the biggest change in rocketry since the 1960s. It is the reason launching satellites is now far cheaper than it used to be."
      }
    ],
    art:"engineering",
    activity:{
      type:"pick",
      title:"Assemble a working rocket",
      hint:"Choose the <b>three</b> parts every orbital rocket must have."
    },
    quiz:[
      { q:"Why are rockets built in stages?",
        options:["So empty tanks can be dropped and not carried further","To make them look taller","Because one engine is not enough","To carry more astronauts"],
        correct:0, hint:"Think about weight that is no longer useful.",
        explain:"Staging sheds empty tanks and engines as they are used up, so the remaining vehicle does not waste fuel lifting dead weight." },
      { q:"What does a rocket nozzle do?",
        options:["Lets hot gas expand and speed up, increasing thrust","Cools the fuel","Steers with wings","Stores oxygen"],
        correct:0, hint:"It is shaped like a bell for a reason.",
        explain:"The bell shape allows exhaust gas to expand and accelerate, which converts more of the engine's energy into forward thrust." },
      { q:"Why does reusing a booster matter so much?",
        options:["It makes reaching orbit much cheaper","It makes rockets quieter","It removes the need for fuel","It makes launches slower"],
        correct:0, hint:"Think about what you normally throw away after one use.",
        explain:"The rocket hardware is a huge part of launch cost. Flying it again instead of discarding it lowers the price of every mission." }
    ],
    reward:{ label:"Engineer's Wrench", icon:"🔧" }
  },
  {
    id:11, hue:170, emoji:"📡", title:"Satellites & GPS",
    subtitle:"How a constellation of robots tells your phone exactly where you are.",
    skill:"Satellites",
    intro:"Right now, dozens of satellites are broadcasting the time. Your phone listens to several at once and works out where it must be — using nothing but clocks and geometry.",
    lessons:[
      {
        h:"Different orbits, different jobs",
        p:["Low Earth orbit, a few hundred kilometres up, is perfect for taking pictures of the ground and for the space station. It is close, so details are sharp, but the satellite races past in about 90 minutes.",
           "Geostationary orbit is 35,786 km up, where one lap takes exactly 24 hours — so the satellite appears to hang still over one spot. That is ideal for television and weather watching."],
        note:"A GPS satellite sits in medium Earth orbit at about 20,200 km, circling twice a day."
      },
      {
        h:"Finding yourself with clocks",
        p:["Each GPS satellite broadcasts its position and the exact time. Your phone measures how long the signal took to arrive, which gives the distance to that satellite — a sphere of possible positions.",
           "With three satellites you can narrow it to two points, and a fourth resolves which one is real. That is why your phone needs to see at least four satellites to give a fix."],
        note:"GPS satellites carry atomic clocks accurate to a few billionths of a second. A timing error of one millionth of a second would put you 300 metres off."
      },
      {
        h:"What satellites do for us",
        p:["Weather satellites watch storms form. Earth-observation satellites track fires, crops and ice. Communication satellites carry phone calls and internet across oceans.",
           "They also watch the Sun, measure sea level, and relay data from Mars rovers back to Earth. Much of modern life quietly depends on machines you never see."],
        note:"Space junk is a growing problem: a fleck of paint travelling at 7 km per second can crack a window on the space station."
      }
    ],
    art:"satellite",
    activity:{
      type:"pick",
      title:"Get a position fix",
      hint:"Your phone needs a fix. Select <b>three</b> satellites that are in view."
    },
    quiz:[
      { q:"How many GPS satellites must your phone usually see to work out its position?",
        options:["At least four","One","Two","Twenty"],
        correct:0, hint:"Three narrows it down, and one more settles it.",
        explain:"Three satellites give two possible points; a fourth resolves which is correct and also checks the phone's clock." },
      { q:"What is special about geostationary orbit?",
        options:["The satellite takes 24 hours per lap, so it seems to hang still","It is the closest orbit to Earth","It is where the space station flies","It has no gravity"],
        correct:0, hint:"Match the orbit period to Earth's rotation.",
        explain:"At 35,786 km the orbital period equals one day, so the satellite stays above the same point on the ground — perfect for weather and TV." },
      { q:"Why do GPS satellites need atomic clocks?",
        options:["A tiny timing error would mean a huge position error","To keep them warm","To power the solar panels","To talk to each other"],
        correct:0, hint:"Light travels 300 metres in a millionth of a second.",
        explain:"Distance is measured from travel time, so even a billionth-of-a-second error shifts the answer. Atomic clocks keep that error tiny." }
    ],
    reward:{ label:"Signal Badge", icon:"📡" }
  },
  {
    id:12, hue:300, emoji:"🛏️", title:"Living in Zero Gravity",
    subtitle:"Sleeping, washing and staying strong when nothing stays put.",
    skill:"Microgravity life",
    intro:"A long stay in orbit changes your body. Astronauts train for months to keep their muscles, bones and balance working without the pull of gravity.",
    lessons:[
      {
        h:"Your body notices immediately",
        p:["Fluids drift towards the head, so faces look puffy and legs look thinner. The inner ear, which normally senses which way is down, gets confused — that is why many astronauts feel sick for the first day or two.",
           "After a few weeks the body adapts: it makes less blood, and the heart does not have to pump so hard against gravity."],
        note:"Astronauts grow about 3% taller in orbit because the discs in the spine expand without weight pressing them together."
      },
      {
        h:"Staying strong on purpose",
        p:["Without load, muscles shrink and bones lose minerals — roughly 1% of bone mass per month if nothing is done. So crews exercise about two hours a day on a treadmill, a bike and a resistance machine.",
           "The treadmill has a harness with bungee cords that pulls the runner down, because otherwise they would simply float off it."],
        note:"Exercise in orbit is a medical treatment, not a hobby. It is the main defence against weakened bones and muscles."
      },
      {
        h:"Everyday habits, rebuilt",
        p:["Astronauts wash with wet wipes and rinseless shampoo, because water will not run. Hair is cut over a vacuum hose so the clippings are captured.",
           "Sleeping bags are strapped to the wall, and crew members often tuck their arms in so they do not float up and wake them. There is no up or down, so any wall will do."],
        note:"Astronauts see about 16 sunrises a day, so the station keeps a strict schedule of lights and alarms to protect their sleep."
      }
    ],
    art:"zeroglife",
    activity:{
      type:"zerog",
      title:"Catch the drifting supplies",
      hint:"Tap <b>all five</b> floating items before they drift out of reach."
    },
    quiz:[
      { q:"Why do astronauts exercise about two hours a day in orbit?",
        options:["To stop bones and muscles weakening without gravity","To pass the time","To generate electricity","To stay warm"],
        correct:0, hint:"Think about what gravity normally does to your body.",
        explain:"Bones and muscles need load to stay strong. Without it they weaken quickly, so exercise is a medical requirement in orbit." },
      { q:"Why do astronauts grow slightly taller in space?",
        options:["The discs in the spine expand without weight pressing on them","They eat more food","The station stretches them","Gravity pulls them upward"],
        correct:0, hint:"Think about what squashes your spine on Earth.",
        explain:"Without gravity compressing the spine, the discs between the vertebrae expand, so astronauts can be about 3% taller." },
      { q:"How do astronauts wash in orbit?",
        options:["With wet wipes and rinseless shampoo","In a normal shower","By floating in a water bubble","They do not wash"],
        correct:0, hint:"Water does not run when there is no down.",
        explain:"Water forms floating blobs instead of flowing, so crews use wipes and rinseless products to stay clean." }
    ],
    reward:{ label:"Orbit Athlete", icon:"🛏️" }
  },
  {
    id:13, hue:250, emoji:"🔭", title:"Deep Space & Telescopes",
    subtitle:"Looking so far away that you see the past.",
    skill:"Astronomy",
    intro:"A telescope is a time machine. Because light takes time to travel, every distant object you see is shown as it was long ago.",
    lessons:[
      {
        h:"Bigger is better",
        p:["A telescope's job is to collect light. A wider mirror gathers more of it, which lets you see fainter objects, and a wider mirror also sharpens the image.",
           "That is why observatories are built on mountain tops, above much of the blurring atmosphere — and why the best telescope of all is the one in orbit."],
        note:"The James Webb Space Telescope's mirror is 6.5 metres across and made of 18 gold-coated hexagons that unfold after launch."
      },
      {
        h:"Looking back in time",
        p:["Light from the Sun takes 8 minutes to reach us, so you always see the Sun as it was 8 minutes ago. Light from the nearest star after the Sun takes about 4.2 years.",
           "Look at a galaxy 50 million light-years away and you are seeing it as it was 50 million years ago — before humans existed. The deepest images show galaxies whose light left them over 13 billion years ago."],
        note:"A light-year is a distance, not a time: about 9.5 trillion kilometres. It is simply how far light travels in one year."
      },
      {
        h:"Seeing the invisible",
        p:["Stars also shine in light our eyes cannot see. Infrared telescopes reveal warm dust and newborn stars hidden inside clouds, while radio telescopes pick up cold gas and even the faint echo of the Big Bang.",
           "Putting telescopes in space removes the atmosphere entirely, and lets them stay cold — which is essential for detecting faint infrared heat."],
        note:"Radio telescopes can be linked across continents to act like one giant dish thousands of kilometres wide."
      }
    ],
    art:"telescope",
    activity:{
      type:"focus",
      title:"Focus the telescope",
      hint:"Slide the focus until the distant galaxy becomes <b>sharp and clear</b>."
    },
    quiz:[
      { q:"Why is a bigger telescope mirror better?",
        options:["It collects more light and gives a sharper image","It is easier to build","It makes the stars move","It needs no maintenance"],
        correct:0, hint:"Think about what a telescope is really doing.",
        explain:"A wider mirror gathers more light, so fainter objects become visible, and it also improves the sharpness of the image." },
      { q:"When you look at a star 4.2 light-years away, what are you seeing?",
        options:["The star as it was 4.2 years ago","The star as it is right now","The star in the future","A reflection of the Sun"],
        correct:0, hint:"Light takes time to travel.",
        explain:"Light from that star has been travelling for 4.2 years, so you see it as it was then — a telescope is a time machine." },
      { q:"Why do infrared telescopes work better in space?",
        options:["The atmosphere blocks much infrared, and space is cold","Space is closer to the stars","There is more light in space","Gravity helps the mirror"],
        correct:0, hint:"Two reasons: one about the air, one about temperature.",
        explain:"Earth's atmosphere absorbs most infrared, and a warm telescope glows in infrared itself. Cold space removes both problems." }
    ],
    reward:{ label:"Deep Sky Lens", icon:"🔭" }
  },
  {
    id:14, hue:12, emoji:"🏕️", title:"Mars Colonization",
    subtitle:"What it would really take to live on another planet.",
    skill:"Colony planning",
    intro:"Mars is the most habitable world after Earth — and it is still trying to kill you. Thin air, deadly cold, no liquid water on the surface, and radiation from space.",
    lessons:[
      {
        h:"The journey and the landing",
        p:["Mars is 55 to 400 million kilometres away, depending on where the planets are. A crewed trip would take about seven months each way, and the crew would have to wait on Mars for over a year for the planets to line up for the return.",
           "Landing is the hard part: Mars has just enough atmosphere to burn you up but not enough to slow you down, so spacecraft need heat shields, parachutes and retro-rockets."],
        note:"Because of the launch window, a Mars mission is roughly a three-year round trip. There is no coming home early."
      },
      {
        h:"Staying alive there",
        p:["A colony would need airtight habitats, probably buried under soil or built from it, because Mars has almost no magnetic field and only a thin atmosphere to block radiation.",
           "Water ice exists under the surface and at the poles. Oxygen can be made from that ice by splitting it with electricity, and rocket fuel can be made from the carbon dioxide in the air."],
        note:"The MOXIE experiment on the Perseverance rover made oxygen from Martian air — a small but real proof that it can be done."
      },
      {
        h:"Growing food and staying sane",
        p:["Food would be grown indoors under LED light, in soil or in water with nutrients. Experiments on the space station have already grown lettuce, radishes and chillies in orbit.",
           "The hardest part may be people. A small crew, far from home, with a long communication delay, needs strong routines, privacy and clear roles. Teamwork is life support too."],
        note:"Radio signals take 4 to 24 minutes to travel one way between Earth and Mars, so a Mars crew cannot ask for help in an emergency."
      }
    ],
    art:"marsbase",
    activity:{
      type:"pick",
      title:"Stock the colony",
      hint:"Choose the <b>three</b> things a Mars base cannot survive without."
    },
    quiz:[
      { q:"Why is landing on Mars harder than landing on the Moon?",
        options:["Mars has enough air to heat you up but not enough to slow you down","Mars is closer to the Sun","Mars has stronger gravity than Earth","There is no gravity on Mars"],
        correct:0, hint:"It is a problem of having too little of something useful.",
        explain:"Mars' thin atmosphere creates fierce heating on entry but provides too little drag, so landers need heat shields, parachutes and rockets." },
      { q:"How could a Mars colony get oxygen?",
        options:["By splitting water ice or carbon dioxide with electricity","By importing it from Earth","By breathing the Martian air directly","By growing it in trees"],
        correct:0, hint:"Think about what oxygen can be extracted from.",
        explain:"Water ice can be split into hydrogen and oxygen, and carbon dioxide in the air can also be split. MOXIE proved this on Mars." },
      { q:"Why would a Mars colony need to be buried or shielded?",
        options:["Mars has almost no magnetic field or thick atmosphere to block radiation","To keep it tidy","To hide from aliens","Because it is too windy"],
        correct:0, hint:"Think about what protects us on Earth.",
        explain:"Without a strong magnetic field and thick air, radiation from space reaches the surface, so habitats need soil or other shielding." }
    ],
    reward:{ label:"Colony Founder", icon:"🏕️" }
  },
  {
    id:15, hue:45, emoji:"🎓", title:"Becoming an Astronaut",
    subtitle:"The last mission: how real astronauts are chosen and trained.",
    skill:"Graduation",
    intro:"You have flown every mission in the academy. Now the final question: what does it actually take to be chosen for a real spaceflight?",
    lessons:[
      {
        h:"Who gets picked",
        p:["Space agencies look for people who are calm under pressure, work well in a team, and can learn fast. Most astronauts are scientists, engineers, doctors or pilots, and many apply several times before being chosen.",
           "Physical fitness matters, but so does the ability to stay friendly and useful in a small crew for months. Astronauts are tested in teams, not just as individuals."],
        note:"The first astronauts were chosen partly because they were test pilots used to staying calm when things went wrong."
      },
      {
        h:"Two years of training",
        p:["New astronauts spend about two years learning before they are assigned to a flight: spacecraft systems, robotics, spacewalking in the water tank, survival training, and Russian or English if it is not their first language.",
           "They also fly jet aircraft to build quick decision-making, and they practise every emergency procedure until it is automatic."],
        note:"Astronauts keep training for their whole career. Every mission has new experiments and new hardware to learn."
      },
      {
        h:"What the job is really like",
        p:["A flight day is scheduled almost minute by minute: experiments, exercise, maintenance, meals, conferences with the ground, and a short window before sleep.",
           "The best part, astronauts often say, is looking out of the window. The hardest part is being away from family — and the first few days back on Earth, when gravity feels very heavy indeed."],
        note:"Astronauts describe seeing Earth from orbit as the 'overview effect': borders disappear and the atmosphere looks like a thin, fragile line."
      }
    ],
    art:"graduation",
    activity:{
      type:"comms",
      title:"Final board review",
      hint:"Answer the <b>three</b> board questions the way a real astronaut would."
    },
    quiz:[
      { q:"What do space agencies look for most in astronaut candidates?",
        options:["Calmness under pressure and strong teamwork","Being the tallest applicant","Having the loudest voice","Never making a mistake"],
        correct:0, hint:"Think about living in a small crew for months.",
        explain:"Technical skill can be taught. Agencies select for judgement, calm and the ability to work well with others in a confined crew." },
      { q:"Roughly how long is basic astronaut training before a first flight?",
        options:["About two years","About two weeks","About ten years","No training is needed"],
        correct:0, hint:"It is measured in years, not days.",
        explain:"Candidates spend around two years learning systems, robotics, spacewalks and survival skills before being assigned to a mission." },
      { q:"What is the 'overview effect' astronauts describe?",
        options:["Seeing Earth from orbit makes it look fragile and borderless","A problem with their eyesight","The feeling of being dizzy","A type of space suit"],
        correct:0, hint:"It is about how Earth looks from up there.",
        explain:"From orbit, national borders vanish and the atmosphere appears as a thin line, which many astronauts find deeply moving." }
    ],
    reward:{ label:"Academy Wings", icon:"🎓" }
  }
];

/* ---------------- ECONOMY ----------------
   Deliberately slow: a first-time mission pays 3 lesson stars + 3 quiz
   answers + a completion bonus, and nothing pays twice. Practice runs pay a
   small training stipend so a determined cadet can still grind towards the
   legendary tier, but the top items take a lot of flying.
   ------------------------------------------ */
const STAGE_BONUS = 15;
const QUIZ_POINTS = 4;
const LESSON_POINTS = 1;
const PLANET_POINTS = 2;
const PRACTICE_STIPEND = 10;

/* ---------------- RARITY ---------------- */
const RARITY = {
  common:    { label:"Common",    color:"#9fb0d4", glow:"rgba(159,176,212,.35)" },
  rare:      { label:"Rare",      color:"#4fe3ff", glow:"rgba(79,227,255,.45)" },
  epic:      { label:"Epic",      color:"#a99bff", glow:"rgba(169,155,255,.5)" },
  legendary: { label:"Legendary", color:"#ffc857", glow:"rgba(255,200,87,.55)" }
};
const RARITY_ORDER = ["common", "rare", "epic", "legendary"];

/* ---------------- OUTFIT SHOP ---------------- */
const SUITS = [
  { id:"suit_classic", name:"Cadet White",     price:0,    rarity:"common",    desc:"Standard issue. Crisp and clean.",        colors:{body:"#eef3ff", trim:"#4fe3ff", visor:"#2b3f66", accent:"#4fe3ff"} },
  { id:"suit_ember",   name:"Ember Orange",    price:30,   rarity:"common",    desc:"For pilots who like a warm glow.",        colors:{body:"#ff9d5c", trim:"#ffd9a8", visor:"#3a1c0a", accent:"#ffd9a8"} },
  { id:"suit_forest",  name:"Bio-Dome Green",  price:45,   rarity:"common",    desc:"Built for growing things in orbit.",      colors:{body:"#5ff0b6", trim:"#0d4a37", visor:"#063d2c", accent:"#0d4a37"} },
  { id:"suit_slate",   name:"Hangar Slate",    price:60,   rarity:"common",    desc:"Workshop grey. Hides the grease.",        colors:{body:"#8d9ab5", trim:"#2b3550", visor:"#141c30", accent:"#c3cfe8"} },
  { id:"suit_nebula",  name:"Nebula Violet",   price:180,  rarity:"rare",      desc:"Swirls of gas from a distant cloud.",     colors:{body:"#b39dff", trim:"#f0e8ff", visor:"#2a1d52", accent:"#f0e8ff"} },
  { id:"suit_solar",   name:"Solar Gold",      price:240,  rarity:"rare",      desc:"Polished panels, maximum shine.",         colors:{body:"#ffc857", trim:"#fff1c9", visor:"#4a3208", accent:"#fff1c9"} },
  { id:"suit_reef",    name:"Coral Reef",      price:280,  rarity:"rare",      desc:"Colours borrowed from a shallow sea.",    colors:{body:"#ff8fa8", trim:"#ffe3ec", visor:"#4a1024", accent:"#7ff0e0"} },
  { id:"suit_void",    name:"Deep Void",       price:520,  rarity:"epic",      desc:"For night-side operations only.",         colors:{body:"#2a3559", trim:"#6f7fd6", visor:"#080d1e", accent:"#6f7fd6"} },
  { id:"suit_plasma",  name:"Plasma Core",     price:640,  rarity:"epic",      desc:"Runs hot. Glows hotter.",                 colors:{body:"#ff5f8f", trim:"#ffd0e0", visor:"#3a0018", accent:"#ffd166"} },
  { id:"suit_aurora",  name:"Aurora Weave",    price:780,  rarity:"epic",      desc:"Woven from polar light.",                 colors:{body:"#5ff0b6", trim:"#a99bff", visor:"#062a3a", accent:"#4fe3ff"} },
  { id:"suit_eclipse", name:"Eclipse Chrome",  price:750,  rarity:"legendary", desc:"Mirror finish. Blinds the competition.",  colors:{body:"#dfe8ff", trim:"#8fa6d8", visor:"#0a0f1e", accent:"#ffffff"} },
  { id:"suit_supernova",name:"Supernova",      price:1600, rarity:"legendary", desc:"The last light of a dying star.",         colors:{body:"#ffb347", trim:"#fff3c4", visor:"#3a1200", accent:"#ff5f8f"} },
  { id:"suit_galaxy",  name:"Galaxy Print",    price:1800, rarity:"legendary", desc:"A whole spiral arm, printed on fabric.",  colors:{body:"#3b2a6b", trim:"#ffc857", visor:"#0b0620", accent:"#a99bff"} }
];
const HELMETS = [
  { id:"helm_bubble",  name:"Standard Bubble",  price:0,    rarity:"common",    desc:"Clear, roomy, reliable." },
  { id:"helm_gold",    name:"Gold Visor",       price:40,   rarity:"common",    desc:"Blocks glare, looks legendary." },
  { id:"helm_horn",    name:"Signal Antenna",   price:70,   rarity:"common",    desc:"A little dish, a lot of style." },
  { id:"helm_star",    name:"Star Crest",       price:150,  rarity:"rare",      desc:"For cadets who shine." },
  { id:"helm_ring",    name:"Ringed Halo",      price:260,  rarity:"rare",      desc:"A slow orbit around your head." },
  { id:"helm_dome",    name:"Survey Dome",      price:340,  rarity:"rare",      desc:"Extra glass, extra visibility." },
  { id:"helm_reactor", name:"Reactor Cowl",     price:600,  rarity:"epic",      desc:"Vents steam when you think hard." },
  { id:"helm_crystal", name:"Crystal Shell",    price:820,  rarity:"epic",      desc:"Grown, not built. Sings faintly." },
  { id:"helm_crown",   name:"Commander Crown",  price:900,  rarity:"legendary", desc:"Reserved for the very best." },
  { id:"helm_blackhole",name:"Event Horizon",   price:1700, rarity:"legendary", desc:"Light bends politely around it." }
];
const VISORS = [
  { id:"visor_clear",  name:"Clear Glass",      price:0,    rarity:"common",    desc:"See everything, hide nothing.",   tint:"#2b3f66", alpha:.92 },
  { id:"visor_smoke",  name:"Smoke Tint",       price:35,   rarity:"common",    desc:"Cool, calm, unreadable.",         tint:"#1a1f2e", alpha:.95 },
  { id:"visor_amber",  name:"Amber Filter",     price:80,   rarity:"common",    desc:"Cuts glare on the day side.",     tint:"#c98a1e", alpha:.9 },
  { id:"visor_rose",   name:"Rose Quartz",      price:190,  rarity:"rare",      desc:"Everything looks friendlier.",    tint:"#e07a9c", alpha:.88 },
  { id:"visor_ice",    name:"Ice Blue",         price:230,  rarity:"rare",      desc:"Frosted at the edges.",           tint:"#7fd8ff", alpha:.86 },
  { id:"visor_emerald",name:"Emerald Scan",     price:300,  rarity:"rare",      desc:"Adds a faint targeting grid.",    tint:"#2fd08a", alpha:.88 },
  { id:"visor_void",   name:"Void Black",       price:560,  rarity:"epic",      desc:"Nothing gets in. Nothing.",       tint:"#05070f", alpha:.98 },
  { id:"visor_prism",  name:"Prism Split",      price:760,  rarity:"epic",      desc:"Splits light into a rainbow.",    tint:"#a99bff", alpha:.85 },
  { id:"visor_solar",  name:"Solar Flare",      price:850,  rarity:"legendary", desc:"Looks like a small sun.",         tint:"#ffb347", alpha:.9 },
  { id:"visor_nebula", name:"Nebula Glass",     price:1650, rarity:"legendary", desc:"A galaxy trapped in the glass.",  tint:"#6b3fd0", alpha:.9 }
];
const HATS = [
  { id:"hat_none",     name:"Bare Helmet",      price:0,    rarity:"common",    desc:"No hat. All business." },
  { id:"hat_cap",      name:"Flight Cap",       price:25,   rarity:"common",    desc:"A simple pilot's cap." },
  { id:"hat_beanie",   name:"Thermal Beanie",   price:55,   rarity:"common",    desc:"For the cold side of the orbit." },
  { id:"hat_headset",  name:"Comms Headset",    price:120,  rarity:"rare",      desc:"Always on the right channel." },
  { id:"hat_tophat",   name:"Formal Top Hat",   price:210,  rarity:"rare",      desc:"For award ceremonies only." },
  { id:"hat_antennae", name:"Bug Antennae",     price:290,  rarity:"rare",      desc:"Two little feelers. Very cute." },
  { id:"hat_mohawk",   name:"Plasma Mohawk",    price:580,  rarity:"epic",      desc:"Hair made of excited gas." },
  { id:"hat_wizard",   name:"Star Wizard Hat",  price:740,  rarity:"epic",      desc:"Slightly magical. Mostly pointy." },
  { id:"hat_halo",     name:"Saintly Halo",     price:700,  rarity:"legendary", desc:"Floats. Glows. Judges you." },
  { id:"hat_dragon",   name:"Dragon Crest",     price:1550, rarity:"legendary", desc:"A tiny dragon, permanently napping." }
];
const BACKPACKS = [
  { id:"pack_std",     name:"Standard Pack",    price:0,    rarity:"common",    desc:"Two tanks. Does the job." },
  { id:"pack_slim",    name:"Slimline Pack",    price:40,   rarity:"common",    desc:"Low profile, high efficiency." },
  { id:"pack_twin",    name:"Twin Thruster",    price:110,  rarity:"rare",      desc:"Two nozzles for fine control." },
  { id:"pack_solar",   name:"Solar Wing Pack",  price:250,  rarity:"rare",      desc:"Folding panels on your back." },
  { id:"pack_cargo",   name:"Cargo Hauler",     price:330,  rarity:"rare",      desc:"Carries the samples home." },
  { id:"pack_jet",     name:"Jet Sprint",       price:620,  rarity:"epic",      desc:"Short bursts, big speed." },
  { id:"pack_reactor", name:"Fusion Backpack",  price:800,  rarity:"epic",      desc:"Powers a small town. Warm." },
  { id:"pack_wings",   name:"Ion Wings",        price:1400, rarity:"legendary", desc:"Glowing wings of charged gas." },
  { id:"pack_blackhole",name:"Singularity Pack",price:1750, rarity:"legendary", desc:"Do not open the little door." }
];
const BOOTS = [
  { id:"boot_std",     name:"Standard Boots",   price:0,    rarity:"common",    desc:"Magnetic soles. Grippy." },
  { id:"boot_red",     name:"Red Racer Boots",  price:30,   rarity:"common",    desc:"Go faster. Probably." },
  { id:"boot_steel",   name:"Steel Toe Caps",   price:90,   rarity:"rare",      desc:"For kicking asteroids." },
  { id:"boot_spring",  name:"Spring Heels",     price:200,  rarity:"rare",      desc:"Bouncy in low gravity." },
  { id:"boot_ice",     name:"Ice Grippers",     price:280,  rarity:"rare",      desc:"Tested on Europa. Allegedly." },
  { id:"boot_rocket",  name:"Rocket Boots",     price:600,  rarity:"epic",      desc:"Small thrusters in each heel." },
  { id:"boot_plasma",  name:"Plasma Striders",  price:780,  rarity:"epic",      desc:"Leaves a glowing footprint." },
  { id:"boot_gravity", name:"Gravity Boots",    price:950,  rarity:"legendary", desc:"Choose your own weight." }
];
const GLOVES = [
  { id:"glove_std",    name:"Standard Gloves",  price:0,    rarity:"common",    desc:"Warm, tough, reliable." },
  { id:"glove_blue",   name:"Blue Grips",       price:35,   rarity:"common",    desc:"Extra sticky fingertips." },
  { id:"glove_armor",  name:"Armoured Gauntlets",price:130, rarity:"rare",      desc:"Plated knuckles." },
  { id:"glove_heater", name:"Heated Gloves",    price:240,  rarity:"rare",      desc:"Toasty at -150 degrees." },
  { id:"glove_tool",   name:"Toolmaster Gloves",price:320,  rarity:"rare",      desc:"A socket in every finger." },
  { id:"glove_plasma", name:"Plasma Touch",     price:640,  rarity:"epic",      desc:"Crackles when you wave." },
  { id:"glove_gauntlet",name:"Infinity Gauntlet",price:820, rarity:"epic",      desc:"Six empty sockets. For now." },
  { id:"glove_star",   name:"Stardust Gloves",  price:1450, rarity:"legendary", desc:"Trails glitter as you work." }
];
const CAPES = [
  { id:"cape_none",    name:"No Cape",          price:0,    rarity:"common",    desc:"Streamlined and sensible." },
  { id:"cape_short",   name:"Short Cape",       price:60,   rarity:"common",    desc:"A modest bit of drama." },
  { id:"cape_hero",    name:"Hero Cape",        price:220,  rarity:"rare",      desc:"Billows even without wind." },
  { id:"cape_thermal", name:"Thermal Blanket",  price:300,  rarity:"rare",      desc:"Survival foil, styled up." },
  { id:"cape_aurora",  name:"Aurora Cloak",     price:660,  rarity:"epic",      desc:"Shimmers in six colours." },
  { id:"cape_void",    name:"Void Shroud",      price:840,  rarity:"epic",      desc:"Absorbs light. Slightly rude." },
  { id:"cape_comet",   name:"Comet Tail",       price:1500, rarity:"legendary", desc:"A tail of ice and dust." }
];
const PETS = [
  { id:"pet_none",     name:"No Companion",     price:0,    rarity:"common",    desc:"Flying solo." },
  { id:"pet_orb",      name:"Helper Orb",       price:80,   rarity:"common",    desc:"A little drone that beeps." },
  { id:"pet_star",     name:"Star Sprite",      price:190,  rarity:"rare",      desc:"A tiny star that follows you." },
  { id:"pet_moon",     name:"Moon Moth",        price:270,  rarity:"rare",      desc:"Wings like crescent moons." },
  { id:"pet_rover",    name:"Pocket Rover",     price:350,  rarity:"rare",      desc:"Six wheels, endless curiosity." },
  { id:"pet_fox",      name:"Comet Fox",        price:700,  rarity:"epic",      desc:"Leaves a trail of sparks." },
  { id:"pet_alien",    name:"Friendly Alien",   price:880,  rarity:"epic",      desc:"Waves with four arms." },
  { id:"pet_dragon",   name:"Baby Star Dragon", price:1600, rarity:"legendary", desc:"Breathes harmless sparkles." },
  { id:"pet_phoenix",  name:"Solar Phoenix",    price:1900, rarity:"legendary", desc:"Reborn every orbit." }
];
const BADGES = [
  { id:"badge_none",   name:"No badge",         price:0,    rarity:"common",    desc:"Clean chest plate." },
  { id:"badge_rocket", name:"Rocket Pin",       price:20,   rarity:"common",    desc:"You earned your launch." },
  { id:"badge_planet", name:"Ringed Planet Pin",price:70,   rarity:"common",    desc:"For planet hunters." },
  { id:"badge_comet",  name:"Comet Pin",        price:160,  rarity:"rare",      desc:"Fast, bright, unstoppable." },
  { id:"badge_wings",  name:"Pilot Wings",      price:250,  rarity:"rare",      desc:"Awarded after your first solo." },
  { id:"badge_shield", name:"Storm Shield",     price:330,  rarity:"rare",      desc:"Survived a solar storm." },
  { id:"badge_flame",  name:"Engine Flame",     price:620,  rarity:"epic",      desc:"For the engineers." },
  { id:"badge_eye",    name:"Deep Sky Eye",     price:790,  rarity:"epic",      desc:"You looked back in time." },
  { id:"badge_laurel", name:"Laurel of Command",price:800,  rarity:"legendary", desc:"Given, never bought. Officially." },
  { id:"badge_galaxy", name:"Galaxy Seal",      price:1700, rarity:"legendary", desc:"A whole galaxy on your chest." }
];
const TRAILS = [
  { id:"trail_none",   name:"No Trail",         price:0,    rarity:"common",    desc:"Clean and quiet." },
  { id:"trail_dust",   name:"Moon Dust",        price:50,   rarity:"common",    desc:"A soft grey puff." },
  { id:"trail_spark",  name:"Spark Shower",     price:140,  rarity:"rare",      desc:"Little orange sparks." },
  { id:"trail_bubble", name:"Bubble Stream",    price:230,  rarity:"rare",      desc:"Floating soap bubbles." },
  { id:"trail_star",   name:"Stardust",         price:310,  rarity:"rare",      desc:"A trail of tiny stars." },
  { id:"trail_flame",  name:"Rocket Flame",     price:650,  rarity:"epic",      desc:"You are the exhaust now." },
  { id:"trail_rainbow",name:"Rainbow Ribbon",   price:810,  rarity:"epic",      desc:"Six colours, always behind." },
  { id:"trail_aurora", name:"Aurora Veil",      price:1450, rarity:"legendary", desc:"Green and violet light." },
  { id:"trail_void",   name:"Void Ripple",      price:1850, rarity:"legendary", desc:"Space bends as you pass." }
];
const COSMETIC_TABS = [
  { key:"suit",     label:"Suits",     icon:"🧑‍🚀", list:SUITS },
  { key:"helmet",   label:"Helmets",   icon:"🪖", list:HELMETS },
  { key:"visor",    label:"Visors",    icon:"🕶️", list:VISORS },
  { key:"hat",      label:"Hats",      icon:"🎩", list:HATS },
  { key:"backpack", label:"Packs",     icon:"🎒", list:BACKPACKS },
  { key:"boots",    label:"Boots",     icon:"🥾", list:BOOTS },
  { key:"gloves",   label:"Gloves",    icon:"🧤", list:GLOVES },
  { key:"cape",     label:"Capes",     icon:"🦸", list:CAPES },
  { key:"pet",      label:"Pets",      icon:"🐾", list:PETS },
  { key:"badge",    label:"Badges",    icon:"🎖️", list:BADGES },
  { key:"trail",    label:"Trails",    icon:"✨", list:TRAILS }
];

const ACHIEVEMENTS = [
  { id:"first_mission", icon:"🚀", name:"First Launch",     desc:"Finish your first mission.",              test:s=>s.completed.length>=1 },
  { id:"half_way",      icon:"🌗", name:"Halfway Cadet",    desc:"Finish 8 of the 15 missions.",            test:s=>s.completed.length>=8 },
  { id:"graduate",      icon:"🎓", name:"Academy Graduate", desc:"Finish all 15 missions.",                 test:s=>s.completed.length>=15 },
  { id:"planet_hunter", icon:"🪐", name:"Planet Hunter",    desc:"Open the file for all 8 planets.",        test:s=>PLANETS.every(p=>s.planetsSeen[p.id]) },
  { id:"sun_gazer",     icon:"☀️", name:"Sun Gazer",        desc:"Read about the Sun.",                     test:s=>!!s.planetsSeen.sun },
  { id:"perfect",       icon:"💯", name:"Perfect Mission",  desc:"Get every question right in one mission.", test:s=>Object.keys(s.stageStars).some(k=>s.stageStars[k]===3) },
  { id:"shopper",       icon:"👕", name:"Style Upgrade",    desc:"Buy your first outfit.",                   test:s=>s.owned.length>=2 },
  { id:"collector",     icon:"🧳", name:"Wardrobe Builder", desc:"Own 15 different items.",                  test:s=>s.owned.length>=15 },
  { id:"fashionista",   icon:"💎", name:"Fashion Icon",     desc:"Own 40 different items.",                  test:s=>s.owned.length>=40 },
  { id:"legendary",     icon:"👑", name:"Legendary Taste",  desc:"Own any Legendary item.",                  test:s=>s.owned.some(id=>{const f=Shop.find(id);return f&&f.item.rarity==="legendary";}) },
  { id:"rich",          icon:"💰", name:"Star Collector",   desc:"Hold 500 stars at once.",                  test:s=>s.stars>=500 },
  { id:"tycoon",        icon:"🏦", name:"Star Tycoon",      desc:"Earn 2,000 stars all-time.",               test:s=>s.earnedTotal>=2000 },
  { id:"curious",       icon:"💡", name:"Curious Mind",     desc:"Ask Astro ten questions.",                 test:s=>s.pipAsked>=10 },
  { id:"listener",      icon:"🔊", name:"Good Listener",    desc:"Turn on Astro's voice.",                     test:s=>!!s.settings.voice }
];
/*@@END_JS_DATA@@*/
/* ============================================================
   2. ILLUSTRATION ENGINE — hand-built SVG art
   ============================================================ */
let __uid = 0;
const uid = p => p + "-" + (++__uid);

const ART = (() => {

  /* ---- shared helpers ---- */
  function sphere(id, base, light, dark, size) {
    return `
      <defs>
        <radialGradient id="${id}-g" cx="34%" cy="28%" r="78%">
          <stop offset="0%" stop-color="${light}"/>
          <stop offset="52%" stop-color="${base}"/>
          <stop offset="100%" stop-color="${dark}"/>
        </radialGradient>
        <radialGradient id="${id}-sh" cx="72%" cy="76%" r="72%">
          <stop offset="0%" stop-color="#000" stop-opacity="0"/>
          <stop offset="58%" stop-color="#000" stop-opacity=".12"/>
          <stop offset="100%" stop-color="#000" stop-opacity=".62"/>
        </radialGradient>
        <clipPath id="${id}-c"><circle cx="100" cy="100" r="86"/></clipPath>
      </defs>
      <circle cx="100" cy="100" r="86" fill="url(#${id}-g)"/>`;
  }

  function shade(id) {
    return `<circle cx="100" cy="100" r="86" fill="url(#${id}-sh)" clip-path="url(#${id}-c)"/>`;
  }

  function glowRing(id, color, w) {
    return `<circle cx="100" cy="100" r="${86 + (w || 5)}" fill="none" stroke="${color}" stroke-opacity=".28" stroke-width="1.5"/>`;
  }

  function craters(id, list) {
    return `<g clip-path="url(#${id}-c)" opacity=".5">` + list.map(c =>
      `<ellipse cx="${c[0]}" cy="${c[1]}" rx="${c[2]}" ry="${c[2] * .78}" fill="#000" opacity=".18"/>
       <ellipse cx="${c[0] - c[2] * .12}" cy="${c[1] - c[2] * .16}" rx="${c[2] * .82}" ry="${c[2] * .62}" fill="#fff" opacity=".10"/>`
    ).join("") + `</g>`;
  }

  const PLANET_ART = {
    mercury: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Mercury, a grey cratered planet">
      ${sphere(id, "#9c968b", "#e6e0d3", "#4d4941")}
      <g clip-path="url(#${id}-c)">
        <path d="M14 78c30-10 62-4 88 10s56 14 84 4v-70H14Z" fill="#fff" opacity=".07"/>
        <path d="M14 132c34 8 58 26 82 40s64 22 90 12v50H14Z" fill="#000" opacity=".10"/>
      </g>
      ${craters(id, [[66,62,15],[128,54,9],[104,112,19],[56,128,8],[143,106,12],[84,158,7],[150,150,6],[44,94,6]])}
      ${shade(id)}${glowRing(id, "#b9b3a8", 6)}</svg>`,

    venus: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Venus, a creamy yellow planet with swirls">
      ${sphere(id, "#d9b06a", "#ffeec4", "#8a6320")}
      <g clip-path="url(#${id}-c)" opacity=".45">
        <path d="M6 66c34-16 60 6 92 2s54-20 96-8" stroke="#fff6d8" stroke-width="9" fill="none" stroke-linecap="round" opacity=".55"/>
        <path d="M0 96c40-14 64 10 98 4s58-16 100-4" stroke="#fff6d8" stroke-width="7" fill="none" stroke-linecap="round" opacity=".4"/>
        <path d="M4 126c36-12 62 12 96 6s56-14 98-2" stroke="#8a6320" stroke-width="8" fill="none" stroke-linecap="round" opacity=".3"/>
        <path d="M10 42c30-10 54 8 84 4s52-14 90-6" stroke="#fff6d8" stroke-width="5" fill="none" stroke-linecap="round" opacity=".3"/>
      </g>
      ${shade(id)}${glowRing(id, "#ffd98a", 7)}</svg>`,

    earth: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Earth, a blue planet with green continents and white clouds">
      <defs>
        <radialGradient id="${id}-o" cx="35%" cy="30%" r="72%">
          <stop offset="0%" stop-color="#8fd7ff"/><stop offset="55%" stop-color="#2f74d0"/><stop offset="100%" stop-color="#0a2a63"/>
        </radialGradient>
        <clipPath id="${id}-c"><circle cx="100" cy="100" r="86"/></clipPath>
      </defs>
      <circle cx="100" cy="100" r="86" fill="url(#${id}-o)"/>
      <g clip-path="url(#${id}-c)">
        <path d="M52 44c14-8 30-4 34 8s-4 22-14 26-24 0-28-10 2-18 8-24Z" fill="#4fbf7a"/>
        <path d="M40 96c18-6 30 4 32 16s-8 30-22 30-22-14-20-26 2-16 10-20Z" fill="#3fa869"/>
        <path d="M96 42c22-6 40 6 44 18s-10 18-24 16-28-10-28-20 2-12 8-14Z" fill="#54c47f"/>
        <path d="M108 88c16-4 34 4 38 16s-8 24-24 26-28-8-30-20 6-18 16-22Z" fill="#469f66"/>
        <path d="M140 132c10-2 18 4 16 12s-12 12-20 8-8-12-4-16 6-4 8-4Z" fill="#4bb374"/>
        <path d="M30 140c10-2 16 4 14 10s-12 8-18 4-4-10 4-14Z" fill="#54c47f"/>
        <path d="M44 60c22-8 52-4 74 4" stroke="#fff" stroke-width="10" fill="none" opacity=".55" stroke-linecap="round"/>
        <path d="M30 112c26 6 48-4 74-2s42 10 66 4" stroke="#fff" stroke-width="9" fill="none" opacity=".45" stroke-linecap="round"/>
        <path d="M64 160c20-6 42 0 60 6" stroke="#fff" stroke-width="8" fill="none" opacity=".4" stroke-linecap="round"/>
        <circle cx="100" cy="14" r="26" fill="#eaf6ff" opacity=".5"/>
        <circle cx="100" cy="186" r="26" fill="#eaf6ff" opacity=".45"/>
      </g>
      <circle cx="100" cy="100" r="86" fill="url(#${id}-o)" opacity=".18"/>
      <circle cx="100" cy="100" r="86" fill="none" stroke="#a9e4ff" stroke-opacity=".6" stroke-width="2"/>
      <circle cx="100" cy="100" r="91" fill="none" stroke="#6fd0ff" stroke-opacity=".28" stroke-width="4"/>
      <ellipse cx="68" cy="58" rx="26" ry="18" fill="#fff" opacity=".13" transform="rotate(-20 68 58)"/>
      ${shade(id)}</svg>`,

    mars: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Mars, a rust-red planet with polar caps">
      ${sphere(id, "#c2572c", "#f2a074", "#5c1f0c")}
      <g clip-path="url(#${id}-c)">
        <path d="M18 118c26-10 44 6 66 2s38-16 60-10 30 14 38 10v70H18Z" fill="#8a3313" opacity=".35"/>
        <path d="M52 88c18-6 34 2 44 10s-4 18-18 18-32-8-34-16 2-10 8-12Z" fill="#8a3313" opacity=".3"/>
        <path d="M126 62c14-4 24 2 26 10s-10 12-22 10-16-8-14-12 6-8 10-8Z" fill="#8a3313" opacity=".3"/>
        <ellipse cx="100" cy="18" rx="40" ry="16" fill="#fff" opacity=".78"/>
        <ellipse cx="100" cy="184" rx="34" ry="13" fill="#fff" opacity=".7"/>
      </g>
      <g clip-path="url(#${id}-c)" opacity=".35">
        <path d="M0 74c40-6 70 4 100 0s60-8 100-2" stroke="#ffd0a8" stroke-width="4" fill="none" opacity=".5"/>
        <path d="M0 144c36 4 66-6 100-2s62 8 100 2" stroke="#ffd0a8" stroke-width="3" fill="none" opacity=".4"/>
      </g>
      ${shade(id)}${glowRing(id, "#ff9a66", 7)}</svg>`,

    jupiter: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Jupiter, a banded gas giant with a great red spot">
      ${sphere(id, "#d99b63", "#ffe2b6", "#7d4a20")}
      <g clip-path="url(#${id}-c)">
        <rect x="0" y="30" width="200" height="13" fill="#b8763f" opacity=".55"/>
        <rect x="0" y="52" width="200" height="8" fill="#f4d7ae" opacity=".55"/>
        <rect x="0" y="68" width="200" height="16" fill="#c98549" opacity=".5"/>
        <rect x="0" y="94" width="200" height="6" fill="#f6dfbc" opacity=".5"/>
        <rect x="0" y="108" width="200" height="20" fill="#b4733c" opacity=".5"/>
        <rect x="0" y="136" width="200" height="9" fill="#f0d4a8" opacity=".45"/>
        <rect x="0" y="152" width="200" height="14" fill="#a86233" opacity=".4"/>
        <ellipse cx="128" cy="122" rx="30" ry="15" fill="#c0402a" opacity=".85"/>
        <ellipse cx="128" cy="122" rx="30" ry="15" fill="none" stroke="#f0a07a" stroke-width="2" opacity=".7"/>
        <ellipse cx="122" cy="119" rx="13" ry="6" fill="#e87a56" opacity=".8"/>
        <path d="M0 44c30 4 60-2 90 0s60 6 110 0" stroke="#fff" stroke-width="2" fill="none" opacity=".18"/>
      </g>
      ${shade(id)}${glowRing(id, "#ffc98a", 7)}</svg>`,

    saturn: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Saturn, a pale gold planet with wide rings">
      <defs>
        <radialGradient id="${id}-g" cx="34%" cy="28%" r="78%">
          <stop offset="0%" stop-color="#fff5d6"/><stop offset="55%" stop-color="#e3c187"/><stop offset="100%" stop-color="#8c6a33"/>
        </radialGradient>
        <clipPath id="${id}-c"><circle cx="100" cy="100" r="66"/></clipPath>
        <radialGradient id="${id}-sh" cx="72%" cy="76%" r="72%">
          <stop offset="0%" stop-color="#000" stop-opacity="0"/>
          <stop offset="58%" stop-color="#000" stop-opacity=".10"/>
          <stop offset="100%" stop-color="#000" stop-opacity=".5"/>
        </radialGradient>
        <linearGradient id="${id}-r" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#c9a464" stop-opacity=".15"/>
          <stop offset="18%" stop-color="#f6e3b8" stop-opacity=".85"/>
          <stop offset="42%" stop-color="#d6b276" stop-opacity=".55"/>
          <stop offset="55%" stop-color="#f8ecc9" stop-opacity=".2"/>
          <stop offset="68%" stop-color="#d6b276" stop-opacity=".6"/>
          <stop offset="88%" stop-color="#f6e3b8" stop-opacity=".8"/>
          <stop offset="100%" stop-color="#c9a464" stop-opacity=".12"/>
        </linearGradient>
      </defs>
      <g transform="rotate(-16 100 100)">
        <ellipse cx="100" cy="100" rx="96" ry="30" fill="none" stroke="url(#${id}-r)" stroke-width="17"/>
        <ellipse cx="100" cy="100" rx="96" ry="30" fill="none" stroke="#fff8e2" stroke-opacity=".45" stroke-width="1.2"/>
        <circle cx="100" cy="100" r="66" fill="url(#${id}-g)"/>
        <g clip-path="url(#${id}-c)">
          <rect x="0" y="70" width="200" height="6" fill="#b98f4f" opacity=".35"/>
          <rect x="0" y="90" width="200" height="5" fill="#b98f4f" opacity=".28"/>
          <rect x="0" y="112" width="200" height="7" fill="#b98f4f" opacity=".3"/>
          <path d="M0 60c40 6 80-2 120 0s58 4 80 0" stroke="#fff6dc" stroke-width="3" fill="none" opacity=".3"/>
        </g>
        <circle cx="100" cy="100" r="66" fill="url(#${id}-sh)" clip-path="url(#${id}-c)"/>
        <ellipse cx="100" cy="100" rx="96" ry="30" fill="none" stroke="url(#${id}-r)" stroke-width="8" opacity=".9"
                 stroke-dasharray="300" stroke-dashoffset="0" clip-path="none"/>
        <path d="M4 100a96 30 0 0 0 192 0" fill="none" stroke="url(#${id}-r)" stroke-width="16"/>
        <path d="M4 100a96 30 0 0 0 192 0" fill="none" stroke="#fff8e2" stroke-opacity=".3" stroke-width="1"/>
      </g></svg>`,

    uranus: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Uranus, a pale cyan ice giant tilted on its side">
      <defs>
        <radialGradient id="${id}-g" cx="34%" cy="30%" r="76%">
          <stop offset="0%" stop-color="#e2fbff"/><stop offset="52%" stop-color="#8fdfe8"/><stop offset="100%" stop-color="#2d7d8d"/>
        </radialGradient>
        <clipPath id="${id}-c"><circle cx="100" cy="100" r="76"/></clipPath>
        <radialGradient id="${id}-sh" cx="72%" cy="76%" r="72%">
          <stop offset="0%" stop-color="#000" stop-opacity="0"/>
          <stop offset="58%" stop-color="#000" stop-opacity=".10"/>
          <stop offset="100%" stop-color="#000" stop-opacity=".45"/>
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="100" rx="94" ry="13" fill="none" stroke="#bdf2f8" stroke-opacity=".35" stroke-width="3" transform="rotate(-72 100 100)"/>
      <circle cx="100" cy="100" r="76" fill="url(#${id}-g)"/>
      <g clip-path="url(#${id}-c)" opacity=".3">
        <rect x="0" y="64" width="200" height="8" fill="#5ec3d2"/>
        <rect x="0" y="104" width="200" height="10" fill="#5ec3d2"/>
        <rect x="0" y="140" width="200" height="7" fill="#5ec3d2"/>
      </g>
      <circle cx="100" cy="100" r="76" fill="url(#${id}-sh)" clip-path="url(#${id}-c)"/>
      <circle cx="100" cy="100" r="76" fill="none" stroke="#cff8ff" stroke-opacity=".5" stroke-width="2"/>
      <circle cx="100" cy="100" r="82" fill="none" stroke="#a8e6ef" stroke-opacity=".22" stroke-width="5"/></svg>`,

    neptune: id => `<svg viewBox="0 0 200 200" role="img" aria-label="Neptune, a deep blue planet with dark storms">
      ${sphere(id, "#3a63d8", "#8fb4ff", "#0d1f63")}
      <g clip-path="url(#${id}-c)">
        <rect x="0" y="48" width="200" height="10" fill="#2a4bb0" opacity=".45"/>
        <rect x="0" y="78" width="200" height="7" fill="#1c3a94" opacity=".4"/>
        <rect x="0" y="128" width="200" height="12" fill="#25459f" opacity=".4"/>
        <ellipse cx="76" cy="108" rx="26" ry="13" fill="#16296e" opacity=".65"/>
        <ellipse cx="76" cy="108" rx="26" ry="13" fill="none" stroke="#7fa8ff" stroke-width="1.6" opacity=".35"/>
        <path d="M20 150c26-6 44 2 60 0" stroke="#dceaff" stroke-width="3" fill="none" opacity=".35"/>
        <path d="M118 60c18-4 34 0 44 2" stroke="#dceaff" stroke-width="2.5" fill="none" opacity=".3"/>
      </g>
      ${shade(id)}${glowRing(id, "#7fa8ff", 7)}</svg>`,

    sun: id => `<svg viewBox="0 0 200 200" role="img" aria-label="The Sun, a glowing ball of hot gas">
      <defs>
        <radialGradient id="${id}-g" cx="42%" cy="38%" r="62%">
          <stop offset="0%" stop-color="#fffdf0"/><stop offset="45%" stop-color="#ffd257"/><stop offset="82%" stop-color="#ff8c1a"/><stop offset="100%" stop-color="#e2551a"/>
        </radialGradient>
        <radialGradient id="${id}-h" cx="50%" cy="50%" r="50%">
          <stop offset="55%" stop-color="#ffb347" stop-opacity=".55"/><stop offset="100%" stop-color="#ffb347" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <circle cx="100" cy="100" r="96" fill="url(#${id}-h)"/>
      <g opacity=".55">
        <circle cx="100" cy="100" r="86" fill="none" stroke="#ffd257" stroke-width="2" stroke-dasharray="6 8"/>
      </g>
      <circle cx="100" cy="100" r="64" fill="url(#${id}-g)"/>
      <g opacity=".35">
        <ellipse cx="78" cy="86" rx="16" ry="10" fill="#fff8d8"/>
        <ellipse cx="122" cy="118" rx="12" ry="8" fill="#e2551a" opacity=".5"/>
        <ellipse cx="112" cy="72" rx="9" ry="6" fill="#fff8d8"/>
      </g>
      <circle cx="100" cy="100" r="64" fill="none" stroke="#fff3c4" stroke-opacity=".55" stroke-width="2"/></svg>`,

    moon: id => `<svg viewBox="0 0 200 200" role="img" aria-label="The Moon, a grey cratered world">
      ${sphere(id, "#b9bccb", "#f2f4ff", "#585d72")}
      ${craters(id, [[70,66,17],[126,84,11],[92,126,20],[48,110,9],[146,132,8],[108,52,7],[62,158,6],[152,52,6]])}
      <g clip-path="url(#${id}-c)" opacity=".25">
        <ellipse cx="118" cy="112" rx="40" ry="30" fill="#2a2f42" opacity=".35"/>
        <ellipse cx="54" cy="72" rx="22" ry="18" fill="#2a2f42" opacity=".3"/>
      </g>
      ${shade(id)}${glowRing(id, "#dfe4ff", 6)}</svg>`
  };

  function planet(spec, size) {
    const id = uid(spec.art);
    const svg = (PLANET_ART[spec.art] || PLANET_ART.earth)(id);
    return svg.replace("<svg ", '<svg width="100%" height="100%" preserveAspectRatio="xMidYMid meet" ');
  }

  /* ---- mission lesson illustrations ---- */
  const SCENES = {
    constellation: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="The Big Dipper constellation drawn across the night sky">
        <defs>
          <radialGradient id="sc-bg" cx="50%" cy="20%" r="80%">
            <stop offset="0%" stop-color="#16224a"/><stop offset="100%" stop-color="#070c1c"/>
          </radialGradient>
          <filter id="sc-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#sc-bg)"/>
        <g fill="#7d90c4" opacity=".7">
          <circle cx="34" cy="42" r="1.4"/><circle cx="92" cy="22" r="1"/><circle cx="170" cy="16" r="1.2"/>
          <circle cx="248" cy="30" r="1"/><circle cx="322" cy="18" r="1.4"/><circle cx="368" cy="58" r="1"/>
          <circle cx="52" cy="120" r="1"/><circle cx="20" cy="196" r="1.3"/><circle cx="390" cy="140" r="1"/>
          <circle cx="330" cy="220" r="1.2"/><circle cx="120" cy="238" r="1"/><circle cx="212" cy="226" r="1.1"/>
        </g>
        <g stroke="#4fe3ff" stroke-width="2" stroke-opacity=".65" stroke-linecap="round" filter="url(#sc-glow)" fill="none">
          <path d="M96 96 L152 74 L212 92 L214 148 L154 168 L96 156 Z"/>
          <path d="M96 96 L60 132"/>
        </g>
        <g fill="#eaf6ff" filter="url(#sc-glow)">
          <circle cx="96" cy="96" r="5.5"/><circle cx="152" cy="74" r="4.6"/><circle cx="212" cy="92" r="4.8"/>
          <circle cx="214" cy="148" r="5"/><circle cx="154" cy="168" r="4.4"/><circle cx="96" cy="156" r="4.4"/>
          <circle cx="60" cy="132" r="4.2"/>
        </g>
        <g fill="#ffc857" opacity=".9">
          <circle cx="96" cy="96" r="9" fill="none" stroke="#ffc857" stroke-width="1" stroke-opacity=".5"/>
        </g>
        <text x="34" y="238" fill="#8fa3d1" font-size="12" font-family="Trebuchet MS">Ursa Major · the Big Dipper</text>
      </svg>`,

    rocket: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A rocket lifting off with a plume of exhaust">
        <defs>
          <linearGradient id="rk-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#0a1230"/><stop offset="70%" stop-color="#132049"/><stop offset="100%" stop-color="#1d2c5c"/>
          </linearGradient>
          <linearGradient id="rk-body" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#8b98b8"/><stop offset="45%" stop-color="#f4f8ff"/><stop offset="100%" stop-color="#96a4c4"/>
          </linearGradient>
          <linearGradient id="rk-flame" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#9ef0ff"/><stop offset="45%" stop-color="#4fe3ff"/><stop offset="100%" stop-color="#ff9d3d" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#rk-sky)"/>
        <g fill="#fff" opacity=".55">
          <circle cx="40" cy="44" r="1.3"/><circle cx="118" cy="26" r="1"/><circle cx="300" cy="40" r="1.2"/>
          <circle cx="356" cy="88" r="1"/><circle cx="66" cy="112" r="1"/><circle cx="332" cy="176" r="1.1"/>
        </g>
        <ellipse cx="200" cy="246" rx="150" ry="18" fill="#4fe3ff" opacity=".09"/>
        <g transform="translate(200 128)">
          <path d="M0 -78c22 18 30 44 30 66v44h-60V-12c0-22 8-48 30-66Z" fill="url(#rk-body)"/>
          <path d="M0 -78c22 18 30 44 30 66v44h-30Z" fill="#000" opacity=".08"/>
          <circle cx="0" cy="-16" r="15" fill="#0c1934"/><circle cx="0" cy="-16" r="11" fill="#4fe3ff" opacity=".9"/>
          <circle cx="-4" cy="-20" r="4" fill="#d9fbff" opacity=".8"/>
          <path d="M-30 6 -52 40 -30 32Z" fill="#ffc857"/><path d="M30 6 52 40 30 32Z" fill="#ffc857"/>
          <rect x="-15" y="32" width="30" height="8" rx="3" fill="#5b6b90"/>
          <path d="M-12 40c0 18 5 32 12 48 7-16 12-30 12-48Z" fill="url(#rk-flame)"/>
          <path d="M-6 40c0 10 2 18 6 28 4-10 6-18 6-28Z" fill="#fff" opacity=".75"/>
        </g>
        <g stroke="#ffc857" stroke-opacity=".5" stroke-width="1.5" stroke-dasharray="4 8" fill="none">
          <path d="M76 210c30-20 40-56 34-96"/><path d="M324 210c-30-20-40-56-34-96"/>
        </g>
      </svg>`,

    cockpit: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A spacecraft cockpit full of glowing control screens">
        <defs>
          <linearGradient id="ck-bg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#0a1024"/><stop offset="100%" stop-color="#131f42"/>
          </linearGradient>
          <linearGradient id="ck-glass" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#0d2a4d"/><stop offset="100%" stop-color="#061426"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#ck-bg)"/>
        <path d="M40 132c0-52 44-90 160-90s160 38 160 90v22c-40-22-100-32-160-32s-120 10-160 32Z" fill="url(#ck-glass)" stroke="#3f6ea8" stroke-width="2"/>
        <g opacity=".9">
          <circle cx="120" cy="78" r="2" fill="#fff"/><circle cx="186" cy="60" r="1.4" fill="#fff"/>
          <circle cx="256" cy="70" r="1.8" fill="#fff"/><circle cx="300" cy="96" r="1.2" fill="#fff"/>
        </g>
        <ellipse cx="196" cy="128" rx="52" ry="42" fill="#3f8fe0" opacity=".55"/>
        <path d="M160 108c16-14 42-18 62-8s26 26 22 40-24 22-46 18-42-18-42-30 0-14 4-20Z" fill="#54c47f" opacity=".55"/>
        <path d="M40 132c40-22 100-32 160-32s120 10 160 32" fill="none" stroke="#7ec4ff" stroke-opacity=".4" stroke-width="3"/>
        <rect x="36" y="156" width="328" height="76" rx="12" fill="#0c1730" stroke="#2b4370" stroke-width="2"/>
        <g>
          <rect x="54" y="170" width="86" height="46" rx="6" fill="#0a2b3a" stroke="#2ea8c9" stroke-width="1.4"/>
          <g stroke="#4fe3ff" stroke-width="2" fill="none" opacity=".9">
            <path d="M62 204c10-14 16 4 24-10s16 6 24-8 16 2 22-6"/>
          </g>
          <rect x="152" y="170" width="96" height="46" rx="6" fill="#0a2b3a" stroke="#2ea8c9" stroke-width="1.4"/>
          <g fill="#5ff0b6">
            <rect x="162" y="194" width="9" height="14" rx="2"/><rect x="176" y="186" width="9" height="22" rx="2"/>
            <rect x="190" y="178" width="9" height="30" rx="2"/><rect x="204" y="190" width="9" height="18" rx="2"/>
            <rect x="218" y="182" width="9" height="26" rx="2"/>
          </g>
          <circle cx="284" cy="193" r="21" fill="none" stroke="#ffc857" stroke-width="3" opacity=".35"/>
          <path d="M284 193 L284 175 A18 18 0 0 1 299 202 Z" fill="#ffc857" opacity=".8"/>
          <circle cx="284" cy="193" r="5" fill="#ffe9bd"/>
          <rect x="318" y="172" width="30" height="10" rx="5" fill="#5ff0b6" opacity=".8"/>
          <rect x="318" y="188" width="30" height="10" rx="5" fill="#4fe3ff" opacity=".6"/>
          <rect x="318" y="204" width="30" height="10" rx="5" fill="#ff7d7d" opacity=".6"/>
        </g>
      </svg>`,

    station: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A space station orbiting Earth with large solar panels">
        <defs>
          <radialGradient id="st-earth" cx="30%" cy="26%" r="80%">
            <stop offset="0%" stop-color="#7fc7ff"/><stop offset="50%" stop-color="#2b6cc4"/><stop offset="100%" stop-color="#0a2554"/>
          </radialGradient>
          <linearGradient id="st-panel" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#1c3f7a"/><stop offset="100%" stop-color="#0b1f45"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#050a18"/>
        <circle cx="112" cy="232" r="132" fill="url(#st-earth)"/>
        <path d="M0 196c40-10 80 6 120 2s70-14 110-6v70H0Z" fill="#54c47f" opacity=".35"/>
        <ellipse cx="70" cy="160" rx="60" ry="26" fill="#fff" opacity=".12"/>
        <g fill="#fff" opacity=".6"><circle cx="330" cy="36" r="1.3"/><circle cx="376" cy="98" r="1"/><circle cx="262" cy="22" r="1.1"/></g>
        <g transform="translate(258 116) rotate(-14)">
          <rect x="-86" y="-9" width="172" height="18" rx="5" fill="#c9d3e8"/>
          <rect x="-74" y="-7" width="60" height="14" rx="2" fill="url(#st-panel)" stroke="#4a7bc4" stroke-width="1"/>
          <rect x="14" y="-7" width="60" height="14" rx="2" fill="url(#st-panel)" stroke="#4a7bc4" stroke-width="1"/>
          <g stroke="#6fa6ee" stroke-width=".7" opacity=".6">
            <path d="M-62-7v14M-50-7v14M-38-7v14M-26-7v14M14-7v14M26-7v14M38-7v14M50-7v14"/>
          </g>
          <rect x="-16" y="-22" width="34" height="44" rx="10" fill="#e8eefc"/>
          <rect x="-8" y="-14" width="18" height="10" rx="3" fill="#2a3d63"/>
          <circle cx="2" cy="10" r="5" fill="#4fe3ff"/>
          <circle cx="-4" cy="18" r="3" fill="#ffc857"/>
        </g>
        <g opacity=".35" stroke="#7ec4ff" stroke-dasharray="3 7" fill="none" stroke-width="1.4">
          <path d="M0 108c60 20 120 4 176-14"/>
        </g>
      </svg>`,

    orbit: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A satellite circling Earth along an orbital path">
        <defs>
          <radialGradient id="or-earth" cx="32%" cy="28%" r="80%">
            <stop offset="0%" stop-color="#8ed4ff"/><stop offset="52%" stop-color="#2a6ccb"/><stop offset="100%" stop-color="#092352"/>
          </radialGradient>
          <radialGradient id="or-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#4fe3ff" stop-opacity=".28"/><stop offset="100%" stop-color="#4fe3ff" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#050a18"/>
        <circle cx="200" cy="130" r="112" fill="url(#or-glow)"/>
        <g fill="none" stroke="#4f6db0" stroke-opacity=".55">
          <ellipse cx="200" cy="130" rx="158" ry="104" stroke-dasharray="5 7" stroke-width="1.4"/>
          <ellipse cx="200" cy="130" rx="124" ry="80" stroke-dasharray="5 7" stroke-width="1.2" stroke-opacity=".7"/>
        </g>
        <circle cx="200" cy="130" r="56" fill="url(#or-earth)"/>
        <path d="M162 116c14-8 26-2 30 6s-4 18-16 18-22-8-20-16 2-6 6-8Z" fill="#54c47f" opacity=".8"/>
        <path d="M206 150c10-4 22 0 24 8s-8 14-18 12-16-8-14-14 4-4 8-6Z" fill="#54c47f" opacity=".7"/>
        <ellipse cx="182" cy="104" rx="26" ry="10" fill="#fff" opacity=".18"/>
        <circle cx="200" cy="130" r="56" fill="none" stroke="#a9e4ff" stroke-opacity=".45" stroke-width="2"/>
        <g transform="translate(316 78) rotate(18)">
          <rect x="-14" y="-10" width="28" height="20" rx="6" fill="#e8eefc"/>
          <rect x="-34" y="-6" width="16" height="12" rx="2" fill="#2d4c86" stroke="#6fa6ee" stroke-width="1"/>
          <rect x="18" y="-6" width="16" height="12" rx="2" fill="#2d4c86" stroke="#6fa6ee" stroke-width="1"/>
          <circle cx="0" cy="0" r="4" fill="#4fe3ff"/>
        </g>
        <g fill="#ffc857" opacity=".9"><circle cx="70" cy="190" r="3"/></g>
        <text x="26" y="240" fill="#8fa3d1" font-size="11" font-family="Trebuchet MS">perigee ↓ · apogee ↑</text>
      </svg>`,

    control: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="Mission control room with screens and a headset">
        <defs>
          <linearGradient id="mc-bg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#07101f"/><stop offset="100%" stop-color="#0e1a33"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#mc-bg)"/>
        <g fill="#142544" stroke="#27446f" stroke-width="1.5">
          <rect x="24" y="28" width="94" height="56" rx="6"/>
          <rect x="128" y="28" width="94" height="56" rx="6"/>
          <rect x="232" y="28" width="94" height="56" rx="6"/>
          <rect x="336" y="28" width="42" height="56" rx="6"/>
        </g>
        <g stroke="#4fe3ff" stroke-width="2" fill="none" opacity=".85">
          <path d="M34 68c14-16 18 2 28-10s16 4 24-8"/>
          <path d="M244 60h70"/>
        </g>
        <g fill="#5ff0b6" opacity=".85">
          <rect x="138" y="56" width="8" height="18" rx="2"/><rect x="150" y="46" width="8" height="28" rx="2"/>
          <rect x="162" y="62" width="8" height="12" rx="2"/><rect x="174" y="40" width="8" height="34" rx="2"/>
          <rect x="186" y="54" width="8" height="20" rx="2"/><rect x="198" y="48" width="8" height="26" rx="2"/>
        </g>
        <g fill="#ffc857" opacity=".8"><circle cx="357" cy="46" r="6"/><circle cx="357" cy="68" r="6" opacity=".5"/></g>
        <rect x="18" y="104" width="364" height="10" rx="4" fill="#1b2f52"/>
        <g>
          <rect x="52" y="118" width="86" height="34" rx="5" fill="#0f2038" stroke="#2c4b76"/>
          <g fill="#4fe3ff" opacity=".8"><rect x="60" y="128" width="20" height="4" rx="2"/><rect x="60" y="136" width="34" height="4" rx="2"/><rect x="60" y="144" width="26" height="4" rx="2"/></g>
          <rect x="256" y="118" width="86" height="34" rx="5" fill="#0f2038" stroke="#2c4b76"/>
          <g fill="#5ff0b6" opacity=".7"><rect x="264" y="128" width="26" height="4" rx="2"/><rect x="264" y="136" width="40" height="4" rx="2"/><rect x="264" y="144" width="18" height="4" rx="2"/></g>
        </g>
        <g transform="translate(196 196)">
          <path d="M-46 22c-16-40 4-70 46-70s62 30 46 70" fill="none" stroke="#8fb0e0" stroke-width="9" stroke-linecap="round"/>
          <ellipse cx="0" cy="10" rx="34" ry="30" fill="#1a2f52" stroke="#4a6d9e" stroke-width="2"/>
          <circle cx="-11" cy="4" r="3.2" fill="#ffc857"/><circle cx="11" cy="4" r="3.2" fill="#ffc857"/>
          <path d="M-12 20c8 6 16 6 24 0" stroke="#ffc857" stroke-width="3" fill="none" stroke-linecap="round"/>
          <path d="M-24 20c-14 6-26 16-30 30" stroke="#8fb0e0" stroke-width="4" fill="none" stroke-linecap="round"/>
          <circle cx="-56" cy="52" r="6" fill="#ff7d7d"/>
        </g>
      </svg>`,

    moon: () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A lunar lander touching down on the Moon">
        <defs>
          <linearGradient id="mn-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#04070f"/><stop offset="100%" stop-color="#111a2e"/>
          </linearGradient>
          <linearGradient id="mn-grd" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#5d6880"/><stop offset="100%" stop-color="#2b3245"/>
          </linearGradient>
          <linearGradient id="mn-flame" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#fff3c4"/><stop offset="60%" stop-color="#ffb347" stop-opacity=".8"/><stop offset="100%" stop-color="#ff7d3d" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#mn-sky)"/>
        <g fill="#fff"><circle cx="48" cy="40" r="1.2" opacity=".7"/><circle cx="112" cy="24" r="1" opacity=".6"/>
          <circle cx="320" cy="34" r="1.4" opacity=".7"/><circle cx="368" cy="92" r="1" opacity=".5"/><circle cx="272" cy="58" r="1" opacity=".6"/></g>
        <circle cx="330" cy="66" r="24" fill="#e8eeff" opacity=".92"/>
        <circle cx="322" cy="60" r="5" fill="#c3cbe6" opacity=".7"/><circle cx="338" cy="74" r="4" fill="#c3cbe6" opacity=".6"/>
        <path d="M0 186c46-22 92-6 138-14s86-18 132-6 92 16 130 6v88H0Z" fill="url(#mn-grd)"/>
        <path d="M0 186c46-22 92-6 138-14s86-18 132-6 92 16 130 6" fill="none" stroke="#93a0bd" stroke-width="2" opacity=".7"/>
        <g fill="#0b1020" opacity=".3">
          <ellipse cx="90" cy="212" rx="26" ry="7"/><ellipse cx="250" cy="226" rx="34" ry="9"/><ellipse cx="340" cy="204" rx="18" ry="5"/>
        </g>
        <g transform="translate(196 118)">
          <path d="M-34 -30h68l14 40h-96Z" fill="#c9d3e8"/>
          <rect x="-18" y="-44" width="36" height="18" rx="6" fill="#9dabc8"/>
          <circle cx="0" cy="-36" r="6" fill="#0c1934"/><circle cx="0" cy="-36" r="3.5" fill="#4fe3ff"/>
          <rect x="-30" y="10" width="60" height="12" rx="4" fill="#8b98b8"/>
          <path d="M-44 10 -56 34M44 10 56 34M-20 22 -24 40M20 22 24 40" stroke="#8b98b8" stroke-width="4" stroke-linecap="round"/>
          <ellipse cx="-56" cy="36" rx="8" ry="3" fill="#6c7793"/><ellipse cx="56" cy="36" rx="8" ry="3" fill="#6c7793"/>
          <ellipse cx="-24" cy="42" rx="7" ry="3" fill="#6c7793"/><ellipse cx="24" cy="42" rx="7" ry="3" fill="#6c7793"/>
          <path d="M-8 24c0 16 3 28 8 40 5-12 8-24 8-40Z" fill="url(#mn-flame)" opacity=".9"/>
        </g>
        <g fill="#5a6580" opacity=".55">
          <circle cx="70" cy="176" r="2"/><circle cx="146" cy="162" r="1.6"/><circle cx="286" cy="166" r="1.8"/>
        </g>
      </svg>`
  };

  /* ---- level 8: solar storm ---- */
  SCENES.sunstorm = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="The Sun throwing a storm of particles towards Earth">
        <defs>
          <radialGradient id="ss-sun" cx="50%" cy="50%">
            <stop offset="0%" stop-color="#fff6d0"/><stop offset="45%" stop-color="#ffc857"/><stop offset="100%" stop-color="#ff7d3d"/>
          </radialGradient>
          <radialGradient id="ss-glow" cx="50%" cy="50%">
            <stop offset="0%" stop-color="#ffb347" stop-opacity=".55"/><stop offset="100%" stop-color="#ffb347" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="ss-earth" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#4fe3ff"/><stop offset="100%" stop-color="#1b6fa8"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#04070f"/>
        <g fill="#fff"><circle cx="60" cy="30" r="1.1" opacity=".6"/><circle cx="200" cy="18" r="1" opacity=".5"/>
          <circle cx="300" cy="46" r="1.2" opacity=".6"/><circle cx="150" cy="240" r="1" opacity=".4"/><circle cx="360" cy="200" r="1.1" opacity=".5"/></g>
        <circle cx="86" cy="130" r="86" fill="url(#ss-glow)"/>
        <circle cx="86" cy="130" r="46" fill="url(#ss-sun)"/>
        <g stroke="#ffb347" stroke-width="2.4" stroke-linecap="round" opacity=".85">
          <path d="M86 66v-16M86 194v16M22 130H6M150 130h16M41 85 30 74M131 175l11 11M131 85l11-11M41 175l-11 11"/>
        </g>
        <g fill="#ff7d3d" opacity=".5">
          <ellipse cx="70" cy="118" rx="9" ry="6"/><ellipse cx="104" cy="146" rx="7" ry="5"/>
        </g>
        <g stroke="#ffc857" stroke-width="2" fill="none" opacity=".8" stroke-dasharray="5 6">
          <path d="M136 108c40-16 78-24 118-22"/><path d="M136 130c42 0 80 2 118 6"/><path d="M136 152c40 16 78 24 118 22"/>
        </g>
        <g fill="#ffd166"><circle cx="176" cy="98" r="2.4"/><circle cx="214" cy="92" r="2"/><circle cx="252" cy="90" r="2.2"/>
          <circle cx="180" cy="132" r="2.2"/><circle cx="222" cy="134" r="2.4"/><circle cx="258" cy="138" r="2"/>
          <circle cx="178" cy="164" r="2"/><circle cx="216" cy="170" r="2.2"/><circle cx="254" cy="172" r="2.4"/></g>
        <circle cx="316" cy="130" r="34" fill="url(#ss-earth)"/>
        <path d="M292 112c14 6 30 4 44-2M290 140c16 8 34 8 50 0M300 156c12 4 24 4 34 0" stroke="#5ff0b6" stroke-width="3" fill="none" opacity=".7"/>
        <ellipse cx="316" cy="130" rx="52" ry="52" fill="none" stroke="#4fe3ff" stroke-width="1.6" opacity=".45"/>
        <ellipse cx="316" cy="130" rx="62" ry="62" fill="none" stroke="#4fe3ff" stroke-width="1.2" opacity=".25"/>
      </svg>`,

  /* ---- level 9: EVA ---- */
  SCENES.eva = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="An astronaut on a spacewalk tethered to a space station">
        <defs>
          <linearGradient id="ev-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#03060e"/><stop offset="100%" stop-color="#0a1226"/>
          </linearGradient>
          <linearGradient id="ev-earth" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#2f7fd0"/><stop offset="100%" stop-color="#0d3a63"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#ev-sky)"/>
        <g fill="#fff"><circle cx="40" cy="34" r="1.2" opacity=".7"/><circle cx="120" cy="20" r="1" opacity=".5"/>
          <circle cx="250" cy="30" r="1.3" opacity=".6"/><circle cx="350" cy="60" r="1" opacity=".5"/><circle cx="300" cy="16" r="1.1" opacity=".6"/></g>
        <path d="M0 260c0-70 60-118 150-118s150 48 150 118Z" fill="url(#ev-earth)"/>
        <path d="M40 200c30-14 60-10 88 2M120 176c26-10 52-6 74 6M210 190c22-8 44-4 62 6" stroke="#5ff0b6" stroke-width="4" fill="none" opacity=".55"/>
        <path d="M0 260c0-70 60-118 150-118s150 48 150 118" fill="none" stroke="#7fd8ff" stroke-width="2" opacity=".5"/>
        <g transform="translate(300 74)">
          <rect x="-46" y="-16" width="92" height="34" rx="8" fill="#c9d3e8"/>
          <rect x="-30" y="-30" width="60" height="16" rx="5" fill="#9dabc8"/>
          <rect x="-70" y="-6" width="26" height="14" rx="3" fill="#4fe3ff" opacity=".85"/>
          <rect x="44" y="-6" width="26" height="14" rx="3" fill="#4fe3ff" opacity=".85"/>
          <circle cx="0" cy="1" r="7" fill="#0c1934"/><circle cx="0" cy="1" r="4" fill="#4fe3ff"/>
        </g>
        <path d="M262 78C210 96 176 130 160 168" stroke="#ffc857" stroke-width="2.4" fill="none" stroke-dasharray="6 5"/>
        <g transform="translate(150 178)">
          <rect x="-16" y="-14" width="32" height="30" rx="9" fill="#eef3ff"/>
          <circle cx="0" cy="-24" r="17" fill="#eef3ff"/>
          <path d="M-13 -26a13 13 0 0 1 26 0Z" fill="#2b3f66" opacity=".9"/>
          <rect x="-22" y="-6" width="10" height="20" rx="5" fill="#dbe4f7"/>
          <rect x="12" y="-6" width="10" height="20" rx="5" fill="#dbe4f7"/>
          <rect x="-12" y="16" width="10" height="22" rx="5" fill="#dbe4f7"/>
          <rect x="2" y="16" width="10" height="22" rx="5" fill="#dbe4f7"/>
          <rect x="-14" y="-30" width="28" height="8" rx="4" fill="#4fe3ff" opacity=".8"/>
        </g>
        <g fill="#ffc857" opacity=".9"><circle cx="196" cy="120" r="2"/><circle cx="216" cy="140" r="1.6"/><circle cx="232" cy="104" r="1.8"/></g>
      </svg>`,

  /* ---- level 10: rocket engineering ---- */
  SCENES.engineering = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A rocket shown in cutaway with its stages and engine nozzle">
        <defs>
          <linearGradient id="en-body" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#8b98b8"/><stop offset="45%" stop-color="#eef3ff"/><stop offset="100%" stop-color="#9dabc8"/>
          </linearGradient>
          <linearGradient id="en-flame" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#fff3c4"/><stop offset="55%" stop-color="#ffb347" stop-opacity=".85"/><stop offset="100%" stop-color="#ff5f3d" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#060b18"/>
        <g stroke="#1d2a4a" stroke-width="1"><path d="M0 60h400M0 120h400M0 180h400M0 240h400"/></g>
        <g transform="translate(200 0)">
          <path d="M0 18c14 22 22 48 22 78v70h-44V96c0-30 8-56 22-78Z" fill="url(#en-body)"/>
          <path d="M-22 96h44v70h-44Z" fill="#c9d3e8" opacity=".55"/>
          <rect x="-24" y="104" width="48" height="4" fill="#ff7d7d" opacity=".8"/>
          <rect x="-24" y="150" width="48" height="4" fill="#4fe3ff" opacity=".8"/>
          <path d="M-22 166 -40 196h80l-18-30Z" fill="#8b98b8"/>
          <path d="M-40 196 -52 214h104l-12-18Z" fill="#6c7793"/>
          <path d="M-16 214c0 18 4 30 16 44 12-14 16-26 16-44Z" fill="url(#en-flame)"/>
          <circle cx="0" cy="60" r="9" fill="#0c1934"/><circle cx="0" cy="60" r="5" fill="#4fe3ff"/>
          <path d="M-22 40 -40 62v22l18-14Z" fill="#ff7d7d" opacity=".85"/>
          <path d="M22 40 40 62v22l-18-14Z" fill="#ff7d7d" opacity=".85"/>
        </g>
        <g stroke="#4fe3ff" stroke-width="1.4" fill="none" opacity=".7">
          <path d="M244 60h44"/><path d="M244 120h44"/><path d="M244 180h44"/>
        </g>
        <g fill="#7fd8ff" font-size="11" font-family="monospace">
          <text x="294" y="64">STAGE 1</text><text x="294" y="124">STAGE 2</text><text x="294" y="184">NOZZLE</text>
        </g>
        <g fill="#ffc857" font-size="10" font-family="monospace" opacity=".9">
          <text x="20" y="40">FUEL</text><text x="20" y="56">OXIDISER</text>
        </g>
      </svg>`,

  /* ---- level 11: satellites & GPS ---- */
  SCENES.satellite = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="GPS satellites orbiting Earth and sending signals to a phone on the ground">
        <defs>
          <radialGradient id="sa-earth" cx="35%" cy="30%">
            <stop offset="0%" stop-color="#5fd0ff"/><stop offset="60%" stop-color="#1b6fa8"/><stop offset="100%" stop-color="#0a2c4d"/>
          </radialGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#04070f"/>
        <g fill="#fff"><circle cx="30" cy="30" r="1.1" opacity=".6"/><circle cx="370" cy="40" r="1.2" opacity=".6"/>
          <circle cx="200" cy="16" r="1" opacity=".5"/><circle cx="330" cy="230" r="1" opacity=".4"/></g>
        <circle cx="200" cy="196" r="96" fill="url(#sa-earth)"/>
        <path d="M120 150c26 12 54 8 78-4M150 200c30 10 62 6 88-6M180 240c26 6 50 2 70-6" stroke="#5ff0b6" stroke-width="4" fill="none" opacity=".5"/>
        <ellipse cx="200" cy="196" rx="150" ry="52" fill="none" stroke="#4fe3ff" stroke-width="1.4" opacity=".4"/>
        <ellipse cx="200" cy="196" rx="186" ry="70" fill="none" stroke="#4fe3ff" stroke-width="1.1" opacity=".22"/>
        <g transform="translate(96 96)">
          <rect x="-16" y="-11" width="32" height="22" rx="4" fill="#c9d3e8"/>
          <rect x="-46" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <rect x="18" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <circle cx="0" cy="0" r="4" fill="#0c1934"/>
        </g>
        <g transform="translate(300 84)">
          <rect x="-16" y="-11" width="32" height="22" rx="4" fill="#c9d3e8"/>
          <rect x="-46" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <rect x="18" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <circle cx="0" cy="0" r="4" fill="#0c1934"/>
        </g>
        <g transform="translate(200 40)">
          <rect x="-16" y="-11" width="32" height="22" rx="4" fill="#c9d3e8"/>
          <rect x="-46" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <rect x="18" y="-8" width="28" height="16" rx="2" fill="#4fe3ff" opacity=".9"/>
          <circle cx="0" cy="0" r="4" fill="#0c1934"/>
        </g>
        <g stroke="#ffc857" stroke-width="1.6" fill="none" opacity=".75" stroke-dasharray="4 5">
          <path d="M96 108 176 176"/><path d="M300 96 224 176"/><path d="M200 52 200 176"/>
        </g>
        <g transform="translate(200 200)">
          <rect x="-13" y="-22" width="26" height="44" rx="6" fill="#0f1a33" stroke="#4fe3ff" stroke-width="1.6"/>
          <rect x="-9" y="-17" width="18" height="30" rx="3" fill="#4fe3ff" opacity=".35"/>
          <circle cx="0" cy="16" r="2.6" fill="#5ff0b6"/>
        </g>
        <g fill="#ffc857"><circle cx="176" cy="176" r="3"/><circle cx="224" cy="176" r="3"/><circle cx="200" cy="176" r="3"/></g>
      </svg>`,

  /* ---- level 12: living in zero gravity ---- */
  SCENES.zeroglife = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="An astronaut sleeping in a wall-mounted sleeping bag while objects float around">
        <defs>
          <linearGradient id="zg-wall" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#101a33"/><stop offset="100%" stop-color="#070d1c"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#zg-wall)"/>
        <g stroke="#1d2a4a" stroke-width="1.4" fill="none">
          <path d="M0 52h400M0 208h400M60 0v260M340 0v260"/>
        </g>
        <g fill="#4fe3ff" opacity=".5"><circle cx="30" cy="26" r="3"/><circle cx="370" cy="26" r="3"/><circle cx="30" cy="234" r="3"/><circle cx="370" cy="234" r="3"/></g>
        <g transform="translate(96 130)">
          <rect x="-34" y="-72" width="68" height="144" rx="26" fill="#1b2745" stroke="#4fe3ff" stroke-width="1.6" opacity=".9"/>
          <rect x="-26" y="-62" width="52" height="124" rx="20" fill="#243356"/>
          <circle cx="0" cy="-34" r="20" fill="#eef3ff"/>
          <path d="M-15 -36a15 15 0 0 1 30 0Z" fill="#2b3f66" opacity=".9"/>
          <path d="M-8 -30c3 3 13 3 16 0" stroke="#2b3f66" stroke-width="2" fill="none" stroke-linecap="round"/>
          <rect x="-20" y="-6" width="40" height="52" rx="14" fill="#dbe4f7" opacity=".9"/>
          <path d="M-20 6h40M-20 22h40" stroke="#9dabc8" stroke-width="2"/>
        </g>
        <g transform="translate(232 74) rotate(-14)">
          <rect x="-20" y="-14" width="40" height="28" rx="5" fill="#c9d3e8"/>
          <rect x="-14" y="-8" width="28" height="16" rx="3" fill="#4fe3ff" opacity=".5"/>
        </g>
        <g transform="translate(300 150) rotate(18)">
          <path d="M-16 -18h32l6 36h-44Z" fill="#ffc857" opacity=".9"/>
          <rect x="-12" y="-26" width="24" height="10" rx="4" fill="#ff7d7d"/>
        </g>
        <g transform="translate(196 200) rotate(-8)">
          <circle cx="0" cy="0" r="15" fill="#5ff0b6" opacity=".85"/>
          <path d="M-6 -4c4 4 8 4 12 0" stroke="#063d2c" stroke-width="2" fill="none" stroke-linecap="round"/>
        </g>
        <g transform="translate(268 40) rotate(24)">
          <rect x="-14" y="-10" width="28" height="20" rx="4" fill="#a99bff" opacity=".85"/>
        </g>
        <g stroke="#4fe3ff" stroke-width="1.2" fill="none" opacity=".35" stroke-dasharray="3 6">
          <path d="M232 74c-20 20-30 40-36 60"/><path d="M300 150c-30 10-60 20-90 34"/>
        </g>
      </svg>`,

  /* ---- level 13: deep space telescope ---- */
  SCENES.telescope = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A space telescope with a segmented mirror looking at a distant galaxy">
        <defs>
          <radialGradient id="ts-gal" cx="50%" cy="50%">
            <stop offset="0%" stop-color="#fff6d0"/><stop offset="35%" stop-color="#ffc857" stop-opacity=".8"/><stop offset="100%" stop-color="#a99bff" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="ts-tube" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#eef3ff"/><stop offset="100%" stop-color="#8b98b8"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#03060e"/>
        <g fill="#fff"><circle cx="40" cy="40" r="1.2" opacity=".7"/><circle cx="120" cy="24" r="1" opacity=".5"/>
          <circle cx="250" cy="34" r="1.3" opacity=".6"/><circle cx="360" cy="70" r="1" opacity=".5"/>
          <circle cx="330" cy="200" r="1.1" opacity=".5"/><circle cx="60" cy="220" r="1" opacity=".4"/></g>
        <g transform="translate(300 70)">
          <ellipse cx="0" cy="0" rx="52" ry="30" fill="url(#ts-gal)" transform="rotate(-24)"/>
          <ellipse cx="0" cy="0" rx="30" ry="16" fill="none" stroke="#ffc857" stroke-width="1.6" opacity=".7" transform="rotate(-24)"/>
          <ellipse cx="0" cy="0" rx="14" ry="7" fill="#fff6d0" opacity=".9" transform="rotate(-24)"/>
        </g>
        <g transform="translate(150 150) rotate(-18)">
          <rect x="-70" y="-30" width="140" height="60" rx="10" fill="url(#ts-tube)"/>
          <rect x="-70" y="-30" width="140" height="60" rx="10" fill="none" stroke="#6c7793" stroke-width="1.6"/>
          <g fill="#ffc857" opacity=".9">
            <path d="M-56 -18h20l10 18-10 18h-20l-10-18Z"/><path d="M-30 -18h20l10 18-10 18h-20l-10-18Z"/>
            <path d="M-4 -18h20l10 18-10 18h-20l-10-18Z"/><path d="M22 -18h20l10 18-10 18h-20l-10-18Z"/>
          </g>
          <rect x="70" y="-14" width="26" height="28" rx="6" fill="#4fe3ff" opacity=".85"/>
          <rect x="-96" y="-20" width="26" height="40" rx="6" fill="#9dabc8"/>
        </g>
        <g stroke="#4fe3ff" stroke-width="1.4" fill="none" opacity=".6" stroke-dasharray="5 6">
          <path d="M76 138 250 78"/>
        </g>
        <g transform="translate(150 150) rotate(-18)">
          <rect x="-40" y="30" width="80" height="10" rx="4" fill="#6c7793"/>
        </g>
        <g fill="#5ff0b6" opacity=".8"><circle cx="200" cy="228" r="2"/><circle cx="230" cy="236" r="1.6"/><circle cx="170" cy="238" r="1.8"/></g>
      </svg>`,

  /* ---- level 14: Mars colony ---- */
  SCENES.marsbase = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A Mars colony of domes and greenhouses under a dusty pink sky">
        <defs>
          <linearGradient id="mb-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#2a1220"/><stop offset="55%" stop-color="#7a3a2e"/><stop offset="100%" stop-color="#c97a52"/>
          </linearGradient>
          <linearGradient id="mb-grd" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#b5643f"/><stop offset="100%" stop-color="#6d3520"/>
          </linearGradient>
          <linearGradient id="mb-dome" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#dff6ff" stop-opacity=".85"/><stop offset="100%" stop-color="#4fe3ff" stop-opacity=".35"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="url(#mb-sky)"/>
        <circle cx="330" cy="52" r="20" fill="#ffd9a8" opacity=".55"/>
        <g fill="#fff" opacity=".5"><circle cx="60" cy="30" r="1"/><circle cx="180" cy="22" r="1.1"/><circle cx="260" cy="40" r="1"/></g>
        <path d="M0 150c50-26 96-10 146-20s92-22 140-8 78 18 114 8v130H0Z" fill="url(#mb-grd)"/>
        <path d="M0 150c50-26 96-10 146-20s92-22 140-8 78 18 114 8" fill="none" stroke="#e0a077" stroke-width="2" opacity=".6"/>
        <g fill="#5a2a18" opacity=".35"><ellipse cx="80" cy="196" rx="30" ry="8"/><ellipse cx="300" cy="212" rx="38" ry="10"/></g>
        <g transform="translate(120 150)">
          <path d="M-52 0a52 52 0 0 1 104 0Z" fill="url(#mb-dome)" stroke="#7fd8ff" stroke-width="2"/>
          <path d="M-30 0a30 30 0 0 1 60 0Z" fill="#0f2a3a" opacity=".5"/>
          <rect x="-8" y="-30" width="16" height="30" rx="4" fill="#0f2a3a" opacity=".6"/>
          <rect x="-56" y="0" width="112" height="8" rx="3" fill="#8b98b8"/>
        </g>
        <g transform="translate(250 158)">
          <path d="M-40 0a40 40 0 0 1 80 0Z" fill="url(#mb-dome)" stroke="#7fd8ff" stroke-width="2"/>
          <g fill="#5ff0b6" opacity=".8">
            <path d="M-22 0c0-12 6-20 12-24 6 4 12 12 12 24Z"/><path d="M2 0c0-10 5-17 10-20 5 3 10 10 10 20Z"/>
          </g>
          <rect x="-44" y="0" width="88" height="8" rx="3" fill="#8b98b8"/>
        </g>
        <g transform="translate(196 120)">
          <rect x="-3" y="-40" width="6" height="40" fill="#8b98b8"/>
          <path d="M-16 -40h32l-6 -12h-20Z" fill="#4fe3ff" opacity=".8"/>
          <circle cx="0" cy="-46" r="3" fill="#ff7d7d"/>
        </g>
        <g transform="translate(60 190)">
          <rect x="-18" y="-10" width="36" height="20" rx="5" fill="#c9d3e8"/>
          <circle cx="-10" cy="12" r="5" fill="#6c7793"/><circle cx="10" cy="12" r="5" fill="#6c7793"/>
          <rect x="-12" y="-18" width="24" height="8" rx="3" fill="#4fe3ff" opacity=".8"/>
        </g>
        <g stroke="#ffc857" stroke-width="1.4" fill="none" opacity=".5" stroke-dasharray="4 5">
          <path d="M196 80 120 150"/><path d="M196 80 250 158"/>
        </g>
      </svg>`,

  /* ---- level 15: graduation ---- */
  SCENES.graduation = () => `
      <svg viewBox="0 0 400 260" role="img" aria-label="A cadet graduating with wings and a certificate in front of a starry sky">
        <defs>
          <radialGradient id="gr-glow" cx="50%" cy="45%">
            <stop offset="0%" stop-color="#ffc857" stop-opacity=".45"/><stop offset="100%" stop-color="#ffc857" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="gr-suit" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#c9d3e8"/>
          </linearGradient>
        </defs>
        <rect width="400" height="260" rx="14" fill="#04070f"/>
        <g fill="#fff"><circle cx="50" cy="36" r="1.2" opacity=".7"/><circle cx="140" cy="22" r="1" opacity=".5"/>
          <circle cx="260" cy="30" r="1.3" opacity=".6"/><circle cx="350" cy="56" r="1" opacity=".5"/>
          <circle cx="90" cy="220" r="1" opacity=".4"/><circle cx="320" cy="216" r="1.1" opacity=".5"/></g>
        <circle cx="200" cy="120" r="120" fill="url(#gr-glow)"/>
        <g transform="translate(200 150)">
          <rect x="-30" y="-30" width="60" height="70" rx="16" fill="url(#gr-suit)"/>
          <circle cx="0" cy="-52" r="26" fill="#eef3ff"/>
          <path d="M-20 -54a20 20 0 0 1 40 0Z" fill="#2b3f66" opacity=".9"/>
          <path d="M-11 -46c4 4 18 4 22 0" stroke="#2b3f66" stroke-width="2.4" fill="none" stroke-linecap="round"/>
          <rect x="-38" y="-24" width="14" height="34" rx="7" fill="#dbe4f7"/>
          <rect x="24" y="-24" width="14" height="34" rx="7" fill="#dbe4f7"/>
          <rect x="-22" y="40" width="16" height="34" rx="7" fill="#dbe4f7"/>
          <rect x="6" y="40" width="16" height="34" rx="7" fill="#dbe4f7"/>
          <g transform="translate(0 -6)">
            <path d="M-16 0h32v10h-32Z" fill="#ffc857"/>
            <path d="M-16 0 -30 -8v10Z" fill="#ffc857"/><path d="M16 0 30 -8v10Z" fill="#ffc857"/>
            <circle cx="0" cy="5" r="4" fill="#ff7d7d"/>
          </g>
          <g transform="translate(0 -78)">
            <path d="M-34 0h68l-8 -10h-52Z" fill="#0f1a33"/>
            <rect x="-30" y="-10" width="60" height="10" rx="2" fill="#1b2745"/>
            <path d="M30 -6 44 4" stroke="#ffc857" stroke-width="3" stroke-linecap="round"/>
            <circle cx="46" cy="6" r="4" fill="#ffc857"/>
          </g>
        </g>
        <g transform="translate(96 196) rotate(-12)">
          <rect x="-30" y="-20" width="60" height="40" rx="4" fill="#f4f7ff"/>
          <path d="M-22 -10h44M-22 0h44M-22 10h30" stroke="#9dabc8" stroke-width="2"/>
          <circle cx="20" cy="10" r="6" fill="#ff7d7d" opacity=".8"/>
        </g>
        <g fill="#ffc857" opacity=".9">
          <path d="M300 60 303 68 311 68 305 73 307 81 300 76 293 81 295 73 289 68 297 68Z"/>
          <path d="M330 120 332 126 338 126 333 130 335 136 330 132 325 136 327 130 322 126 328 126Z"/>
        </g>
      </svg>`,

  /* ---- focus target: a distant galaxy ---- */
  SCENES.galaxy = () => `
      <svg viewBox="0 0 200 200" role="img" aria-label="A distant spiral galaxy">
        <defs>
          <radialGradient id="gx-core" cx="50%" cy="50%">
            <stop offset="0%" stop-color="#fff6d0"/><stop offset="40%" stop-color="#ffc857" stop-opacity=".85"/><stop offset="100%" stop-color="#a99bff" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="200" height="200" fill="none"/>
        <ellipse cx="100" cy="100" rx="92" ry="52" fill="url(#gx-core)" transform="rotate(-24 100 100)"/>
        <g fill="none" stroke="#a99bff" stroke-width="2.4" opacity=".75" transform="rotate(-24 100 100)">
          <ellipse cx="100" cy="100" rx="70" ry="34"/>
          <ellipse cx="100" cy="100" rx="48" ry="22"/>
          <ellipse cx="100" cy="100" rx="26" ry="12"/>
        </g>
        <ellipse cx="100" cy="100" rx="18" ry="9" fill="#fff6d0" opacity=".95" transform="rotate(-24 100 100)"/>
        <g fill="#fff" opacity=".9">
          <circle cx="46" cy="72" r="1.6"/><circle cx="150" cy="128" r="1.6"/>
          <circle cx="70" cy="140" r="1.3"/><circle cx="132" cy="62" r="1.3"/>
          <circle cx="100" cy="40" r="1.2"/><circle cx="100" cy="162" r="1.2"/>
        </g>
      </svg>`;

  function scene(name) {
    return (SCENES[name] || SCENES.constellation)();
  }

  /* ---- cadet avatar ---- */
  function cadet(opts) {
    const o = opts || {};
    const u = "cd" + (++__uid);
    const suit = SUITS.find(s => s.id === o.suit) || SUITS[0];
    const helmet = o.helmet || "helm_bubble";
    const badge = o.badge || "badge_none";
    const visorId = o.visor || "visor_clear";
    const hatId = o.hat || "hat_none";
    const packId = o.backpack || "pack_std";
    const bootId = o.boots || "boot_std";
    const gloveId = o.gloves || "glove_std";
    const capeId = o.cape || "cape_none";
    const petId = o.pet || "pet_none";
    const trailId = o.trail || "trail_none";
    const c = suit.colors;
    const bodyDark = shadeColor(c.body, -0.34);
    const bodyMid = shadeColor(c.body, -0.14);

    const visorItem = VISORS.find(v => v.id === visorId) || VISORS[0];
    const visorFill = helmet === "helm_gold" ? "#ffcf4d" : visorItem.tint;
    const visorOpacity = helmet === "helm_gold" ? ".92" : String(visorItem.alpha);

    const antenna = helmet === "helm_horn" ? `
      <g transform="translate(150 44)">
        <rect x="-2" y="0" width="4" height="22" rx="2" fill="${c.trim}"/>
        <ellipse cx="0" cy="-4" rx="15" ry="6" fill="${c.trim}" opacity=".9"/>
        <ellipse cx="0" cy="-6" rx="15" ry="6" fill="${bodyDark}" opacity=".55"/>
        <circle cx="0" cy="-4" r="3" fill="#4fe3ff"/>
      </g>` : "";
    const crest = helmet === "helm_star" ? `
      <g transform="translate(100 26)">
        <path d="M0 -10 3 -3 10 -3 4.5 1.5 6.5 8.5 0 4.5 -6.5 8.5 -4.5 1.5 -10 -3 -3 -3Z" fill="#ffc857"/>
      </g>` : "";
    const ringHalo = helmet === "helm_ring" ? `
      <ellipse cx="100" cy="76" rx="62" ry="16" fill="none" stroke="#ffc857" stroke-width="3" opacity=".85" transform="rotate(-16 100 76)"/>
      <ellipse cx="100" cy="76" rx="62" ry="16" fill="none" stroke="#fff6d0" stroke-width="1.2" opacity=".6" transform="rotate(-16 100 76)"/>` : "";
    const surveyDome = helmet === "helm_dome" ? `
      <circle cx="100" cy="76" r="52" fill="none" stroke="${c.trim}" stroke-width="2" opacity=".7"/>
      <path d="M100 24v104M48 76h104" stroke="${c.trim}" stroke-width="1.2" opacity=".35"/>` : "";
    const reactorCowl = helmet === "helm_reactor" ? `
      <path d="M62 40h76l-8-16H70Z" fill="#8b98b8"/>
      <rect x="86" y="14" width="28" height="12" rx="4" fill="#5ff0b6" opacity=".9"/>
      <path d="M70 30c-8-6-14-14-16-22M130 30c8-6 14-14 16-22" stroke="#5ff0b6" stroke-width="3" fill="none" opacity=".6" stroke-linecap="round"/>` : "";
    const crystalShell = helmet === "helm_crystal" ? `
      <path d="M100 22 148 60 132 122 68 122 52 60Z" fill="#a99bff" opacity=".22" stroke="#a99bff" stroke-width="2"/>
      <path d="M100 22v100M52 60h96" stroke="#a99bff" stroke-width="1.2" opacity=".5"/>` : "";
    const commanderCrown = helmet === "helm_crown" ? `
      <path d="M62 34 74 14 88 30 100 8 112 30 126 14 138 34Z" fill="#ffc857"/>
      <circle cx="100" cy="20" r="4" fill="#ff7d7d"/><circle cx="74" cy="22" r="3" fill="#4fe3ff"/><circle cx="126" cy="22" r="3" fill="#4fe3ff"/>` : "";
    const eventHorizon = helmet === "helm_blackhole" ? `
      <circle cx="100" cy="76" r="50" fill="#05070f" opacity=".55"/>
      <ellipse cx="100" cy="76" rx="66" ry="18" fill="none" stroke="#a99bff" stroke-width="3" opacity=".9" transform="rotate(-14 100 76)"/>
      <ellipse cx="100" cy="76" rx="66" ry="18" fill="none" stroke="#fff6d0" stroke-width="1.2" opacity=".5" transform="rotate(-14 100 76)"/>` : "";

    /* ---- hats ---- */
    let hatMark = "";
    if (hatId === "hat_cap") hatMark = `<path d="M62 40h76v14H62Z" fill="#2b3f66"/><path d="M138 40h26v9h-26Z" fill="#1b2745"/><circle cx="100" cy="34" r="5" fill="#4fe3ff"/>`;
    else if (hatId === "hat_beanie") hatMark = `<path d="M64 44a36 36 0 0 1 72 0Z" fill="#ff7d7d"/><rect x="60" y="40" width="80" height="14" rx="7" fill="#ffd9a8"/><circle cx="100" cy="14" r="7" fill="#ffd9a8"/>`;
    else if (hatId === "hat_headset") hatMark = `<path d="M60 46a40 40 0 0 1 80 0" fill="none" stroke="#4fe3ff" stroke-width="6"/><rect x="46" y="40" width="18" height="28" rx="8" fill="#4fe3ff"/><rect x="136" y="40" width="18" height="28" rx="8" fill="#4fe3ff"/><path d="M145 68c0 16-14 22-28 22" stroke="#4fe3ff" stroke-width="4" fill="none"/><circle cx="117" cy="90" r="5" fill="#4fe3ff"/>`;
    else if (hatId === "hat_tophat") hatMark = `<rect x="70" y="0" width="60" height="42" rx="4" fill="#0f1a33"/><rect x="52" y="38" width="96" height="12" rx="6" fill="#0f1a33"/><rect x="70" y="28" width="60" height="9" fill="#ffc857"/>`;
    else if (hatId === "hat_antennae") hatMark = `<path d="M84 40 70 8M116 40 130 8" stroke="#5ff0b6" stroke-width="4" stroke-linecap="round"/><circle cx="70" cy="6" r="7" fill="#5ff0b6"/><circle cx="130" cy="6" r="7" fill="#5ff0b6"/><circle cx="70" cy="6" r="3" fill="#fff"/><circle cx="130" cy="6" r="3" fill="#fff"/>`;
    else if (hatId === "hat_mohawk") hatMark = `<path d="M100 -6 112 34 100 28 88 34Z" fill="#ff5f8f"/><path d="M100 4 108 34 100 30 92 34Z" fill="#ffc857"/>`;
    else if (hatId === "hat_wizard") hatMark = `<path d="M100 -14 142 40H58Z" fill="#3b2a6b"/><path d="M100 -14 122 40H78Z" fill="#a99bff" opacity=".55"/><circle cx="100" cy="-8" r="6" fill="#ffc857"/><path d="M74 30h52" stroke="#ffc857" stroke-width="3"/>`;
    else if (hatId === "hat_halo") hatMark = `<ellipse cx="100" cy="6" rx="40" ry="11" fill="none" stroke="#ffc857" stroke-width="6"/><ellipse cx="100" cy="6" rx="40" ry="11" fill="none" stroke="#fff6d0" stroke-width="2"/>`;
    else if (hatId === "hat_dragon") hatMark = `<path d="M62 40c0-24 17-38 38-38s38 14 38 38Z" fill="#5ff0b6"/><path d="M68 24 54 6l18 4ZM132 24 146 6l-18 4Z" fill="#0d4a37"/><circle cx="86" cy="30" r="5" fill="#0f1a33"/><circle cx="114" cy="30" r="5" fill="#0f1a33"/><path d="M92 40c5 4 11 4 16 0" stroke="#0d4a37" stroke-width="3" fill="none" stroke-linecap="round"/>`;

    /* ---- backpack ---- */
    let packMark = "";
    if (packId === "pack_std") packMark = `<rect x="47" y="120" width="7" height="26" rx="3" fill="${c.trim}" opacity=".55"/><rect x="146" y="120" width="7" height="26" rx="3" fill="${c.trim}" opacity=".55"/>`;
    else if (packId === "pack_slim") packMark = `<rect x="44" y="116" width="20" height="58" rx="9" fill="${bodyDark}"/><rect x="136" y="116" width="20" height="58" rx="9" fill="${bodyDark}"/>`;
    else if (packId === "pack_twin") packMark = `<path d="M55 176v18M145 176v18" stroke="#ff7d7d" stroke-width="7" stroke-linecap="round"/><path d="M55 194c0 8 3 12 6 16M145 194c0 8-3 12-6 16" stroke="#ffb347" stroke-width="5" fill="none" stroke-linecap="round"/>`;
    else if (packId === "pack_solar") packMark = `<rect x="40" y="112" width="30" height="34" rx="3" fill="#4fe3ff" opacity=".9"/><rect x="130" y="112" width="30" height="34" rx="3" fill="#4fe3ff" opacity=".9"/><path d="M40 124h30M40 136h30M55 112v34M130 124h30M130 136h30M145 112v34" stroke="#0c1934" stroke-width="1.4"/>`;
    else if (packId === "pack_cargo") packMark = `<rect x="38" y="110" width="34" height="40" rx="5" fill="#c9a06a"/><rect x="128" y="110" width="34" height="40" rx="5" fill="#c9a06a"/><path d="M38 126h34M55 110v40M128 126h34M145 110v40" stroke="#7a5a34" stroke-width="2"/>`;
    else if (packId === "pack_jet") packMark = `<rect x="44" y="112" width="22" height="52" rx="9" fill="#8b98b8"/><rect x="134" y="112" width="22" height="52" rx="9" fill="#8b98b8"/><path d="M55 164c0 14 3 22 0 30-3-8 0-16 0-30ZM145 164c0 14-3 22 0 30 3-8 0-16 0-30Z" fill="#ffb347"/>`;
    else if (packId === "pack_reactor") packMark = `<circle cx="55" cy="140" r="17" fill="#0f1a33" stroke="#5ff0b6" stroke-width="3"/><circle cx="55" cy="140" r="7" fill="#5ff0b6"/><circle cx="145" cy="140" r="17" fill="#0f1a33" stroke="#5ff0b6" stroke-width="3"/><circle cx="145" cy="140" r="7" fill="#5ff0b6"/>`;
    else if (packId === "pack_wings") packMark = `<path d="M44 118 4 96v34l40 20Z" fill="#4fe3ff" opacity=".8"/><path d="M156 118 196 96v34l-40 20Z" fill="#4fe3ff" opacity=".8"/><path d="M44 118 4 96M156 118 196 96" stroke="#7fd8ff" stroke-width="2"/>`;
    else if (packId === "pack_blackhole") packMark = `<circle cx="55" cy="140" r="18" fill="#05070f"/><ellipse cx="55" cy="140" rx="26" ry="8" fill="none" stroke="#a99bff" stroke-width="3"/><circle cx="145" cy="140" r="18" fill="#05070f"/><ellipse cx="145" cy="140" rx="26" ry="8" fill="none" stroke="#a99bff" stroke-width="3"/>`;

    /* ---- boots ---- */
    let bootMark = "";
    if (bootId === "boot_red") bootMark = `<rect x="62" y="228" width="38" height="9" rx="4.5" fill="#ff7d7d"/><rect x="100" y="228" width="38" height="9" rx="4.5" fill="#ff7d7d"/>`;
    else if (bootId === "boot_steel") bootMark = `<rect x="58" y="234" width="46" height="12" rx="4" fill="#c9d3e8"/><rect x="96" y="234" width="46" height="12" rx="4" fill="#c9d3e8"/>`;
    else if (bootId === "boot_spring") bootMark = `<path d="M70 244c0 8 4 12 8 12M130 244c0 8-4 12-8 12" stroke="#ffc857" stroke-width="5" fill="none" stroke-linecap="round"/>`;
    else if (bootId === "boot_ice") bootMark = `<path d="M62 246h38M100 246h38" stroke="#7fd8ff" stroke-width="4"/><path d="M72 246v8M90 246v8M110 246v8M128 246v8" stroke="#7fd8ff" stroke-width="3"/>`;
    else if (bootId === "boot_rocket") bootMark = `<path d="M74 244c0 12 4 18 8 24 4-6 8-12 8-24ZM112 244c0 12 4 18 8 24 4-6 8-12 8-24Z" fill="#ffb347"/>`;
    else if (bootId === "boot_plasma") bootMark = `<rect x="62" y="230" width="38" height="7" fill="#ff5f8f"/><rect x="100" y="230" width="38" height="7" fill="#ff5f8f"/><rect x="62" y="240" width="38" height="7" fill="#ff5f8f"/><rect x="100" y="240" width="38" height="7" fill="#ff5f8f"/>`;
    else if (bootId === "boot_gravity") bootMark = `<circle cx="81" cy="238" r="9" fill="none" stroke="#a99bff" stroke-width="3"/><circle cx="81" cy="238" r="3" fill="#a99bff"/><circle cx="119" cy="238" r="9" fill="none" stroke="#a99bff" stroke-width="3"/><circle cx="119" cy="238" r="3" fill="#a99bff"/>`;

    /* ---- gloves ---- */
    let gloveMark = "";
    if (gloveId === "glove_blue") gloveMark = `<circle cx="48" cy="182" r="10" fill="#4fe3ff"/><circle cx="152" cy="182" r="10" fill="#4fe3ff"/>`;
    else if (gloveId === "glove_armor") gloveMark = `<circle cx="48" cy="182" r="11" fill="#c9d3e8"/><circle cx="152" cy="182" r="11" fill="#c9d3e8"/><path d="M42 178h12M146 178h12" stroke="#6c7793" stroke-width="2"/>`;
    else if (gloveId === "glove_heater") gloveMark = `<circle cx="48" cy="182" r="10" fill="#ff7d7d"/><circle cx="152" cy="182" r="10" fill="#ff7d7d"/><path d="M48 176c3 4 3 7 0 10-3-3-3-6 0-10ZM152 176c3 4 3 7 0 10-3-3-3-6 0-10Z" fill="#fff6d0"/>`;
    else if (gloveId === "glove_tool") gloveMark = `<circle cx="48" cy="182" r="10" fill="#ffc857"/><circle cx="152" cy="182" r="10" fill="#ffc857"/><circle cx="48" cy="182" r="4" fill="#0f1a33"/><circle cx="152" cy="182" r="4" fill="#0f1a33"/>`;
    else if (gloveId === "glove_plasma") gloveMark = `<circle cx="48" cy="182" r="11" fill="#4fe3ff" opacity=".85"/><circle cx="152" cy="182" r="11" fill="#4fe3ff" opacity=".85"/><path d="M42 176 50 182 44 186 52 192M146 176 154 182 148 186 156 192" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    else if (gloveId === "glove_gauntlet") gloveMark = `<circle cx="48" cy="182" r="12" fill="#c9a06a"/><circle cx="152" cy="182" r="12" fill="#c9a06a"/><circle cx="44" cy="178" r="3" fill="#ffc857"/><circle cx="52" cy="178" r="3" fill="#4fe3ff"/><circle cx="44" cy="186" r="3" fill="#ff7d7d"/><circle cx="52" cy="186" r="3" fill="#a99bff"/><circle cx="148" cy="178" r="3" fill="#ffc857"/><circle cx="156" cy="178" r="3" fill="#4fe3ff"/><circle cx="148" cy="186" r="3" fill="#ff7d7d"/><circle cx="156" cy="186" r="3" fill="#a99bff"/>`;
    else if (gloveId === "glove_star") gloveMark = `<circle cx="48" cy="182" r="11" fill="#ffc857"/><circle cx="152" cy="182" r="11" fill="#ffc857"/><path d="M48 175 50 180 55 180 51 183 53 188 48 185 43 188 45 183 41 180 46 180ZM152 175 154 180 159 180 155 183 157 188 152 185 147 188 149 183 145 180 150 180Z" fill="#fff6d0"/>`;

    /* ---- cape ---- */
    let capeMark = "";
    if (capeId === "cape_short") capeMark = `<path d="M62 118h76l-10 62H72Z" fill="#ff7d7d" opacity=".9"/>`;
    else if (capeId === "cape_hero") capeMark = `<path d="M60 116h80l-8 88-32-16-32 16Z" fill="#4fe3ff" opacity=".9"/>`;
    else if (capeId === "cape_thermal") capeMark = `<path d="M60 116h80l-8 88-32-16-32 16Z" fill="#e8eeff" opacity=".92"/><path d="M70 130h60M74 152h52M78 174h44" stroke="#9dabc8" stroke-width="2.4"/>`;
    else if (capeId === "cape_aurora") capeMark = `<path d="M60 116h80l-8 88-32-16-32 16Z" fill="#5ff0b6" opacity=".9"/><path d="M80 118h40l-4 78-16-8-16 8Z" fill="#a99bff" opacity=".7"/>`;
    else if (capeId === "cape_void") capeMark = `<path d="M60 116h80l-8 88-32-16-32 16Z" fill="#05070f"/><path d="M60 116h80l-8 88-32-16-32 16Z" fill="none" stroke="#a99bff" stroke-width="2.4"/>`;
    else if (capeId === "cape_comet") capeMark = `<path d="M60 116h80l-8 88-32-16-32 16Z" fill="#7fd8ff" opacity=".9"/><path d="M88 122h24l-4 70-8-4-8 4Z" fill="#fff6d0" opacity=".85"/>`;

    /* ---- pet ---- */
    let petMark = "";
    if (petId === "pet_orb") petMark = `<circle cx="176" cy="196" r="17" fill="#4fe3ff" opacity=".9"/><circle cx="170" cy="192" r="3.4" fill="#0c1934"/><circle cx="182" cy="192" r="3.4" fill="#0c1934"/><path d="M169 203c4 3 10 3 14 0" stroke="#0c1934" stroke-width="2.2" fill="none" stroke-linecap="round"/>`;
    else if (petId === "pet_star") petMark = `<path d="M176 176 182 192 199 192 185 202 190 219 176 209 162 219 167 202 153 192 170 192Z" fill="#ffc857"/><circle cx="170" cy="196" r="2.6" fill="#0f1a33"/><circle cx="182" cy="196" r="2.6" fill="#0f1a33"/>`;
    else if (petId === "pet_moon") petMark = `<path d="M176 178c-12 0-21 10-21 22s9 22 21 22c-7-5-11-13-11-22s4-17 11-22Z" fill="#e8eeff"/><path d="M186 184c-8 3-13 10-13 16s5 13 13 16c-5-5-8-11-8-16s3-11 8-16Z" fill="#c3cbe6"/>`;
    else if (petId === "pet_rover") petMark = `<rect x="156" y="188" width="40" height="18" rx="4" fill="#c9d3e8"/><circle cx="163" cy="210" r="6" fill="#6c7793"/><circle cx="176" cy="210" r="6" fill="#6c7793"/><circle cx="189" cy="210" r="6" fill="#6c7793"/><rect x="166" y="180" width="20" height="9" rx="3" fill="#4fe3ff"/>`;
    else if (petId === "pet_fox") petMark = `<path d="M160 186 156 170l12 7ZM192 186 196 170l-12 7Z" fill="#ff9d5c"/><circle cx="176" cy="200" r="18" fill="#ff9d5c"/><circle cx="169" cy="196" r="3.4" fill="#0f1a33"/><circle cx="183" cy="196" r="3.4" fill="#0f1a33"/><path d="M176 205l-4 4h8Z" fill="#0f1a33"/>`;
    else if (petId === "pet_alien") petMark = `<ellipse cx="176" cy="198" rx="20" ry="17" fill="#5ff0b6"/><ellipse cx="169" cy="194" rx="5" ry="7" fill="#0f1a33"/><ellipse cx="183" cy="194" rx="5" ry="7" fill="#0f1a33"/><path d="M168 208c5 3 11 3 16 0" stroke="#0d4a37" stroke-width="2.2" fill="none"/><path d="M156 200 144 194M196 200 208 194" stroke="#5ff0b6" stroke-width="3.4" stroke-linecap="round"/>`;
    else if (petId === "pet_dragon") petMark = `<circle cx="176" cy="198" r="19" fill="#a99bff"/><path d="M162 184 154 172l11 4ZM190 184 198 172l-11 4Z" fill="#6b3fd0"/><circle cx="169" cy="195" r="3.4" fill="#0f1a33"/><circle cx="183" cy="195" r="3.4" fill="#0f1a33"/><path d="M169 207c4 4 10 4 14 0" stroke="#0f1a33" stroke-width="2.2" fill="none"/>`;
    else if (petId === "pet_phoenix") petMark = `<path d="M176 176c-7 9-17 12-26 10 7 7 16 10 26 10s19-3 26-10c-9 2-19-1-26-10Z" fill="#ffb347"/><path d="M176 188c-5 7-12 10-19 10 5 5 12 8 19 8s14-3 19-8c-7 0-14-3-19-10Z" fill="#ff5f8f"/><circle cx="176" cy="204" r="7" fill="#fff6d0"/>`;

    /* ---- trail ---- */
    let trailMark = "";
    if (trailId === "trail_dust") trailMark = `<circle cx="30" cy="212" r="9" fill="#9dabc8" opacity=".6"/><circle cx="16" cy="196" r="6" fill="#9dabc8" opacity=".4"/><circle cx="6" cy="180" r="4" fill="#9dabc8" opacity=".28"/>`;
    else if (trailId === "trail_spark") trailMark = `<circle cx="30" cy="214" r="6" fill="#ffb347"/><circle cx="16" cy="198" r="4.4" fill="#ffc857"/><circle cx="6" cy="182" r="3" fill="#fff6d0"/><path d="M22 226 12 236M8 210 0 218" stroke="#ffb347" stroke-width="2.6" stroke-linecap="round"/>`;
    else if (trailId === "trail_bubble") trailMark = `<circle cx="30" cy="212" r="11" fill="none" stroke="#7fd8ff" stroke-width="2.6"/><circle cx="14" cy="194" r="7" fill="none" stroke="#7fd8ff" stroke-width="2.2"/><circle cx="4" cy="178" r="4.6" fill="none" stroke="#7fd8ff" stroke-width="1.8"/>`;
    else if (trailId === "trail_star") trailMark = `<path d="M30 202 33 212 43 212 35 218 38 228 30 222 22 228 25 218 17 212 27 212Z" fill="#ffc857"/><path d="M12 184 14 191 21 191 15 195 17 202 12 198 7 202 9 195 3 191 10 191Z" fill="#fff6d0"/>`;
    else if (trailId === "trail_flame") trailMark = `<path d="M6 232c0-18 10-28 20-38 3 13 10 18 10 28 0 10-8 18-15 18s-15-3-15-8Z" fill="#ffb347"/><path d="M14 232c0-10 6-16 12-22 2 8 6 11 6 17 0 6-5 10-9 10s-9-1-9-5Z" fill="#fff6d0"/>`;
    else if (trailId === "trail_rainbow") trailMark = `<path d="M0 226c14-22 34-34 58-34" stroke="#ff7d7d" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M0 238c14-22 34-34 58-34" stroke="#ffc857" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M0 250c14-22 34-34 58-34" stroke="#5ff0b6" stroke-width="6" fill="none" stroke-linecap="round"/>`;
    else if (trailId === "trail_aurora") trailMark = `<path d="M0 234c18-26 40-38 66-38" stroke="#5ff0b6" stroke-width="9" fill="none" stroke-linecap="round" opacity=".85"/><path d="M0 250c18-26 40-38 66-38" stroke="#a99bff" stroke-width="9" fill="none" stroke-linecap="round" opacity=".7"/>`;
    else if (trailId === "trail_void") trailMark = `<ellipse cx="26" cy="212" rx="26" ry="11" fill="none" stroke="#a99bff" stroke-width="3.4" transform="rotate(-24 26 212)"/><ellipse cx="8" cy="186" rx="15" ry="6" fill="none" stroke="#a99bff" stroke-width="2.6" transform="rotate(-24 8 186)"/>`;

    let badgeMark = "";
    if (badge === "badge_rocket") {
      badgeMark = `<g transform="translate(0 -1.5)">
        <path d="M0 -7c3.4 2.6 4.6 6 4.6 9.4V6h-9.2v-3.6C-4.6 -1 -3.4 -4.4 0 -7Z" fill="#ff7d7d"/>
        <path d="M-4.6 6 -7 11 -4.6 9.6ZM4.6 6 7 11 4.6 9.6Z" fill="#ffc857"/>
      </g>`;
    } else if (badge === "badge_planet") {
      badgeMark = `<g transform="translate(0 -1)">
        <circle cx="0" cy="0" r="5.4" fill="#ffc857"/>
        <ellipse cx="0" cy="0" rx="9" ry="3" fill="none" stroke="#ff7d7d" stroke-width="1.8" transform="rotate(-18)"/>
      </g>`;
    } else if (badge === "badge_comet") {
      badgeMark = `<g transform="translate(0 -1)">
        <circle cx="2" cy="-1" r="3.4" fill="#ffc857"/>
        <path d="M-1 1 -8 6M0 -3 -7 -1M-1 -4 -7 -7" stroke="#4fe3ff" stroke-width="1.8" stroke-linecap="round"/>
      </g>`;
    } else if (badge === "badge_wings") {
      badgeMark = `<g transform="translate(0 -1)">
        <path d="M0 -6h2v12h-2Z" fill="#ffc857"/>
        <path d="M0 -5 -9 -8v5l9 3Z" fill="#ffc857"/><path d="M2 -5 11 -8v5l-9 3Z" fill="#ffc857"/>
        <circle cx="1" cy="-7" r="2.4" fill="#ff7d7d"/>
      </g>`;
    } else if (badge === "badge_shield") {
      badgeMark = `<g transform="translate(0 -1)">
        <path d="M0 -8 8 -5v6c0 5-4 8-8 10-4-2-8-5-8-10v-6Z" fill="#4fe3ff" opacity=".9"/>
        <path d="M0 -5v11" stroke="#0c1934" stroke-width="1.4"/>
      </g>`;
    } else if (badge === "badge_flame") {
      badgeMark = `<g transform="translate(0 -1)">
        <path d="M0 -8c3 4 6 6 6 10a6 6 0 0 1-12 0c0-4 3-6 6-10Z" fill="#ffb347"/>
        <path d="M0 -3c1.6 2 3 3 3 5a3 3 0 0 1-6 0c0-2 1.4-3 3-5Z" fill="#fff6d0"/>
      </g>`;
    } else if (badge === "badge_eye") {
      badgeMark = `<g transform="translate(0 -1)">
        <ellipse cx="0" cy="0" rx="9" ry="5.6" fill="#0f1a33"/>
        <circle cx="0" cy="0" r="3.4" fill="#4fe3ff"/><circle cx="0" cy="0" r="1.4" fill="#fff"/>
        <path d="M-9 0 -13 -4M9 0 13 -4" stroke="#a99bff" stroke-width="1.6" stroke-linecap="round"/>
      </g>`;
    } else if (badge === "badge_laurel") {
      badgeMark = `<g transform="translate(0 -1)">
        <path d="M0 5c-5 0-9-3-10-7 4 0 7 2 9 5" fill="#5ff0b6"/>
        <path d="M0 5c5 0 9-3 10-7-4 0-7 2-9 5" fill="#5ff0b6"/>
        <circle cx="0" cy="-4" r="3.6" fill="#ffc857"/>
      </g>`;
    } else if (badge === "badge_galaxy") {
      badgeMark = `<g transform="translate(0 -1)">
        <ellipse cx="0" cy="0" rx="10" ry="4.4" fill="none" stroke="#a99bff" stroke-width="1.8" transform="rotate(-22)"/>
        <circle cx="0" cy="0" r="3" fill="#fff6d0"/>
        <circle cx="-8" cy="-3" r="1.2" fill="#4fe3ff"/><circle cx="8" cy="3" r="1.2" fill="#ffc857"/>
      </g>`;
    }

    const svgOut = `
<svg viewBox="0 0 200 260" width="100%" role="img" aria-label="${o.label || "A cadet astronaut"}">
  <defs>
    <linearGradient id="bd-s" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${shadeColor(c.body, .16)}"/>
      <stop offset="55%" stop-color="${c.body}"/>
      <stop offset="100%" stop-color="${bodyDark}"/>
    </linearGradient>
    <linearGradient id="bd-visor" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${shadeColor(visorFill, .35)}" stop-opacity="${visorOpacity}"/>
      <stop offset="52%" stop-color="${visorFill}" stop-opacity="${visorOpacity}"/>
      <stop offset="100%" stop-color="${shadeColor(visorFill, -.45)}" stop-opacity="${visorOpacity}"/>
    </linearGradient>
    <linearGradient id="bd-glass" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="60%" stop-color="#fff" stop-opacity=".06"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
    <radialGradient id="bd-glow" cx="50%" cy="50%" r="50%">
      <stop offset="55%" stop-color="${c.accent}" stop-opacity=".22"/>
      <stop offset="100%" stop-color="${c.accent}" stop-opacity="0"/>
    </radialGradient>
    <filter id="bd-sh" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#000" flood-opacity=".45"/>
    </filter>
  </defs>

  <ellipse cx="100" cy="128" rx="96" ry="120" fill="url(#bd-glow)"/>
  ${trailMark}

  <g filter="url(#bd-sh)">
    <!-- cape (behind everything) -->
    ${capeMark}

    <!-- backpack -->
    <rect x="42" y="112" width="26" height="62" rx="12" fill="${bodyDark}"/>
    <rect x="132" y="112" width="26" height="62" rx="12" fill="${bodyDark}"/>
    ${packMark}

    <!-- legs -->
    <rect x="70" y="196" width="24" height="40" rx="11" fill="url(#bd-s)"/>
    <rect x="106" y="196" width="24" height="40" rx="11" fill="url(#bd-s)"/>
    <rect x="66" y="228" width="32" height="15" rx="7" fill="${bodyDark}"/>
    <rect x="102" y="228" width="32" height="15" rx="7" fill="${bodyDark}"/>
    <rect x="62" y="236" width="38" height="9" rx="4.5" fill="${c.trim}"/>
    <rect x="100" y="236" width="38" height="9" rx="4.5" fill="${c.trim}"/>
    ${bootMark}

    <!-- arms -->
    <rect x="44" y="130" width="21" height="52" rx="10.5" fill="url(#bd-s)" transform="rotate(9 54 156)"/>
    <rect x="135" y="130" width="21" height="52" rx="10.5" fill="url(#bd-s)" transform="rotate(-9 146 156)"/>
    <circle cx="48" cy="182" r="10" fill="${bodyMid}"/>
    <circle cx="152" cy="182" r="10" fill="${bodyMid}"/>
    ${gloveMark}

    <!-- torso -->
    <path d="M76 116h48c9 0 16 7 16 16v46c0 9-7 16-16 16H76c-9 0-16-7-16-16v-46c0-9 7-16 16-16Z" fill="url(#bd-s)"/>
    <path d="M62 128c0-7 6-12 14-12h8v82h-8c-8 0-14-6-14-13Z" fill="#fff" opacity=".07"/>
    <rect x="60" y="168" width="80" height="9" fill="${c.trim}" opacity=".85"/>
    <rect x="62" y="176" width="76" height="4" fill="${bodyDark}" opacity=".5"/>

    <!-- badge -->
    <g transform="translate(100 132)">
      <circle cx="0" cy="0" r="13" fill="${bodyDark}" opacity=".55"/>
      <circle cx="0" cy="0" r="10.5" fill="${c.accent}" opacity=".22"/>
      <circle cx="0" cy="0" r="10.5" fill="none" stroke="${c.trim}" stroke-width="1.6" opacity=".9"/>
      ${badgeMark}
    </g>

    <!-- helmet -->
    <circle cx="100" cy="76" r="46" fill="${shadeColor(c.body, .06)}"/>
    <circle cx="100" cy="76" r="46" fill="none" stroke="${c.trim}" stroke-width="3"/>
    <circle cx="100" cy="76" r="40" fill="url(#bd-visor)"/>
    <circle cx="100" cy="76" r="40" fill="none" stroke="${bodyDark}" stroke-width="1.2" opacity=".5"/>
    <ellipse cx="84" cy="60" rx="16" ry="11" fill="url(#bd-glass)" transform="rotate(-24 84 60)"/>
    <ellipse cx="112" cy="92" rx="8" ry="5" fill="#fff" opacity=".14" transform="rotate(-24 112 92)"/>
    <!-- little face -->
    <g fill="#eaf6ff" opacity=".92">
      <circle cx="88" cy="74" r="3.4"/><circle cx="112" cy="74" r="3.4"/>
    </g>
    <path d="M92 86c5 4 11 4 16 0" stroke="#eaf6ff" stroke-width="2.6" fill="none" stroke-linecap="round" opacity=".9"/>
    ${antenna}${crest}${ringHalo}${surveyDome}${reactorCowl}${crystalShell}${commanderCrown}${eventHorizon}
    ${hatMark}

    <!-- helmet collar -->
    <rect x="70" y="112" width="60" height="10" rx="5" fill="${bodyDark}"/>
    <rect x="70" y="112" width="60" height="4" rx="2" fill="${c.trim}" opacity=".8"/>
  </g>
  ${petMark}
</svg>`;
    return svgOut.split("bd-").join(u + "-");
  }

  function shadeColor(hex, amt) {
    const h = hex.replace("#", "");
    const n = parseInt(h.length === 3 ? h.split("").map(x => x + x).join("") : h, 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    if (amt >= 0) {
      r = Math.round(r + (255 - r) * amt); g = Math.round(g + (255 - g) * amt); b = Math.round(b + (255 - b) * amt);
    } else {
      r = Math.round(r * (1 + amt)); g = Math.round(g * (1 + amt)); b = Math.round(b * (1 + amt));
    }
    return "#" + [r, g, b].map(v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0")).join("");
  }

  /* ---- small shop thumbnails ---- */
  function thumb(kind, item, equip) {
    if (kind === "suit") {
      const c = item.colors;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <defs><linearGradient id="th-${item.id}" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="${shadeColor(c.body, .18)}"/><stop offset="100%" stop-color="${shadeColor(c.body, -.3)}"/>
        </linearGradient></defs>
        <rect x="30" y="46" width="40" height="40" rx="12" fill="url(#th-${item.id})" stroke="${c.trim}" stroke-width="2"/>
        <rect x="43" y="44" width="14" height="44" fill="${c.trim}" opacity=".7"/>
        <circle cx="50" cy="30" r="19" fill="${shadeColor(c.body, .05)}" stroke="${c.trim}" stroke-width="2.4"/>
        <circle cx="50" cy="30" r="14" fill="${c.visor}" opacity=".92"/>
        <ellipse cx="44" cy="24" rx="6" ry="4" fill="#fff" opacity=".35" transform="rotate(-25 44 24)"/>
      </svg>`;
    }
    if (kind === "helmet") {
      const c = equip ? equip.colors : SUITS[0].colors;
      let extra = "";
      if (item.id === "helm_gold") extra = "";
      if (item.id === "helm_horn") extra = `<rect x="48" y="8" width="4" height="14" rx="2" fill="${c.trim}"/><ellipse cx="50" cy="7" rx="12" ry="5" fill="${c.trim}"/>`;
      if (item.id === "helm_star") extra = `<path d="M50 4 53 11 60 11 55 15 57 22 50 18 43 22 45 15 40 11 47 11Z" fill="#ffc857"/>`;
      const vf = item.id === "helm_gold" ? "#ffcf4d" : "#2b3f66";
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        ${extra}
        <circle cx="50" cy="52" r="32" fill="${shadeColor(c.body, .12)}" stroke="${c.trim}" stroke-width="3"/>
        <circle cx="50" cy="52" r="25" fill="${vf}"/>
        <ellipse cx="41" cy="42" rx="9" ry="6" fill="#fff" opacity=".32" transform="rotate(-25 41 42)"/>
        <ellipse cx="60" cy="66" rx="5" ry="3" fill="#fff" opacity=".13"/>
        <rect x="26" y="80" width="48" height="8" rx="4" fill="${shadeColor(c.body, -.25)}"/>
      </svg>`;
    }
    const c = equip ? equip.colors : SUITS[0].colors;
    const base = shadeColor(c.body, .1);

    if (kind === "visor") {
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <circle cx="50" cy="50" r="34" fill="${shadeColor(c.body, .12)}" stroke="${c.trim}" stroke-width="3"/>
        <path d="M22 46a28 28 0 0 1 56 0v10a28 28 0 0 1-56 0Z" fill="${item.tint}" opacity="${item.alpha}"/>
        <ellipse cx="38" cy="42" rx="9" ry="5" fill="#fff" opacity=".3" transform="rotate(-22 38 42)"/>
        <ellipse cx="62" cy="60" rx="5" ry="3" fill="#fff" opacity=".12"/>
      </svg>`;
    }
    if (kind === "hat") {
      let g = "";
      if (item.id === "hat_cap") g = `<path d="M26 40h48v10H26Z" fill="#2b3f66"/><path d="M74 40h16v6H74Z" fill="#1b2745"/>`;
      else if (item.id === "hat_beanie") g = `<path d="M28 44a22 22 0 0 1 44 0Z" fill="#ff7d7d"/><rect x="26" y="42" width="48" height="9" rx="4" fill="#ffd9a8"/>`;
      else if (item.id === "hat_headset") g = `<path d="M26 46a24 24 0 0 1 48 0" fill="none" stroke="#4fe3ff" stroke-width="4"/><rect x="18" y="42" width="12" height="18" rx="5" fill="#4fe3ff"/><rect x="70" y="42" width="12" height="18" rx="5" fill="#4fe3ff"/><path d="M76 60c0 10-8 14-16 14" stroke="#4fe3ff" stroke-width="3" fill="none"/>`;
      else if (item.id === "hat_tophat") g = `<rect x="30" y="14" width="40" height="30" rx="3" fill="#0f1a33"/><rect x="20" y="42" width="60" height="8" rx="4" fill="#0f1a33"/><rect x="30" y="34" width="40" height="6" fill="#ffc857"/>`;
      else if (item.id === "hat_antennae") g = `<path d="M40 40 32 20M60 40 68 20" stroke="#5ff0b6" stroke-width="3" stroke-linecap="round"/><circle cx="32" cy="18" r="5" fill="#5ff0b6"/><circle cx="68" cy="18" r="5" fill="#5ff0b6"/>`;
      else if (item.id === "hat_mohawk") g = `<path d="M50 8 58 30 50 26 42 30Z" fill="#ff5f8f"/><path d="M50 14 55 30 50 27 45 30Z" fill="#ffc857"/>`;
      else if (item.id === "hat_wizard") g = `<path d="M50 6 74 44H26Z" fill="#3b2a6b"/><path d="M50 6 62 44H38Z" fill="#a99bff" opacity=".6"/><circle cx="50" cy="10" r="4" fill="#ffc857"/>`;
      else if (item.id === "hat_halo") g = `<ellipse cx="50" cy="18" rx="24" ry="7" fill="none" stroke="#ffc857" stroke-width="4"/><ellipse cx="50" cy="18" rx="24" ry="7" fill="none" stroke="#fff6d0" stroke-width="1.6"/>`;
      else if (item.id === "hat_dragon") g = `<path d="M30 40c0-14 10-22 20-22s20 8 20 22Z" fill="#5ff0b6"/><path d="M34 30 26 20l10 2ZM66 30 74 20l-10 2Z" fill="#0d4a37"/><circle cx="42" cy="34" r="3" fill="#0f1a33"/><circle cx="58" cy="34" r="3" fill="#0f1a33"/>`;
      else g = `<circle cx="50" cy="50" r="30" fill="none" stroke="${c.trim}" stroke-width="2" opacity=".4"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <circle cx="50" cy="58" r="26" fill="${base}" stroke="${c.trim}" stroke-width="2.4"/>
        ${g}
      </svg>`;
    }
    if (kind === "backpack") {
      let g = "";
      if (item.id === "pack_std") g = `<rect x="34" y="30" width="14" height="40" rx="7" fill="#9dabc8"/><rect x="52" y="30" width="14" height="40" rx="7" fill="#9dabc8"/>`;
      else if (item.id === "pack_slim") g = `<rect x="40" y="28" width="20" height="44" rx="8" fill="#9dabc8"/>`;
      else if (item.id === "pack_twin") g = `<rect x="34" y="30" width="14" height="40" rx="7" fill="#9dabc8"/><rect x="52" y="30" width="14" height="40" rx="7" fill="#9dabc8"/><path d="M41 70v10M59 70v10" stroke="#ff7d7d" stroke-width="4" stroke-linecap="round"/>`;
      else if (item.id === "pack_solar") g = `<rect x="30" y="30" width="40" height="30" rx="4" fill="#4fe3ff" opacity=".85"/><path d="M30 40h40M30 50h40M43 30v30M57 30v30" stroke="#0c1934" stroke-width="1.4"/>`;
      else if (item.id === "pack_cargo") g = `<rect x="28" y="28" width="44" height="44" rx="6" fill="#c9a06a"/><path d="M28 44h44M50 28v44" stroke="#7a5a34" stroke-width="2"/>`;
      else if (item.id === "pack_jet") g = `<rect x="36" y="28" width="28" height="40" rx="8" fill="#8b98b8"/><path d="M42 68c0 10 3 16 8 22 5-6 8-12 8-22Z" fill="#ffb347"/>`;
      else if (item.id === "pack_reactor") g = `<circle cx="50" cy="48" r="20" fill="#0f1a33" stroke="#5ff0b6" stroke-width="3"/><circle cx="50" cy="48" r="9" fill="#5ff0b6"/><circle cx="50" cy="48" r="4" fill="#fff"/>`;
      else if (item.id === "pack_wings") g = `<path d="M50 40 14 26v22l36 12Z" fill="#4fe3ff" opacity=".8"/><path d="M50 40 86 26v22L50 60Z" fill="#4fe3ff" opacity=".8"/>`;
      else if (item.id === "pack_blackhole") g = `<circle cx="50" cy="48" r="22" fill="#05070f"/><ellipse cx="50" cy="48" rx="30" ry="9" fill="none" stroke="#a99bff" stroke-width="3"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <rect x="30" y="24" width="40" height="52" rx="12" fill="${shadeColor(c.body, -.2)}" stroke="${c.trim}" stroke-width="2"/>
        ${g}
      </svg>`;
    }
    if (kind === "boots") {
      let g = "";
      if (item.id === "boot_red") g = `<rect x="24" y="30" width="52" height="14" fill="#ff7d7d"/>`;
      else if (item.id === "boot_steel") g = `<rect x="20" y="52" width="60" height="12" rx="3" fill="#c9d3e8"/>`;
      else if (item.id === "boot_spring") g = `<path d="M30 58c0 8 4 12 8 12M70 58c0 8-4 12-8 12" stroke="#ffc857" stroke-width="4" fill="none"/>`;
      else if (item.id === "boot_ice") g = `<path d="M26 60h48" stroke="#7fd8ff" stroke-width="4"/><path d="M34 60v8M50 60v8M66 60v8" stroke="#7fd8ff" stroke-width="3"/>`;
      else if (item.id === "boot_rocket") g = `<path d="M38 62c0 10 4 16 12 22 8-6 12-12 12-22Z" fill="#ffb347"/>`;
      else if (item.id === "boot_plasma") g = `<rect x="24" y="34" width="52" height="10" fill="#ff5f8f"/><rect x="24" y="50" width="52" height="10" fill="#ff5f8f"/>`;
      else if (item.id === "boot_gravity") g = `<circle cx="50" cy="46" r="14" fill="none" stroke="#a99bff" stroke-width="3"/><circle cx="50" cy="46" r="5" fill="#a99bff"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <path d="M30 20h16v34h20a8 8 0 0 1 8 8v10H30Z" fill="${base}" stroke="${c.trim}" stroke-width="2.4"/>
        <path d="M30 62h44v10H30Z" fill="${shadeColor(c.body, -.3)}"/>
        ${g}
      </svg>`;
    }
    if (kind === "gloves") {
      let g = "";
      if (item.id === "glove_blue") g = `<rect x="30" y="30" width="40" height="12" fill="#4fe3ff"/>`;
      else if (item.id === "glove_armor") g = `<rect x="28" y="34" width="44" height="10" rx="3" fill="#c9d3e8"/><rect x="28" y="50" width="44" height="10" rx="3" fill="#c9d3e8"/>`;
      else if (item.id === "glove_heater") g = `<path d="M50 30c6 8 6 14 0 20-6-6-6-12 0-20Z" fill="#ff7d7d"/>`;
      else if (item.id === "glove_tool") g = `<circle cx="38" cy="46" r="5" fill="#ffc857"/><circle cx="62" cy="46" r="5" fill="#ffc857"/>`;
      else if (item.id === "glove_plasma") g = `<path d="M34 40 44 48 36 52 48 62" stroke="#4fe3ff" stroke-width="3" fill="none" stroke-linecap="round"/>`;
      else if (item.id === "glove_gauntlet") g = `<circle cx="36" cy="40" r="4" fill="#ffc857"/><circle cx="50" cy="36" r="4" fill="#4fe3ff"/><circle cx="64" cy="40" r="4" fill="#ff7d7d"/><circle cx="40" cy="56" r="4" fill="#a99bff"/><circle cx="60" cy="56" r="4" fill="#5ff0b6"/>`;
      else if (item.id === "glove_star") g = `<path d="M50 34 53 44 63 44 55 50 58 60 50 54 42 60 45 50 37 44 47 44Z" fill="#ffc857"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <path d="M32 26h36v22a18 18 0 0 1-36 0Z" fill="${base}" stroke="${c.trim}" stroke-width="2.4"/>
        <rect x="32" y="60" width="36" height="16" rx="6" fill="${shadeColor(c.body, -.22)}"/>
        ${g}
      </svg>`;
    }
    if (kind === "cape") {
      let g = "";
      if (item.id === "cape_short") g = `<path d="M30 30h40l-6 34H36Z" fill="#ff7d7d"/>`;
      else if (item.id === "cape_hero") g = `<path d="M30 28h40l-4 46-16-8-16 8Z" fill="#4fe3ff"/>`;
      else if (item.id === "cape_thermal") g = `<path d="M30 28h40l-4 46-16-8-16 8Z" fill="#e8eeff" opacity=".9"/><path d="M36 36h28M38 48h24M40 60h20" stroke="#9dabc8" stroke-width="2"/>`;
      else if (item.id === "cape_aurora") g = `<path d="M30 28h40l-4 46-16-8-16 8Z" fill="#5ff0b6"/><path d="M40 30h20l-2 40-8-4-8 4Z" fill="#a99bff" opacity=".7"/>`;
      else if (item.id === "cape_void") g = `<path d="M30 28h40l-4 46-16-8-16 8Z" fill="#05070f"/><path d="M30 28h40l-4 46-16-8-16 8Z" fill="none" stroke="#a99bff" stroke-width="2"/>`;
      else if (item.id === "cape_comet") g = `<path d="M30 28h40l-4 46-16-8-16 8Z" fill="#7fd8ff"/><path d="M44 34h12l-2 34-4-2-4 2Z" fill="#fff6d0" opacity=".8"/>`;
      else g = `<path d="M34 30h32l-4 40-12-6-12 6Z" fill="${c.trim}" opacity=".35"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
        <circle cx="50" cy="24" r="9" fill="${base}" stroke="${c.trim}" stroke-width="2"/>
        ${g}
      </svg>`;
    }
    if (kind === "pet") {
      let g = "";
      if (item.id === "pet_orb") g = `<circle cx="50" cy="50" r="20" fill="#4fe3ff" opacity=".85"/><circle cx="43" cy="45" r="4" fill="#0c1934"/><circle cx="57" cy="45" r="4" fill="#0c1934"/><path d="M42 58c5 4 11 4 16 0" stroke="#0c1934" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
      else if (item.id === "pet_star") g = `<path d="M50 22 58 44 82 44 62 58 70 82 50 68 30 82 38 58 18 44 42 44Z" fill="#ffc857"/><circle cx="43" cy="48" r="3" fill="#0f1a33"/><circle cx="57" cy="48" r="3" fill="#0f1a33"/>`;
      else if (item.id === "pet_moon") g = `<path d="M50 24c-14 0-24 12-24 26s10 26 24 26c-8-6-12-16-12-26s4-20 12-26Z" fill="#e8eeff"/><path d="M62 30c-10 4-16 12-16 20s6 16 16 20c-6-6-9-13-9-20s3-14 9-20Z" fill="#c3cbe6"/>`;
      else if (item.id === "pet_rover") g = `<rect x="26" y="40" width="48" height="22" rx="5" fill="#c9d3e8"/><circle cx="34" cy="66" r="7" fill="#6c7793"/><circle cx="50" cy="66" r="7" fill="#6c7793"/><circle cx="66" cy="66" r="7" fill="#6c7793"/><rect x="40" y="30" width="20" height="10" rx="3" fill="#4fe3ff"/>`;
      else if (item.id === "pet_fox") g = `<path d="M30 34 26 18l14 8ZM70 34 74 18 60 26Z" fill="#ff9d5c"/><circle cx="50" cy="50" r="22" fill="#ff9d5c"/><circle cx="42" cy="46" r="4" fill="#0f1a33"/><circle cx="58" cy="46" r="4" fill="#0f1a33"/><path d="M50 56l-5 5h10Z" fill="#0f1a33"/>`;
      else if (item.id === "pet_alien") g = `<ellipse cx="50" cy="48" rx="24" ry="20" fill="#5ff0b6"/><ellipse cx="42" cy="44" rx="6" ry="8" fill="#0f1a33"/><ellipse cx="58" cy="44" rx="6" ry="8" fill="#0f1a33"/><path d="M40 60c6 4 14 4 20 0" stroke="#0d4a37" stroke-width="2.4" fill="none"/><path d="M26 52 12 44M74 52 88 44" stroke="#5ff0b6" stroke-width="4" stroke-linecap="round"/>`;
      else if (item.id === "pet_dragon") g = `<path d="M50 24c-16 0-26 12-26 26s10 26 26 26 26-12 26-26-10-26-26-26Z" fill="#a99bff"/><path d="M34 30 26 18l12 4ZM66 30 74 18l-12 4Z" fill="#6b3fd0"/><circle cx="42" cy="46" r="4" fill="#0f1a33"/><circle cx="58" cy="46" r="4" fill="#0f1a33"/><path d="M42 60c5 5 11 5 16 0" stroke="#0f1a33" stroke-width="2.4" fill="none"/>`;
      else if (item.id === "pet_phoenix") g = `<path d="M50 20c-8 10-20 14-30 12 8 8 18 12 30 12s22-4 30-12c-10 2-22-2-30-12Z" fill="#ffb347"/><path d="M50 34c-6 8-14 12-22 12 6 6 14 10 22 10s16-4 22-10c-8 0-16-4-22-12Z" fill="#ff5f8f"/><circle cx="50" cy="52" r="8" fill="#fff6d0"/>`;
      else g = `<circle cx="50" cy="50" r="18" fill="none" stroke="${c.trim}" stroke-width="2" stroke-dasharray="4 4" opacity=".5"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">${g}</svg>`;
    }
    if (kind === "trail") {
      let g = "";
      if (item.id === "trail_dust") g = `<circle cx="30" cy="60" r="7" fill="#9dabc8" opacity=".7"/><circle cx="46" cy="52" r="5" fill="#9dabc8" opacity=".5"/><circle cx="60" cy="46" r="3.5" fill="#9dabc8" opacity=".35"/>`;
      else if (item.id === "trail_spark") g = `<circle cx="28" cy="62" r="5" fill="#ffb347"/><circle cx="44" cy="54" r="4" fill="#ffc857"/><circle cx="58" cy="46" r="3" fill="#fff6d0"/><path d="M20 70 12 78M36 62 30 72" stroke="#ffb347" stroke-width="2.4" stroke-linecap="round"/>`;
      else if (item.id === "trail_bubble") g = `<circle cx="30" cy="60" r="9" fill="none" stroke="#7fd8ff" stroke-width="2.4"/><circle cx="50" cy="48" r="6" fill="none" stroke="#7fd8ff" stroke-width="2"/><circle cx="64" cy="40" r="4" fill="none" stroke="#7fd8ff" stroke-width="1.8"/>`;
      else if (item.id === "trail_star") g = `<path d="M28 60 31 68 39 68 33 73 35 81 28 76 21 81 23 73 17 68 25 68Z" fill="#ffc857"/><path d="M52 44 54 50 60 50 55 54 57 60 52 56 47 60 49 54 44 50 50 50Z" fill="#fff6d0"/>`;
      else if (item.id === "trail_flame") g = `<path d="M20 74c0-14 8-22 16-30 2 10 8 14 8 22 0 8-6 14-12 14s-12-2-12-6Z" fill="#ffb347"/><path d="M26 74c0-8 5-13 10-18 1 6 5 9 5 14 0 5-4 8-8 8s-7-1-7-4Z" fill="#fff6d0"/>`;
      else if (item.id === "trail_rainbow") g = `<path d="M14 70c10-16 26-24 44-24" stroke="#ff7d7d" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M14 78c10-16 26-24 44-24" stroke="#ffc857" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M14 86c10-16 26-24 44-24" stroke="#5ff0b6" stroke-width="5" fill="none" stroke-linecap="round"/>`;
      else if (item.id === "trail_aurora") g = `<path d="M12 76c14-20 30-30 50-30" stroke="#5ff0b6" stroke-width="7" fill="none" stroke-linecap="round" opacity=".85"/><path d="M12 86c14-20 30-30 50-30" stroke="#a99bff" stroke-width="7" fill="none" stroke-linecap="round" opacity=".7"/>`;
      else if (item.id === "trail_void") g = `<ellipse cx="34" cy="62" rx="20" ry="9" fill="none" stroke="#a99bff" stroke-width="3" transform="rotate(-24 34 62)"/><ellipse cx="58" cy="46" rx="12" ry="5" fill="none" stroke="#a99bff" stroke-width="2.4" transform="rotate(-24 58 46)"/>`;
      else g = `<path d="M20 70c12-14 26-20 42-20" stroke="${c.trim}" stroke-width="3" fill="none" stroke-dasharray="5 6" opacity=".5"/>`;
      return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">${g}</svg>`;
    }

    let glyph = "";
    if (item.id === "badge_rocket") glyph = `<path d="M50 34c4 3 6 8 6 12v8H44v-8c0-4 2-9 6-12Z" fill="#ff7d7d"/><path d="M44 54 40 61l4-2ZM56 54 60 61l-4-2Z" fill="#ffc857"/>`;
    if (item.id === "badge_planet") glyph = `<circle cx="50" cy="52" r="10" fill="#ffc857"/><ellipse cx="50" cy="52" rx="17" ry="5" fill="none" stroke="#ff7d7d" stroke-width="3" transform="rotate(-18 50 52)"/>`;
    if (item.id === "badge_comet") glyph = `<circle cx="55" cy="48" r="6" fill="#ffc857"/><path d="M48 52 36 60M52 45 40 44M49 41 40 35" stroke="#4fe3ff" stroke-width="3" stroke-linecap="round"/>`;
    if (item.id === "badge_wings") glyph = `<path d="M50 44h4v18h-4Z" fill="#ffc857"/><path d="M50 46 30 40v10l20 6Z" fill="#ffc857"/><path d="M54 46 74 40v10l-20 6Z" fill="#ffc857"/><circle cx="52" cy="42" r="4" fill="#ff7d7d"/>`;
    if (item.id === "badge_shield") glyph = `<path d="M50 34 66 40v12c0 10-8 16-16 20-8-4-16-10-16-20V40Z" fill="#4fe3ff" opacity=".9"/><path d="M50 40v22" stroke="#0c1934" stroke-width="2"/>`;
    if (item.id === "badge_flame") glyph = `<path d="M50 34c6 8 12 12 12 20a12 12 0 0 1-24 0c0-8 6-12 12-20Z" fill="#ffb347"/><path d="M50 44c3 4 6 6 6 10a6 6 0 0 1-12 0c0-4 3-6 6-10Z" fill="#fff6d0"/>`;
    if (item.id === "badge_eye") glyph = `<ellipse cx="50" cy="52" rx="18" ry="11" fill="#0f1a33"/><circle cx="50" cy="52" r="7" fill="#4fe3ff"/><circle cx="50" cy="52" r="3" fill="#fff"/><path d="M32 52 24 44M68 52 76 44" stroke="#a99bff" stroke-width="2.4" stroke-linecap="round"/>`;
    if (item.id === "badge_laurel") glyph = `<path d="M50 62c-10 0-18-6-20-14 8 0 14 4 18 10" fill="#5ff0b6"/><path d="M50 62c10 0 18-6 20-14-8 0-14 4-18 10" fill="#5ff0b6"/><circle cx="50" cy="44" r="7" fill="#ffc857"/>`;
    if (item.id === "badge_galaxy") glyph = `<ellipse cx="50" cy="52" rx="20" ry="9" fill="none" stroke="#a99bff" stroke-width="3" transform="rotate(-22 50 52)"/><circle cx="50" cy="52" r="6" fill="#fff6d0"/><circle cx="34" cy="46" r="2" fill="#4fe3ff"/><circle cx="66" cy="58" r="2" fill="#ffc857"/>`;
    if (item.id === "badge_none") glyph = `<circle cx="50" cy="52" r="6" fill="${c.trim}" opacity=".5"/>`;
    return `<svg viewBox="0 0 100 100" role="img" aria-label="${item.name}">
      <circle cx="50" cy="52" r="30" fill="${c.accent}" opacity=".16"/>
      <circle cx="50" cy="52" r="30" fill="none" stroke="${c.trim}" stroke-width="2.5"/>
      ${glyph}
    </svg>`;
  }

  /* ---- medal ---- */
  function medal(hue) {
    const u = "md" + (++__uid);
    const out = `<svg viewBox="0 0 120 120" role="img" aria-label="Mission medal">
      <defs>
        <radialGradient id="md-g" cx="34%" cy="28%" r="76%">
          <stop offset="0%" stop-color="#fff6cf"/><stop offset="48%" stop-color="#ffc857"/><stop offset="100%" stop-color="#b8781a"/>
        </radialGradient>
      </defs>
      <path d="M40 8 52 44 34 52 24 18Z" fill="hsl(${hue} 90% 62%)" opacity=".9"/>
      <path d="M80 8 68 44 86 52 96 18Z" fill="hsl(${hue} 90% 46%)" opacity=".9"/>
      <circle cx="60" cy="72" r="36" fill="url(#md-g)"/>
      <circle cx="60" cy="72" r="29" fill="none" stroke="#8a5a10" stroke-width="2" opacity=".45"/>
      <circle cx="60" cy="72" r="22" fill="#0f1730" opacity=".18"/>
      <path d="M60 52 65 66 80 66 68 75 72 90 60 81 48 90 52 75 40 66 55 66Z" fill="#fff8dc" opacity=".95"/>
      <circle cx="44" cy="56" r="8" fill="#fff" opacity=".28"/>
    </svg>`;
    return out.split("md-").join(u + "-");
  }

  return { planet, scene, cadet, thumb, medal, shadeColor };
})();
/*@@END_JS_ART@@*/
/* ============================================================
   3. STATE — persistence, scoring guards, rewards
   ============================================================ */
const SAVE_KEY = (window.AstroAuth && AstroAuth.saveKey()) || "astrocadet.v3.save";
const LEGACY_KEYS = ["astrocadet.v2.save", "astrocadet.save"];

/* Every cosmetic slot, with the free starter item that is always owned. */
const SLOT_DEFAULTS = {
  suit:"suit_classic", helmet:"helm_bubble", visor:"visor_clear", hat:"hat_none",
  backpack:"pack_std", boots:"boot_std", gloves:"glove_std", cape:"cape_none",
  pet:"pet_none", badge:"badge_none", trail:"trail_none"
};

const DEFAULT_STATE = () => ({
  name: "",
  stars: 0,
  earnedTotal: 0,
  completed: [],          // stage ids fully finished (first completion pays out)
  stageStars: {},         // stage id -> best correct count (0..3)
  stageAttempts: {},      // stage id -> number of quiz attempts
  scoredQuestions: {},    // "stage:q" -> true once that question has ever paid out
  lessonSeen: {},         // "stage:lesson" -> true
  planetsSeen: {},        // planet id -> true
  owned: Object.values(SLOT_DEFAULTS),
  equipped: Object.assign({}, SLOT_DEFAULTS),
  achievements: [],
  pipAsked: 0,
  settings: { sound: true, voice: false, calm: false },
  createdAt: Date.now(),
  version: 3
});

const Store = {
  state: null,

  load() {
    try {
      let raw = localStorage.getItem(SAVE_KEY);
      if (!raw) {
        // migrate an older save rather than wiping a child's progress
        for (const k of LEGACY_KEYS) {
          const old = localStorage.getItem(k);
          if (old) { raw = old; break; }
        }
      }
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      const base = DEFAULT_STATE();
      const owned = Array.isArray(parsed.owned) && parsed.owned.length ? parsed.owned.slice() : base.owned.slice();
      // make sure every slot's starter item is present, even from an old save
      Object.values(SLOT_DEFAULTS).forEach(id => { if (!owned.includes(id)) owned.push(id); });
      return Object.assign(base, parsed, {
        settings: Object.assign(base.settings, parsed.settings || {}),
        equipped: Object.assign({}, SLOT_DEFAULTS, parsed.equipped || {}),
        owned,
        completed: Array.isArray(parsed.completed) ? parsed.completed : [],
        achievements: Array.isArray(parsed.achievements) ? parsed.achievements : [],
        stageStars: parsed.stageStars || {},
        stageAttempts: parsed.stageAttempts || {},
        scoredQuestions: parsed.scoredQuestions || {},
        lessonSeen: parsed.lessonSeen || {},
        planetsSeen: parsed.planetsSeen || {},
        version: 3
      });
    } catch (e) {
      console.warn("Could not read save:", e);
      return null;
    }
  },

  save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn("Could not write save:", e);
    }
  },

  reset() {
    try {
      localStorage.removeItem(SAVE_KEY);
      LEGACY_KEYS.forEach(k => localStorage.removeItem(k));
    } catch (e) {}
  }
};

/* ---------- sound ---------- */
const Sound = {
  enabled: true,
  ctx: null,
  ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) this.ctx = new AC();
    }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
    return this.ctx;
  },
  tone(freq, type, dur, gainVal) {
    if (!this.enabled) return;
    const ctx = this.ensure();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type || "sine";
      osc.frequency.value = freq;
      const g = gainVal == null ? 0.07 : gainVal;
      gain.gain.setValueAtTime(g, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0008, ctx.currentTime + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + dur);
    } catch (e) {}
  },
  click() { this.tone(560, "sine", 0.07, 0.05); },
  success() {
    if (!this.enabled) return;
    this.tone(523.25, "triangle", 0.12, 0.07);
    setTimeout(() => this.tone(659.25, "triangle", 0.12, 0.07), 95);
    setTimeout(() => this.tone(783.99, "triangle", 0.2, 0.07), 190);
  },
  wrong() { this.tone(210, "sawtooth", 0.16, 0.05); },
  coin() {
    if (!this.enabled) return;
    this.tone(880, "square", 0.07, 0.045);
    setTimeout(() => this.tone(1320, "square", 0.1, 0.04), 70);
  },
  fanfare() {
    if (!this.enabled) return;
    [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.tone(f, "triangle", 0.22, 0.075), i * 110));
  }
};

/* ---------- speech (Web Speech API) ----------
   Rules that keep this safe and pleasant:
   - nothing is ever spoken before a real user gesture (browser autoplay policy)
   - the global toggle is persisted, and defaults to OFF
   - a new line always cancels the previous one, so cards never talk over each other
   ------------------------------------------------------------ */
const Talk = {
  enabled: false,          // must be switched on; never speaks before a click
  supported: "speechSynthesis" in window,
  voice: null,
  unlocked: false,         // becomes true after the first user gesture
  speaking: false,

  /* Pick a friendly, high-pitched English voice when one is available. */
  pickVoice() {
    if (!this.supported) return null;
    try {
      const voices = window.speechSynthesis.getVoices() || [];
      if (!voices.length) return null;
      const wanted = (window.AstroLanguage && window.AstroLanguage.get()) || document.documentElement.lang || "en";
      const poolWanted = voices.filter(v => (v.lang || "").toLowerCase().startsWith(wanted.toLowerCase()));
      const en = voices.filter(v => /^en(-|_|$)/i.test(v.lang || ""));
      const pool = poolWanted.length ? poolWanted : (en.length ? en : voices);
      const prefer = [
        /google uk english female/i, /google us english/i, /samantha/i, /karen/i,
        /moira/i, /tessa/i, /zira/i, /female/i, /natural/i
      ];
      for (const re of prefer) {
        const hit = pool.find(v => re.test(v.name || ""));
        if (hit) return hit;
      }
      return pool[0];
    } catch (e) { return null; }
  },

  init() {
    if (!this.supported) return;
    this.voice = this.pickVoice();
    try {
      window.speechSynthesis.onvoiceschanged = () => { this.voice = this.pickVoice(); };
    } catch (e) {}
  },

  /* Called from a real click handler so the browser allows audio. */
  unlock() {
    if (!this.supported || this.unlocked) return;
    this.unlocked = true;
    try {
      const u = new SpeechSynthesisUtterance(" ");
      u.volume = 0;
      window.speechSynthesis.speak(u);
    } catch (e) {}
  },

  say(text, opts) {
    if (!this.enabled || !this.supported) return false;
    const sourceText = String(text == null ? "" : text);
    const localizedText = window.AstroLanguage ? window.AstroLanguage.translate(sourceText) : sourceText;
    const clean = String(localizedText)
      .replace(/[★☆•→←✓✔]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!clean) return false;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(clean);
      if (!this.voice) this.voice = this.pickVoice();
      const wanted = (window.AstroLanguage && window.AstroLanguage.get()) || document.documentElement.lang || "en";
      if (this.voice) { u.voice = this.voice; u.lang = this.voice.lang || (wanted === "ar" ? "ar-EG" : wanted === "es" ? "es-ES" : "en-US"); }
      else u.lang = wanted === "ar" ? "ar-EG" : wanted === "es" ? "es-ES" : "en-US";
      const o = opts || {};
      u.pitch = o.pitch == null ? 1.22 : o.pitch;   // a touch high = friendly robot
      u.rate = o.rate == null ? 0.97 : o.rate;      // slightly slow for young readers
      u.volume = o.volume == null ? 0.95 : o.volume;
      u.onstart = () => { this.speaking = true; };
      u.onend = () => { this.speaking = false; };
      u.onerror = () => { this.speaking = false; };
      window.speechSynthesis.speak(u);
      return true;
    } catch (e) { return false; }
  },

  /* Read a whole lesson card: heading, body, then Astro's note. */
  sayCard(stage, lesson) {
    if (!lesson) return false;
    const parts = [lesson.h + "."];
    (lesson.p || []).forEach(p => parts.push(p));
    if (lesson.note) parts.push("Astro's note. " + lesson.note);
    return this.say(parts.join(" "), { rate: 0.95 });
  },

  stop() {
    if (!this.supported) return;
    try { window.speechSynthesis.cancel(); } catch (e) {}
    this.speaking = false;
  }
};

/* ---------- scoring guard ----------
   Two independent locks:
   (a) question-level: answered[] per quiz session, plus a data-answered
       attribute the click handler checks before anything else.
   (b) stage-level: a stage pays out only if it is not in state.completed.
   ------------------------------------------------------------ */
const Award = {
  points(n, reason) {
    const s = Store.state;
    s.stars += n;
    s.earnedTotal += n;
    Store.save();
    UI.syncHUD();
    UI.toast(`+${n} stars${reason ? " · " + reason : ""}`, "mint");
    Sound.coin();
  },
  completeStage(stage) {
    const s = Store.state;
    if (s.completed.includes(stage.id)) return { already: true, bonus: 0 };
    s.completed.push(stage.id);
    s.completed.sort((a, b) => a - b);
    s.stars += STAGE_BONUS;
    s.earnedTotal += STAGE_BONUS;
    Store.save();
    return { already: false, bonus: STAGE_BONUS };
  },
  lessonSeen(stageId, idx) {
    const s = Store.state;
    const key = stageId + ":" + idx;
    if (s.lessonSeen[key]) return 0;
    s.lessonSeen[key] = true;
    s.stars += LESSON_POINTS;
    s.earnedTotal += LESSON_POINTS;
    Store.save();
    return LESSON_POINTS;
  },
  /* A small training stipend for replaying a finished mission, so a cadet who
     really wants a legendary item can keep flying for it. */
  practiceStipend() {
    const s = Store.state;
    s.stars += PRACTICE_STIPEND;
    s.earnedTotal += PRACTICE_STIPEND;
    Store.save();
    return PRACTICE_STIPEND;
  },
  planetSeen(id) {
    const s = Store.state;
    if (s.planetsSeen[id]) return 0;
    s.planetsSeen[id] = true;
    s.stars += PLANET_POINTS;
    s.earnedTotal += PLANET_POINTS;
    Store.save();
    return PLANET_POINTS;
  }
};

/* ---------- progression ---------- */
const Progress = {
  unlocked(stageId) {
    // Mission 1 is always open. A mission opens when the one before it is finished.
    if (stageId === 1) return true;
    return Store.state.completed.includes(stageId - 1) || Store.state.completed.includes(stageId);
  },
  isDone(stageId) { return Store.state.completed.includes(stageId); },
  nextStage() {
    const next = STAGES.find(st => !Store.state.completed.includes(st.id));
    return next || null;
  },
  rank() {
    const done = Store.state.completed.length;
    const tiers = [
      { at: 0,  name: "Space Trainee" },
      { at: 1,  name: "Star Scout" },
      { at: 2,  name: "Rocket Cadet" },
      { at: 3,  name: "Systems Pilot" },
      { at: 4,  name: "Orbit Engineer" },
      { at: 5,  name: "Navigator" },
      { at: 6,  name: "Flight Officer" },
      { at: 7,  name: "Weather Officer" },
      { at: 8,  name: "EVA Specialist" },
      { at: 9,  name: "Launch Engineer" },
      { at: 10, name: "Satellite Controller" },
      { at: 11, name: "Orbit Physician" },
      { at: 12, name: "Deep Sky Astronomer" },
      { at: 13, name: "Colony Architect" },
      { at: 14, name: "Astro Commander" },
      { at: 15, name: "Academy Legend" }
    ];
    let name = tiers[0].name, idx = 0;
    tiers.forEach((t, i) => { if (done >= t.at) { name = t.name; idx = i; } });
    const pct = Math.round((done / STAGES.length) * 100);
    return { name, pct, index: idx };
  }
};

/* ---------- cosmetics ---------- */
const Shop = {
  itemList(kind) {
    const tab = COSMETIC_TABS.find(t => t.key === kind);
    return tab ? tab.list : [];
  },
  find(id) {
    for (const tab of COSMETIC_TABS) {
      const found = tab.list.find(i => i.id === id);
      if (found) return { kind: tab.key, item: found };
    }
    return null;
  },
  rarity(item) { return RARITY[(item && item.rarity) || "common"] || RARITY.common; },
  owns(id) { return Store.state.owned.includes(id); },
  price(id) { const f = this.find(id); return f ? f.item.price : 0; },
  equipped(kind) { return Store.state.equipped[kind]; },
  currentSuit() {
    return SUITS.find(s => s.id === Store.state.equipped.suit) || SUITS[0];
  },
  /* Everything the avatar renderer needs, in one object. */
  look() {
    const e = Store.state.equipped;
    return {
      suit: e.suit, helmet: e.helmet, visor: e.visor, hat: e.hat,
      backpack: e.backpack, boots: e.boots, gloves: e.gloves,
      cape: e.cape, pet: e.pet, badge: e.badge, trail: e.trail
    };
  },
  ownedCount() { return Store.state.owned.length; },
  totalCount() { return COSMETIC_TABS.reduce((n, t) => n + t.list.length, 0); },
  buy(id) {
    const found = this.find(id);
    if (!found) return { ok: false, msg: "That item is not in the shop." };
    const { kind, item } = found;
    const s = Store.state;
    if (s.owned.includes(id)) {
      this.equip(id);
      return { ok: true, msg: "Equipped!" };
    }
    if (s.stars < item.price) {
      const need = item.price - s.stars;
      return { ok: false, msg: `You need ${need} more star${need === 1 ? "" : "s"} for that. Try a mission quiz!`, short: true };
    }
    s.stars -= item.price;
    s.owned.push(id);
    s.equipped[kind] = id;
    Store.save();
    Sound.success();
    return { ok: true, msg: `${item.name} unlocked and equipped!` };
  },
  equip(id) {
    const found = this.find(id);
    if (!found) return false;
    if (!Store.state.owned.includes(id)) return false;
    Store.state.equipped[found.kind] = id;
    Store.save();
    Sound.click();
    return true;
  }
};

/* ---------- achievements ---------- */
const Trophies = {
  check(silent) {
    const s = Store.state;
    const unlocked = [];
    ACHIEVEMENTS.forEach(a => {
      const has = s.achievements.includes(a.id);
      if (!has) {
        let ok = false;
        try { ok = a.test(s); } catch (e) { ok = false; }
        if (ok) {
          s.achievements.push(a.id);
          unlocked.push(a);
        }
      }
    });
    if (unlocked.length) {
      Store.save();
      if (!silent) {
        unlocked.forEach(a => UI.toast(`Trophy unlocked: ${a.name}`, "mint"));
      }
    }
    return unlocked;
  },
  has(id) { return Store.state.achievements.includes(id); },
  earnedCount() { return Store.state.achievements.length; }
};
/*@@END_JS_STATE@@*/
/* ============================================================
   4. UI — views and shared widgets
   ============================================================ */
const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
const esc = str => String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const UI = {
  view: "missions",
  shopTab: "suit",

  /* Switching tabs must ALWAYS work, even from inside a finished level.
     Any open overlay (mission sheet, planet file, settings) is torn down
     first, the mission session is cleaned up, and the target view is
     rendered in the same action — so there is never a stale level card
     sitting on top of the tab the child just asked for. */
  go(name) {
    this.exitOverlays();
    this.view = name;
    $$(".view").forEach(v => v.classList.toggle("is-active", v.id === "view-" + name));
    $$(".tab").forEach(t => t.classList.toggle("is-active", t.dataset.view === name));
    if (name === "missions") this.renderMissions();
    if (name === "planets") this.renderPlanets();
    if (name === "cadet") this.renderCadet();
    if (name === "trophies") this.renderTrophies();
    window.scrollTo({ top: 0, behavior: "smooth" });
    Sound.click();
  },

  /* Close every overlay and stop any running mission/activity loop.
     This is what makes tab switching work from inside a finished level:
     the level sheet is torn down and the target view rendered in the same
     action, so no stale level card can sit on top of the new tab. */
  exitOverlays() {
    try { Session.cleanup(); } catch (e) {}
    try { Session.stage = null; } catch (e) {}
    try { Talk.stop(); } catch (e) {}
    $$(".overlay.is-open").forEach(ov => ov.classList.remove("is-open"));
    document.body.classList.remove("is-locked");
  },

  syncHUD() {
    const s = Store.state;
    const hs = $("#hudStars");
    if (hs) hs.textContent = s.stars;
    const rank = Progress.rank();
    const hr = $("#hudRank");
    if (hr) hr.textContent = rank.name;
    const rf = $("#rankFill");
    if (rf) rf.style.width = rank.pct + "%";
    const launcher = $("#pipLauncherAvatar");
    if (launcher) launcher.innerHTML = ART.thumb("suit", Shop.currentSuit());
    const head = $("#pipHeadAvatar");
    if (head) head.innerHTML = ART.thumb("suit", Shop.currentSuit());
  },

  toast(msg, tone) {
    const wrap = $("#toastWrap");
    if (!wrap) return;
    const el = document.createElement("div");
    el.className = "toast " + (tone || "");
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 320); }, 2600);
  },

  open(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add("is-open");
    document.body.classList.add("is-locked");
  },
  close(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("is-open");
    if (!$$(".overlay.is-open").length) document.body.classList.remove("is-locked");
  },

  confetti() {
    if (Store.state.settings.calm) return;
    const canvas = $("#confetti");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const colors = ["#4fe3ff", "#5ff0b6", "#ffc857", "#ff7d7d", "#a99bff"];
    const parts = Array.from({ length: 90 }, () => ({
      x: window.innerWidth / 2 + (Math.random() - 0.5) * 240,
      y: window.innerHeight * 0.42 + (Math.random() - 0.5) * 60,
      vx: (Math.random() - 0.5) * 9,
      vy: -Math.random() * 11 - 3,
      r: Math.random() * 5 + 2.5,
      c: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * 6,
      vr: (Math.random() - 0.5) * 0.3,
      life: 1
    }));
    let frame = 0;
    (function tick() {
      frame++;
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      parts.forEach(p => {
        p.vy += 0.34;
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;
        p.life -= 0.008;
        if (p.life <= 0) return;
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.life);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.c;
        ctx.fillRect(-p.r, -p.r * 0.55, p.r * 2, p.r * 1.1);
        ctx.restore();
      });
      if (frame < 140) requestAnimationFrame(tick);
      else ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    })();
  },

  /* ---------------- MISSIONS ---------------- */
  renderMissions() {
    const s = Store.state;
    const root = $("#view-missions");
    const next = Progress.nextStage();
    const done = s.completed.length;
    const totalStars = s.stars;
    const rank = Progress.rank();
    const planetsSeen = Object.keys(s.planetsSeen).length;

    const ctaLabel = done === 0 ? "Start Mission 1" : (next ? `Continue: Mission ${next.id}` : "Review a mission");
    const ctaTarget = next ? next.id : STAGES[0].id;

    let heroArt = "";
    try {
      heroArt = ART.planet(PLANETS[done % PLANETS.length], 240);
    } catch (e) { heroArt = ""; }

    root.innerHTML = `
      <div class="hero">
        <div>
          <span class="eyebrow">🚀 Astronaut Jr · cadet ${esc(s.name || "recruit")}</span>
          <h2>Hey ${esc(s.name || "Cadet")}, ${done === 0 ? "ready for your first" : done >= STAGES.length ? "you finished every" : "ready for the next"} <em>mission</em>?</h2>
          <p>${STAGES.length} short training missions, one at a time. Read a little, try the activity, answer three questions — and collect stars for your cadet's wardrobe.</p>
          <div class="hero-actions">
            <button class="btn btn-primary" onclick="app.openMission(${ctaTarget})">${esc(ctaLabel)} →</button>
            <button class="btn btn-ghost" onclick="app.go('planets')">🪐 Explore planets</button>
            <button class="btn btn-ghost" onclick="app.go('cadet')">🧑‍🚀 My cadet</button>
          </div>
        </div>
        <div class="hero-visual">${heroArt}</div>
      </div>

      <div class="strip">
        <div class="strip-cell"><b>${done}<span style="font-size:.9rem;color:var(--ink-faint)"> / ${STAGES.length}</span></b><span>Missions done</span></div>
        <div class="strip-cell accent"><b>${totalStars}</b><span>Stars to spend</span></div>
        <div class="strip-cell mint"><b>${rank.name}</b><span>Current rank</span></div>
        <div class="strip-cell"><b>${planetsSeen}<span style="font-size:.9rem;color:var(--ink-faint)"> / ${PLANETS.length + 1}</span></b><span>Space objects logged</span></div>
      </div>

      <div class="sec-head">
        <div>
          <h2>Training path</h2>
          <p>${done >= 7 ? "All missions complete — replay any of them to sharpen your skills." : "Finish a mission to unlock the next one. You can replay finished missions any time."}</p>
        </div>
        <button class="link" onclick="app.togglePip(true)">💬 Ask Astro for a tip</button>
      </div>

      <div class="mission-grid">
        ${STAGES.map(st => this.missionCard(st)).join("")}
      </div>

      <div class="sec-head">
        <div>
          <h2>A quick look at the planets</h2>
          <p>Tap a world to open its full file — size, distance, temperature and the strange bits.</p>
        </div>
        <button class="link" onclick="app.go('planets')">Open the planet explorer →</button>
      </div>
      <div class="planet-grid">
        ${PLANETS.map(p => `
          <button class="planet-card" onclick="app.openPlanet('${p.id}')" aria-label="Open ${p.name}">
            <span class="pv">${ART.planet(p, 100)}</span>
            <h4>${p.name}</h4>
            <small>${p.type.split("·")[1] ? p.type.split("·")[1].trim() : p.type}</small>
            ${s.planetsSeen[p.id] ? `<span class="seen">logged</span>` : ""}
          </button>`).join("")}
      </div>
    `;
  },

  missionCard(st) {
    const s = Store.state;
    const done = s.completed.includes(st.id);
    const open = Progress.unlocked(st.id);
    const best = s.stageStars[st.id] || 0;
    const status = done ? "done" : open ? "ready" : "locked";
    const statusText = done ? "✓ Complete" : open ? "Ready" : "🔒 Locked";
    const dotCount = 3;

    return `
      <button class="mission-card ${done ? "is-done" : ""} ${open ? "" : "is-locked"}"
              style="--hue:${st.hue}"
              onclick="${open ? `app.openMission(${st.id})` : "app.lockedTap(" + st.id + ")"}"
              aria-label="Mission ${st.id}: ${esc(st.title)}${done ? " (complete)" : open ? "" : " (locked)"}">
        <div class="m-top">
          <span class="m-orb">${st.emoji}</span>
          <span>
            <span class="m-num">Mission ${String(st.id).padStart(2, "0")}</span>
          </span>
          <span class="m-status ${status}">${statusText}</span>
        </div>
        <h3>${esc(st.title)}</h3>
        <p class="m-sub">${esc(st.subtitle)}</p>
        <div class="m-meta">
          <span>🎯 <i>${esc(st.skill)}</i></span>
          <span>⏱ <i>${st.lessons.length} cards</i></span>
          <span class="m-dots">${Array.from({ length: dotCount }).map((_, i) => `<span class="m-dot ${i < best ? "on" : ""}"></span>`).join("")}</span>
        </div>
      </button>`;
  },

  lockedTap(id) {
    Sound.wrong();
    const prev = STAGES.find(st => st.id === id - 1);
    this.toast(`Finish Mission ${id - 1}${prev ? " (" + prev.title + ")" : ""} first to unlock this.`, "coral");
  },

  /* ---------------- PLANETS ---------------- */
  renderPlanets() {
    const s = Store.state;
    const root = $("#view-planets");
    const all = [SUN_INFO].concat(PLANETS);
    const seen = Object.keys(s.planetsSeen).length;

    root.innerHTML = `
      <div class="hero" style="padding-bottom:22px">
        <div>
          <span class="eyebrow">🪐 Planet explorer</span>
          <h2>Nine worlds, <em>one family</em></h2>
          <p>Starting at the Sun and flying outward: read the card for each world, compare the numbers, and keep the weird facts. ${seen}/${PLANETS.length + 1} logged so far.</p>
          <div class="hero-actions">
            <button class="btn btn-primary" onclick="app.openPlanet('earth')">Start with Earth →</button>
            <button class="btn btn-ghost" onclick="app.planetTour()">▶ Take the tour</button>
          </div>
        </div>
        <div class="hero-visual">${ART.planet(SUN_INFO, 220)}</div>
      </div>

      <div class="sec-head">
        <div>
          <h2>The solar system, in order</h2>
          <p>Sizes in the pictures are not to scale — Neptune would be a speck next to the Sun.</p>
        </div>
      </div>

      <div class="planet-grid" style="grid-template-columns:1fr">
        <button class="planet-card" style="flex-direction:row;text-align:left;padding:16px;gap:16px" onclick="app.openPlanet('sun')" aria-label="Open the Sun">
          <span class="pv" style="width:84px;height:84px;flex:none">${ART.planet(SUN_INFO, 100)}</span>
          <span style="flex:1">
            <h4 style="font-size:1.05rem">The Sun</h4>
            <small style="display:block;margin:3px 0 6px">Our star</small>
            <span style="font-size:.82rem;color:var(--ink-dim);display:block">Holds 99.8% of the solar system's mass. Everything else orbits it.</span>
          </span>
          ${s.planetsSeen.sun ? `<span class="seen" style="position:static">logged</span>` : ""}
        </button>
      </div>

      <div class="planet-grid" style="margin-top:12px">
        ${PLANETS.map(p => `
          <button class="planet-card" onclick="app.openPlanet('${p.id}')" aria-label="Open ${p.name}">
            <span class="pv" style="width:88px;height:88px">${ART.planet(p, 100)}</span>
            <h4>${p.name}</h4>
            <small style="text-transform:none;letter-spacing:0;font-size:.68rem">${p.stats["Distance from Sun"]}</small>
            ${s.planetsSeen[p.id] ? `<span class="seen">logged</span>` : ""}
          </button>`).join("")}
      </div>

      <div class="sec-head">
        <div>
          <h2>Compare the numbers</h2>
          <p>Distance is measured from the Sun, in millions of kilometres.</p>
        </div>
      </div>
      <div class="activity-box" style="min-height:0">
        <div style="overflow-x:auto">
          <table style="width:100%;border-collapse:collapse;font-size:.84rem;min-width:560px">
            <thead>
              <tr style="text-align:left;color:var(--ink-faint);font-size:.68rem;letter-spacing:.1em;text-transform:uppercase">
                <th style="padding:8px 6px;border-bottom:1px solid var(--line)">Planet</th>
                <th style="padding:8px 6px;border-bottom:1px solid var(--line)">Diameter</th>
                <th style="padding:8px 6px;border-bottom:1px solid var(--line)">Distance</th>
                <th style="padding:8px 6px;border-bottom:1px solid var(--line)">Year</th>
                <th style="padding:8px 6px;border-bottom:1px solid var(--line)">Moons</th>
              </tr>
            </thead>
            <tbody>
              ${PLANETS.map(p => `
                <tr style="cursor:pointer" onclick="app.openPlanet('${p.id}')">
                  <td style="padding:9px 6px;border-bottom:1px solid rgba(126,168,255,.08);font-weight:800">${p.name}</td>
                  <td style="padding:9px 6px;border-bottom:1px solid rgba(126,168,255,.08);color:var(--ink-dim)">${p.stats["Diameter"]}</td>
                  <td style="padding:9px 6px;border-bottom:1px solid rgba(126,168,255,.08);color:var(--ink-dim)">${p.stats["Distance from Sun"]}</td>
                  <td style="padding:9px 6px;border-bottom:1px solid rgba(126,168,255,.08);color:var(--ink-dim)">${p.stats["Year length"]}</td>
                  <td style="padding:9px 6px;border-bottom:1px solid rgba(126,168,255,.08);color:var(--ink-dim)">${p.stats["Moons"]}</td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  /* ---------------- CADET ---------------- */
  renderCadet() {
    const s = Store.state;
    const root = $("#view-cadet");
    const look = Shop.look();
    const owned = s.owned.length;
    const total = Shop.totalCount();
    const tab = COSMETIC_TABS.find(t => t.key === this.shopTab) || COSMETIC_TABS[0];

    root.innerHTML = `
      <div class="cadet-layout">
        <div>
          <div class="cadet-stage">
            <div class="cadet-avatar">
              ${ART.cadet(Object.assign({}, look, { label: "Your cadet" }))}
              ${look.pet !== "pet_none" ? `<div class="pet-float">${ART.thumb("pet", Shop.find(look.pet).item, Shop.currentSuit())}</div>` : ""}
              ${look.trail !== "trail_none" ? `<div class="trail-float">${ART.thumb("trail", Shop.find(look.trail).item, Shop.currentSuit())}</div>` : ""}
            </div>
            <div class="cadet-name">${esc(s.name || "Cadet")}</div>
            <div class="cadet-title">${Progress.rank().name}</div>
            <div class="look-chips">
              ${COSMETIC_TABS.filter(t => look[t.key] && look[t.key] !== SLOT_DEFAULTS[t.key])
                .map(t => `<span class="look-chip">${t.icon} ${esc((Shop.find(look[t.key]) || { item: { name: "" } }).item.name)}</span>`).join("") || `<span class="look-chip">Starter kit</span>`}
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;z-index:1">
              <span class="pill amber">★ ${s.stars} stars</span>
              <span class="pill mint">${s.completed.length}/${STAGES.length} missions</span>
            </div>
            <button class="btn btn-ghost btn-sm" onclick="app.go('trophies')">🏆 See trophies</button>
          </div>
        </div>

        <div>
          <div class="sec-head" style="margin-top:0">
            <div>
              <h2>Cadet wardrobe</h2>
              <p>Spend the stars you earn. Everything you buy stays unlocked and equipped for good.</p>
            </div>
            <span class="pill amber">★ ${s.stars} available</span>
          </div>

          <div class="wallet-bar">
            <span>Wardrobe</span>
            <b>${owned}</b><span style="color:var(--ink-faint)">/ ${total} items</span>
            <span class="bar"><i style="width:${Math.round((owned / total) * 100)}%"></i></span>
            <span style="color:var(--ink-faint)">${Math.round((owned / total) * 100)}% collected</span>
          </div>

          <div class="shop-tabs">
            ${COSMETIC_TABS.map(t => {
              const n = t.list.filter(i => s.owned.includes(i.id)).length;
              return `<button class="shop-tab ${this.shopTab === t.key ? "is-active" : ""}" onclick="app.setShopTab('${t.key}')">
                ${t.icon} ${t.label}<span class="cnt">${n}/${t.list.length}</span></button>`;
            }).join("")}
          </div>

          <div class="shop-grid">
            ${tab.list.map(item => this.shopRow(tab.key, item)).join("")}
          </div>

          <div class="activity-box" style="margin-top:16px;min-height:0">
            <div style="display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap">
              <div style="font-size:1.4rem">💡</div>
              <div style="flex:1;min-width:200px">
                <b style="font-size:.9rem">How to earn faster</b>
                <p style="font-size:.82rem;color:var(--ink-dim);margin-top:4px">Each new lesson card is worth ${LESSON_POINTS} star and each first-try correct answer ${QUIZ_POINTS} stars. Finishing a mission for the first time adds a ${STAGE_BONUS}-star bonus, and logging a new world adds ${PLANET_POINTS}. Replaying a finished mission never pays the bonus again, and a question only ever scores once — but a practice run still pays a small ${PRACTICE_STIPEND}-star training stipend, so you can always keep flying towards the legendary gear.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  shopRow(kind, item) {
    const s = Store.state;
    const owned = s.owned.includes(item.id);
    const equipped = s.equipped[kind] === item.id;
    const affordable = s.stars >= item.price;
    const thumbSvg = ART.thumb(kind, item, Shop.currentSuit());
    const rar = Shop.rarity(item);

    let action;
    if (equipped) {
      action = `<button class="btn btn-sm btn-ghost" disabled>Equipped</button>`;
    } else if (owned) {
      action = `<button class="btn btn-sm btn-mint" onclick="app.equipItem('${item.id}')">Wear it</button>`;
    } else {
      action = `<button class="btn btn-sm ${affordable ? "btn-amber" : "btn-ghost"}" onclick="app.buyItem('${item.id}')" ${affordable ? "" : 'title="Not enough stars yet"'}>
        ${affordable ? "Buy" : "🔒 Buy"}
      </button>`;
    }

    return `
      <div class="shop-item r-${item.rarity || "common"} ${equipped ? "is-equipped" : ""}">
        <div class="shop-thumb">${thumbSvg}</div>
        <div class="shop-info">
          <h5>${esc(item.name)}</h5>
          <p>${esc(item.desc)}</p>
          <div class="shop-meta">
            <span class="rarity ${item.rarity || "common"}">${rar.label}</span>
            <span class="shop-price ${owned || affordable ? "" : "locked"}">${item.price === 0 ? "Free · starter" : "★ " + item.price}</span>
          </div>
        </div>
        <div class="shop-act">${action}</div>
      </div>`;
  },

  /* ---------------- TROPHIES ---------------- */
  renderTrophies() {
    const s = Store.state;
    const root = $("#view-trophies");
    const earned = s.achievements.length;

    root.innerHTML = `
      <div class="hero">
        <div>
          <span class="eyebrow">🏆 Trophy cabinet</span>
          <h2>${earned} of ${ACHIEVEMENTS.length} <em>trophies</em> earned</h2>
          <p>Every trophy marks something you actually did — a mission finished, a planet read, a question answered right the first time. Nothing here is bought.</p>
          <div class="hero-actions">
            <button class="btn btn-primary" onclick="app.go('missions')">Back to missions →</button>
            <button class="btn btn-ghost" onclick="app.go('planets')">🪐 Log more planets</button>
          </div>
        </div>
        <div class="hero-visual">${ART.medal(45)}</div>
      </div>

      <div class="strip">
        <div class="strip-cell"><b>${s.completed.length}/${STAGES.length}</b><span>Missions</span></div>
        <div class="strip-cell accent"><b>${s.stars}</b><span>Stars now</span></div>
        <div class="strip-cell mint"><b>${s.earnedTotal}</b><span>Stars earned all-time</span></div>
        <div class="strip-cell"><b>${Object.keys(s.planetsSeen).length}/${PLANETS.length + 1}</b><span>Worlds logged</span></div>
      </div>

      <div class="sec-head">
        <div>
          <h2>All trophies</h2>
          <p>Grey ones are still waiting for you.</p>
        </div>
      </div>
      <div class="trophy-grid">
        ${ACHIEVEMENTS.map(a => {
          const has = s.achievements.includes(a.id);
          return `<div class="trophy ${has ? "done" : ""}">
            <div class="medal-sm">${a.icon}</div>
            <div>
              <h5>${esc(a.name)}</h5>
              <p>${esc(a.desc)}</p>
            </div>
            <span class="state">${has ? "Earned" : "Locked"}</span>
          </div>`;
        }).join("")}
      </div>

      <div class="sec-head">
        <div><h2>Mission record</h2><p>Your best score on each quiz.</p></div>
      </div>
      <div class="activity-box" style="min-height:0">
        ${STAGES.map(st => {
          const done = s.completed.includes(st.id);
          const best = s.stageStars[st.id] || 0;
          return `<div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(126,168,255,.08)">
            <span style="font-size:1.1rem">${st.emoji}</span>
            <span style="flex:1;font-size:.88rem;font-weight:700">${esc(st.title)}</span>
            <span style="font-size:.72rem;color:${done ? "var(--mint)" : "var(--ink-faint)"}">${done ? "Complete" : "Not yet"}</span>
            <span class="m-dots">${[0, 1, 2].map(i => `<span class="m-dot ${i < best ? "on" : ""}"></span>`).join("")}</span>
          </div>`;
        }).join("")}
      </div>
    `;
  }
};
/*@@END_JS_VIEWS@@*/
/* ============================================================
   5. MISSIONS — lessons, activities, quiz, results
   ============================================================ */
const Session = {
  stage: null,
  phase: "lesson",
  lesson: 0,
  qIndex: 0,
  answered: [],       // per-question lock (index -> true) — set the instant it is answered
  order: [],          // per-question shuffled display order (display -> original index)
  correct: 0,
  scored: [],         // per-question: was it right on the first attempt?
  firstTryWrong: [],
  hintShown: false,
  finished: false,
  practice: false,
  earnedThisRun: 0,
  resultShown: false,
  timers: [],
  raf: null,
  listeners: [],
  activityDone: false,
  api: {},

  reset(stage) {
    this.cleanup();
    this.stage = stage;
    this.phase = "lesson";
    this.lesson = 0;
    this.qIndex = 0;
    this.answered = [];
    this.order = [];
    this.correct = 0;
    this.scored = [];
    this.firstTryWrong = [];
    this.hintShown = false;
    this.finished = false;
    this.practice = Store.state.completed.includes(stage.id);
    this.activityDone = false;
    this.earnedThisRun = 0;
    this.resultShown = false;
    this.api = {};
  },

  cleanup() {
    this.timers.forEach(t => clearTimeout(t));
    this.timers = [];
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.listeners.forEach(([el, ev, fn]) => { try { el.removeEventListener(ev, fn); } catch (e) {} });
    this.listeners = [];
    if (typeof this.api.stop === "function") { try { this.api.stop(); } catch (e) {} }
    this.api = {};
  },

  later(fn, ms) {
    const t = setTimeout(fn, ms);
    this.timers.push(t);
    return t;
  }
};

const Mission = {
  open(stageId) {
    const stage = STAGES.find(s => s.id === stageId);
    if (!stage) return;
    if (!Progress.unlocked(stageId)) { UI.lockedTap(stageId); return; }
    Session.reset(stage);
    UI.open("missionOverlay");
    this.render();
    if (!Session.practice) sound_open();
  },

  close() {
    Session.cleanup();
    UI.close("missionOverlay");
    UI.renderMissions();
    UI.syncHUD();
  },

  render() {
    const st = Session.stage;
    if (!st) return;
    $("#missionKicker").textContent = `Mission ${String(st.id).padStart(2, "0")} · ${st.skill}`;
    $("#missionTitle").textContent = st.title;

    const dots = $("#lessonDots");
    const total = st.lessons.length + 1 + 1;
    const pos = Session.phase === "lesson" ? Session.lesson
      : Session.phase === "activity" ? st.lessons.length
      : Session.phase === "quiz" ? st.lessons.length + 1
      : total - 1;
    dots.innerHTML = Array.from({ length: total }).map((_, i) => `<i class="${i <= pos ? "on" : ""}"></i>`).join("");

    if (Session.phase === "lesson") this.renderLesson();
    else if (Session.phase === "activity") this.renderActivity();
    else if (Session.phase === "quiz") this.renderQuiz();
    else this.renderResult();
  },

  /* ---------------- lessons ---------------- */
  renderLesson() {
    const st = Session.stage;
    const l = st.lessons[Session.lesson];
    const last = Session.lesson === st.lessons.length - 1;
    const gained = Award.lessonSeen(st.id, Session.lesson);

    if (gained > 0) {
      UI.syncHUD();
      UI.toast(`+${gained} stars · lesson read`, "mint");
    }

    $("#missionBody").innerHTML = `
      <div class="lesson-wrap">
        <div class="lesson-art">${ART.scene(st.art)}</div>
        <div class="lesson-copy">
          <div class="lesson-topline">
            <span class="pill">Card ${Session.lesson + 1} of ${st.lessons.length}</span>
            <button class="speak-btn" id="cardSpeak" onclick="app.speakCard()"
                    aria-label="Read this card aloud" title="Read this card aloud">
              <span class="spk-ico">🔊</span><span class="spk-txt">Read to me</span>
            </button>
          </div>
          <h3 style="margin-top:10px">${esc(l.h)}</h3>
          ${l.p.map(p => `<p>${esc(p)}</p>`).join("")}
          ${l.note ? `<div class="lesson-note"><b>Astro's note:</b> ${esc(l.note)}</div>` : ""}
          <div class="voice-line" id="voiceLine">
            <span class="vl-ico">🤖</span>
            <span><b>Astro says:</b> ${esc(this.voiceLine(st, Session.lesson))}</span>
          </div>
        </div>
      </div>
    `;

    $("#missionFoot").innerHTML = `
      <span style="font-size:.76rem;color:var(--ink-faint)">
        ${Session.practice ? "Practice run · stars already collected" : "★ " + LESSON_POINTS + " stars per card"}
      </span>
      <span style="margin-left:auto;display:flex;gap:8px;flex-wrap:wrap">
        ${Session.lesson > 0 ? `<button class="btn btn-ghost btn-sm" onclick="app.lessonPrev()">← Back</button>` : ""}
        <button class="btn btn-primary btn-sm" onclick="app.lessonNext()">
          ${last ? "Try the activity →" : "Next card →"}
        </button>
      </span>
    `;

    this.syncSpeakBtn();
    /* Astro speaks the card automatically when voice is on — but only ever
       after the child has already clicked something (Talk.unlock). */
    if (Talk.enabled) {
      Session.later(() => Talk.sayCard(st, l), 320);
    }
  },

  /* A short, friendly spoken line for each card. Falls back to the heading
     plus the first sentence when a card has no bespoke line. */
  voiceLine(stage, idx) {
    const l = stage.lessons[idx];
    if (!l) return "";
    if (l.voice) return l.voice;
    const first = (l.p && l.p[0]) ? l.p[0].split(". ")[0] : "";
    return `Card ${idx + 1}: ${l.h}. ${first}.`;
  },

  syncSpeakBtn() {
    const btn = $("#cardSpeak");
    if (!btn) return;
    const on = Talk.enabled && Talk.supported;
    btn.classList.toggle("is-on", on);
    const txt = $(".spk-txt", btn);
    if (txt) txt.textContent = on ? "Reading aloud" : "Read to me";
    btn.setAttribute("aria-pressed", String(on));
  },

  /* Speaker button on a card: a real click, so it also unlocks speech. */
  speakCard() {
    const st = Session.stage;
    if (!st) return;
    Talk.unlock();
    if (!Talk.supported) { UI.toast("This browser cannot read aloud.", "coral"); return; }
    if (!Talk.enabled) {
      /* First press turns voice on for the whole app and reads the card. */
      Store.state.settings.voice = true;
      Talk.enabled = true;
      Store.save();
      app.syncToggles();
      UI.toast("Voice on — Astro will read the cards to you.", "mint");
    }
    const l = st.lessons[Session.lesson];
    Talk.sayCard(st, l);
    this.syncSpeakBtn();
    Sound.click();
  },

  lessonNext() {
    Sound.click();
    const st = Session.stage;
    if (Session.lesson < st.lessons.length - 1) {
      Session.lesson++;
      this.render();
      $("#missionBody").scrollTop = 0;
    } else {
      Session.phase = "activity";
      this.render();
    }
  },

  lessonPrev() {
    Sound.click();
    if (Session.lesson > 0) { Session.lesson--; this.render(); }
  },

  /* ---------------- activity ---------------- */
  renderActivity() {
    const st = Session.stage;
    const a = st.activity;
    const head = `
      <div class="activity-head">
        <span class="pill amber">Hands-on</span>
        <b style="font-size:.95rem">${esc(a.title)}</b>
      </div>
      <p class="activity-hint">${a.hint}</p>
    `;

    let body = "";
    if (a.type === "constellation") body = this.actConstellation();
    else if (a.type === "thrust") body = this.actThrust();
    else if (a.type === "systems") body = this.actSystems();
    else if (a.type === "zerog") body = this.actZeroG();
    else if (a.type === "orbit") body = this.actOrbit();
    else if (a.type === "comms") body = this.actComms();
    else if (a.type === "shield") body = this.actShield();
    else if (a.type === "order") body = this.actOrder();
    else if (a.type === "pick") body = this.actPick();
    else if (a.type === "focus") body = this.actFocus();
    else body = this.actLander();

    $("#missionBody").innerHTML = head + `<div class="activity-box" id="activityBox">${body}</div>
      <div id="activityFeedback"></div>`;

    $("#missionFoot").innerHTML = `
      <button class="btn btn-ghost btn-sm" onclick="app.lessonPrevFromActivity()">← Read the cards again</button>
      <span style="margin-left:auto;font-size:.76rem;color:var(--ink-faint)">Finish the activity to open the quiz</span>
    `;

    Session.activityDone = false;
    if (this["init_" + a.type]) this["init_" + a.type]();
  },

  lessonPrevFromActivity() {
    Session.cleanup();
    Session.phase = "lesson";
    Session.lesson = Session.stage.lessons.length - 1;
    Session.activityDone = false;
    this.render();
  },

  activityComplete(message) {
    if (Session.activityDone) return;
    Session.activityDone = true;
    const fb = $("#activityFeedback");
    if (fb) {
      fb.innerHTML = `<div class="explain" style="margin-top:14px">
        <h5>Activity complete</h5>
        <p>${esc(message)}</p>
      </div>`;
    }
    Sound.success();
    Pip.say(message, "cheer", true);
    const foot = $("#missionFoot");
    if (foot) {
      foot.innerHTML = `<span style="font-size:.76rem;color:var(--mint);font-weight:800">✓ Activity complete</span>
        <button class="btn btn-primary btn-sm" style="margin-left:auto" onclick="app.startQuiz()">Start the quiz →</button>`;
    }
  },

  startQuiz() {
    Sound.click();
    Session.cleanup();
    Session.phase = "quiz";
    Session.qIndex = 0;
    Session.answered = [];
    Session.order = [];
    this.render();
  },

  /* ---- activity 1: constellation (Big Dipper, 7 stars) ---- */
  actConstellation() {
    const pts = [
      [14, 30], [30, 22], [48, 27], [49, 50], [32, 60], [14, 55], [4, 44]
    ];
    return `<div class="sky" id="sky">
      <svg class="sky-lines" viewBox="0 0 100 100" preserveAspectRatio="none" id="skyLines"></svg>
      ${pts.map((p, i) => `<button class="sky-star ${i === 0 ? "next" : ""}" id="st-${i}"
        style="left:${p[0]}%;top:${p[1]}%" onclick="app.tapConstStar(${i})"
        aria-label="Star ${i + 1}">${i + 1}</button>`).join("")}
    </div>
    <p style="font-size:.8rem;color:var(--ink-faint);margin-top:10px">Order: bowl first (1→2→3→4), then the handle (5→6→7).</p>`;
  },
  init_constellation() {
    Session.api.ptr = 0;
    Session.api.pts = [[14, 30], [30, 22], [48, 27], [49, 50], [32, 60], [14, 55], [4, 44]];
  },
  tapConstStar(i) {
    if (Session.activityDone) return;
    const ptr = Session.api.ptr;
    const el = $("#st-" + i);
    if (!el) return;
    if (i === ptr) {
      el.classList.remove("next");
      el.classList.add("done");
      Sound.tone(480 + ptr * 90, "sine", 0.13, 0.06);
      this._drawConstLine(ptr);
      Session.api.ptr = ptr + 1;
      const next = $("#st-" + Session.api.ptr);
      if (next) next.classList.add("next");
      if (Session.api.ptr >= 7) {
        this.activityComplete("That is the Big Dipper — Ursa Major. The two stars on the far edge of the bowl point straight at Polaris, the North Star.");
      }
    } else {
      el.classList.add("wrong");
      Sound.wrong();
      setTimeout(() => el.classList.remove("wrong"), 400);
      if (ptr === 0) UI.toast("Start at star 1 — it is the bright one on the left.", "coral");
    }
  },
  _drawConstLine(from) {
    const pts = Session.api.pts;
    if (from < 1) return;
    const a = pts[from - 1], b = pts[from];
    const svg = $("#skyLines");
    if (!svg) return;
    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", a[0]); line.setAttribute("y1", a[1]);
    line.setAttribute("x2", b[0]); line.setAttribute("y2", b[1]);
    line.setAttribute("stroke", "#4fe3ff");
    line.setAttribute("stroke-width", "1");
    line.setAttribute("stroke-opacity", ".75");
    svg.appendChild(line);
  },

  /* ---- activity 2: thrust ---- */
  actThrust() {
    return `<div class="rocket-stage">
        <div class="rocket-emoji" id="rocketEmoji">🚀</div>
      </div>
      <div style="margin-top:16px">
        <input class="range" id="thrustRange" type="range" min="0" max="100" value="0" aria-label="Throttle"
               oninput="app.onThrust(this.value)" onchange="app.onThrust(this.value)">
        <div class="thrust-read"><span>Throttle</span><b id="thrustVal">0%</b></div>
      </div>`;
  },
  init_thrust() { Session.api.peak = 0; },
  onThrust(val) {
    const v = Number(val);
    const label = document.getElementById("thrustVal");
    if (label) label.textContent = v + "%";
    const rk = document.getElementById("rocketEmoji");
    if (rk) {
      rk.style.transform = `translateY(${-v * 0.42}px) scale(${1 + v / 500})`;
      rk.style.filter = `drop-shadow(0 ${6 + v / 8}px ${10 + v / 6}px rgba(79,227,255,${0.25 + v / 300}))`;
    }
    if (v > (Session.api.peak || 0)) Session.api.peak = v;
    if (v >= 100) {
      this.activityComplete("Full thrust! The engine throws gas down at high speed, and the reaction pushes the rocket up. In space that reaction is all you need.");
    }
  },

  /* ---- activity 3: systems ---- */
  actSystems() {
    const sys = [
      ["oxygen", "Oxygen generator", "Splits water into breathable O₂"],
      ["scrubber", "CO₂ scrubber", "Removes carbon dioxide from the cabin"],
      ["solar", "Solar array + battery", "Charges in sunlight, powers the dark half"]
    ];
    return `<div class="switch-row">
      ${sys.map(([id, name, sub]) => `
        <button class="switch" id="sw-${id}" onclick="app.tapSystem('${id}')" aria-pressed="false">
          <span style="text-align:left">${name}<small>${sub}</small></span>
          <span class="knob"></span>
        </button>`).join("")}
    </div>
    <p style="font-size:.8rem;color:var(--ink-faint);margin-top:12px">All three must be online before the crew can launch.</p>`;
  },
  init_systems() { Session.api.on = {}; },
  tapSystem(id) {
    if (Session.activityDone) return;
    const el = $("#sw-" + id);
    if (!el || el.classList.contains("on")) return;
    el.classList.add("on");
    el.setAttribute("aria-pressed", "true");
    Sound.tone(520, "square", 0.09, 0.045);
    Session.api.on[id] = true;
    if (Object.keys(Session.api.on).length === 3) {
      this.activityComplete("Ship online! Air, clean carbon dioxide and steady power — the three systems no crew can fly without.");
    }
  },

  /* ---- activity 4: zero-g catch ---- */
  actZeroG() {
    const items = [
      ["🍎", 12, 20], ["💧", 66, 14], ["🥨", 28, 62], ["🍪", 72, 58], ["🧃", 46, 36]
    ];
    return `<div class="float-field" id="floatField">
      ${items.map(([emoji, x, y], i) => `<div class="float-item" data-i="${i}" style="left:${x}%;top:${y}%"
        onclick="app.catchItem(this)" role="button" tabindex="0" aria-label="Catch ${emoji}">${emoji}</div>`).join("")}
      <div style="position:absolute;left:12px;bottom:10px;font-size:.75rem;color:var(--ink-faint)">
        Caught: <b id="catchCount" style="color:var(--mint)">0</b> / 5
      </div>
    </div>`;
  },
  init_zerog() {
    const field = $("#floatField");
    if (!field) return;
    const items = $$(".float-item", field);
    const state = items.map(el => ({
      el,
      x: parseFloat(el.style.left) / 100 * field.clientWidth,
      y: parseFloat(el.style.top) / 100 * field.clientHeight,
      vx: (Math.random() - 0.5) * 1.3,
      vy: (Math.random() - 0.5) * 1.1,
      caught: false
    }));
    Session.api.caught = 0;
    const step = () => {
      const w = field.clientWidth, h = field.clientHeight;
      state.forEach(s => {
        if (s.caught) return;
        s.x += s.vx; s.y += s.vy;
        if (s.x < 0 || s.x > w - 54) { s.vx *= -1; s.x = Math.max(0, Math.min(w - 54, s.x)); }
        if (s.y < 0 || s.y > h - 54) { s.vy *= -1; s.y = Math.max(0, Math.min(h - 54, s.y)); }
        s.el.style.left = s.x + "px";
        s.el.style.top = s.y + "px";
      });
      Session.raf = requestAnimationFrame(step);
    };
    Session.raf = requestAnimationFrame(step);
  },
  catchItem(el) {
    if (Session.activityDone || el.classList.contains("caught")) return;
    el.classList.add("caught");
    Sound.tone(700 + Math.random() * 200, "sine", 0.1, 0.05);
    Session.api.caught = (Session.api.caught || 0) + 1;
    const c = $("#catchCount");
    if (c) c.textContent = Session.api.caught;
    if (Session.api.caught >= 5) {
      if (Session.raf) cancelAnimationFrame(Session.raf);
      Session.raf = null;
      this.activityComplete("All caught. Nothing falls in orbit — the station, the food and you are all falling around Earth together, so everything just floats.");
    }
  },

  /* ---- activity 5: orbit ---- */
  actOrbit() {
    return `<div class="orbit-stage" id="orbitStage">
        <div class="orbit-path" id="orbitPath" style="width:220px;height:220px"></div>
        <div style="width:64px;height:64px">${ART.planet(PLANETS[2], 100)}</div>
        <div class="orbit-sat" id="orbitSat"></div>
        <div class="orbit-read">
          <span>Speed <b id="orbSpeed" style="color:var(--amber)">0</b> km/s</span>
          <span id="orbState">too slow — falling in</span>
        </div>
      </div>
      <div style="margin-top:16px">
        <input class="range" id="orbRange" type="range" min="0" max="100" value="0" aria-label="Orbit speed"
               oninput="app.onOrbit(this.value)">
        <div class="thrust-read"><span>Engine burn</span><span>Stable window: <b>7.4 – 7.9 km/s</b></span></div>
      </div>`;
  },
  init_orbit() {
    Session.api.angle = 0;
    Session.api.speed = 0;
    Session.api.hold = 0;
    const loop = () => {
      const sat = $("#orbitSat");
      const path = $("#orbitPath");
      const s = Session.api.speed;
      if (sat) {
        const r = 110 - Math.min(58, Math.max(0, (s / 100) * 58));
        const a = Session.api.angle;
        sat.style.transform = `translate(calc(-50% + ${Math.cos(a) * r}px), calc(-50% + ${Math.sin(a) * r * 0.82}px))`;
      }
      if (path) {
        const r = 110 - Math.min(58, Math.max(0, (s / 100) * 58));
        path.style.width = (r * 2) + "px";
        path.style.height = (r * 2 * 0.82) + "px";
      }
      Session.api.angle += (0.004 + s / 9000);
      Session.raf = requestAnimationFrame(loop);
    };
    Session.raf = requestAnimationFrame(loop);
  },
  onOrbit(val) {
    const v = Number(val);
    Session.api.speed = v;
    const kms = (6.0 + v * 0.028).toFixed(1);
    const sp = $("#orbSpeed"); if (sp) sp.textContent = kms;
    const stEl = $("#orbState");
    const stable = v >= 52 && v <= 72;
    if (stEl) {
      stEl.textContent = v < 52 ? "too slow — falling in" : v > 72 ? "too fast — escaping" : "stable orbit ✓";
      stEl.style.color = stable ? "var(--mint)" : "var(--coral)";
    }
    if (stable && !Session.activityDone) {
      Session.api.hold = (Session.api.hold || 0) + 1;
      if (Session.api.hold >= 3) {
        this.activityComplete("Stable orbit! At 7.4–7.9 km/s you fall around the curve of Earth exactly as fast as the ground drops away — so you keep circling instead of landing.");
      }
    } else {
      Session.api.hold = 0;
    }
  },

  /* ---- activity 6: comms ---- */
  actComms() {
    Session.api.commsRound = 0;
    Session.api.commsScore = 0;
    return `<div id="commsWrap">${this._commsQuestion(0)}</div>`;
  },
  init_comms() { /* state set in actComms */ },
  _commsQuestion(idx) {
    const rounds = [
      {
        prompt: "Fuel is at 18% and dropping. Which message should go to the crew?",
        options: [
          { t: "“Flight, fuel: one eight percent and falling, two percent per minute.”", ok: true, why: "Number first, then unit and trend. The crew knows exactly what is happening." },
          { t: "“Uh, we might be a bit low on fuel, hang on…”", ok: false, why: "No number, no trend, and 'hang on' leaves the crew waiting." },
          { t: "“Fuel is fine.”", ok: false, why: "That is not true — and false reassurance is worse than silence." }
        ]
      },
      {
        prompt: "The crew reads back a number that sounds wrong. What now?",
        options: [
          { t: "“Say again — confirm one five zero metres per second.”", ok: true, why: "Asking for a repeat with the expected value lets both sides check the same number." },
          { t: "“Never mind, it's probably fine.”", ok: false, why: "Skipping the check is how small errors become big ones." },
          { t: "Say nothing and hope it was right.", ok: false, why: "Silence is a decision too — and a risky one." }
        ]
      },
      {
        prompt: "Two controllers start talking at once. What keeps the loop clean?",
        options: [
          { t: "One voice at a time, through the CAPCOM, with a clear call sign.", ok: true, why: "The CAPCOM is the single voice to the crew, so nothing overlaps or contradicts." },
          { t: "Everyone talks faster so it is over sooner.", ok: false, why: "Talking over each other is how instructions get missed." },
          { t: "Send it all as one long paragraph.", ok: false, why: "Long unbroken messages are hard to act on under pressure." }
        ]
      }
    ];
    const r = rounds[idx];
    return `<div id="commsRound">
      <p style="font-size:.85rem;color:var(--ink-faint);letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px">Call ${idx + 1} of 3</p>
      <p style="font-weight:800;margin-bottom:12px">${esc(r.prompt)}</p>
      <div class="q-options">
        ${r.options.map((o, i) => `<button class="q-option" onclick="app.tapComms(${idx},${i},${o.ok})">
          <span class="ltr">${"ABC"[i]}</span><span>${esc(o.t)}</span></button>`).join("")}
      </div>
      <div id="commsFb"></div>
    </div>`;
  },
  tapComms(idx, optIdx, ok) {
    if (Session.activityDone) return;
    const wrap = $("#commsRound");
    if (!wrap || wrap.dataset.answered) return;
    wrap.dataset.answered = "1";
    $$(".q-option", wrap).forEach((b, i) => {
      b.disabled = true;
      if (i === optIdx) b.classList.add(ok ? "correct" : "wrong");
    });
    const rounds = ["Number, unit, trend — in that order.", "Repeat it back before you act on it.", "One voice, one channel, clear call signs."];
    const fb = $("#commsFb");
    if (fb) fb.innerHTML = `<div class="explain ${ok ? "" : "bad"}"><h5>${ok ? "Good call" : "Try this instead"}</h5><p>${esc((ok ? "" : rounds[idx] + " "))}${ok ? "Clear, short messages are how a whole room stays in sync." : "Clear, short messages are how a whole room stays in sync."}</p></div>`;
    ok ? Sound.success() : Sound.wrong();
    Session.later(() => {
      const next = idx + 1;
      if (next < 3) {
        const w = $("#commsWrap");
        if (w) w.innerHTML = this._commsQuestion(next);
        Session.api.commsRound = next;
      } else {
        this.activityComplete("Three clean calls. Short, ordered messages with read-backs are what keep a mission room working as one team.");
      }
    }, 1300);
  },

  /* ---- activity 7: lander ---- */
  actLander() {
    return `<div class="lander-field" id="landerField">
        <div class="lander-hud">
          <span>Altitude<b id="ladAlt">120 m</b></span>
          <span style="text-align:center">Speed<b id="ladVel">4.0 m/s</b></span>
          <span style="text-align:right">Fuel<b id="ladFuel">100%</b></span>
        </div>
        <div class="lander" id="landerEmoji" style="bottom:210px">🛸
          <div class="flame" id="landerFlame"></div>
        </div>
        <div class="moon-ground"></div>
      </div>
      <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap">
        <button class="btn btn-amber btn-sm" id="burnBtn" onclick="app.landerBurn()">🔥 BURN (slow down)</button>
        <button class="btn btn-ghost btn-sm" onclick="app.landerReset()">↺ Reset</button>
      </div>
      <p style="font-size:.78rem;color:var(--ink-faint);margin-top:10px">Gravity keeps pulling you down. Land below <b style="color:var(--mint)">3 m/s</b> or you will bounce.</p>`;
  },
  init_lander() {
    Session.api.alt = 120;
    Session.api.vel = 4;
    Session.api.fuel = 100;
    Session.api.dead = false;
    const tick = () => {
      if (Session.api.dead) return;
      Session.api.vel += 0.16;
      Session.api.alt -= Session.api.vel * 0.22;
      if (Session.api.alt <= 0) {
        Session.api.alt = 0;
        Session.api.dead = true;
        this._landerRender();
        if (Session.api.vel < 3) {
          this.activityComplete("Touchdown! You used the engine to cancel your fall instead of a parachute — there is no air on the Moon to fill one.");
        } else {
          Sound.wrong();
          const fb = $("#activityFeedback");
          if (fb) fb.innerHTML = `<div class="explain bad" style="margin-top:14px"><h5>Too fast</h5><p>You hit the surface at ${Session.api.vel.toFixed(1)} m/s. Burn earlier and in shorter puffs so you arrive slow.</p></div>`;
          const btn = $("#burnBtn");
          if (btn) btn.disabled = true;
        }
        return;
      }
      this._landerRender();
      Session.raf = requestAnimationFrame(tick);
    };
    this._landerRender();
    Session.raf = requestAnimationFrame(tick);
  },
  _landerRender() {
    const a = $("#ladAlt"), v = $("#ladVel"), f = $("#ladFuel"), l = $("#landerEmoji");
    if (a) a.textContent = Math.max(0, Math.round(Session.api.alt)) + " m";
    if (v) {
      v.textContent = Session.api.vel.toFixed(1) + " m/s";
      v.style.color = Session.api.vel < 3 ? "var(--mint)" : "var(--coral)";
    }
    if (f) f.textContent = Math.round(Session.api.fuel) + "%";
    if (l) l.style.bottom = (48 + Math.max(0, Session.api.alt) * 1.55) + "px";
  },
  landerBurn() {
    if (Session.activityDone || Session.api.dead) return;
    if (Session.api.fuel <= 0) return;
    Session.api.vel = Math.max(-1.2, Session.api.vel - 1.5);
    Session.api.fuel = Math.max(0, Session.api.fuel - 7);
    Sound.tone(180, "sawtooth", 0.09, 0.04);
    const flame = $("#landerFlame");
    if (flame) { flame.classList.add("on"); setTimeout(() => flame.classList.remove("on"), 160); }
    this._landerRender();
  },
  landerReset() {
    Session.cleanup();
    Session.activityDone = false;
    const box = $("#activityBox");
    if (box) box.innerHTML = this.actLander();
    const fb = $("#activityFeedback");
    if (fb) fb.innerHTML = "";
    const foot = $("#missionFoot");
    if (foot) foot.innerHTML = `<button class="btn btn-ghost btn-sm" onclick="app.lessonPrevFromActivity()">← Read the cards again</button>
      <span style="margin-left:auto;font-size:.76rem;color:var(--ink-faint)">Finish the activity to open the quiz</span>`;
    this.init_lander();
  },

  /* ---- activity 8: solar storm shield (level 8) ---- */
  actShield() {
    const items = [
      ["sat", "🛰️", "Satellite safe mode", "Park the panels and stop the sensitive work"],
      ["grid", "🔌", "Power grid alert", "Warn operators so transformers are protected"],
      ["crew", "🧑‍🚀", "Crew storm shelter", "Move the astronauts to the shielded module"]
    ];
    return `<div class="storm-timer"><i id="stormBar" style="width:100%"></i></div>
      <p style="font-size:.8rem;color:var(--ink-faint);margin-bottom:12px">
        Flare detected. Time to impact: <b id="stormClock" style="color:var(--coral)">20</b>s
      </p>
      <div class="shield-grid">
        ${items.map(([id, ico, name, sub]) => `
          <button class="shield-card" id="sh-${id}" onclick="app.tapShield('${id}')" aria-pressed="false">
            <span class="ico">${ico}</span>
            <span>${name}<small>${sub}</small></span>
          </button>`).join("")}
      </div>`;
  },
  init_shield() {
    Session.api.shield = {};
    Session.api.left = 20;
    const bar = $("#stormBar"), clock = $("#stormClock");
    const tick = () => {
      if (Session.activityDone) return;
      Session.api.left -= 0.1;
      if (bar) bar.style.width = Math.max(0, (Session.api.left / 20) * 100) + "%";
      if (clock) clock.textContent = Math.max(0, Math.ceil(Session.api.left));
      if (Session.api.left <= 0) {
        if (Object.keys(Session.api.shield).length < 3) {
          const fb = $("#activityFeedback");
          if (fb) fb.innerHTML = `<div class="explain bad" style="margin-top:14px"><h5>Storm arrived</h5>
            <p>You only switched on ${Object.keys(Session.api.shield).length} of 3 protections. Real forecasters get a day or more of warning \u2014 use it all.</p></div>`;
          Sound.wrong();
          const foot = $("#missionFoot");
          if (foot) foot.innerHTML = `<button class="btn btn-ghost btn-sm" onclick="app.retryActivity()">↻ Try again</button>`;
        }
        return;
      }
      Session.raf = requestAnimationFrame(tick);
    };
    Session.raf = requestAnimationFrame(tick);
  },
  tapShield(id) {
    if (Session.activityDone) return;
    const el = $("#sh-" + id);
    if (!el || el.classList.contains("on")) return;
    el.classList.add("on");
    el.setAttribute("aria-pressed", "true");
    Sound.tone(520, "square", 0.09, 0.045);
    Session.api.shield[id] = true;
    if (Object.keys(Session.api.shield).length === 3) {
      if (Session.raf) cancelAnimationFrame(Session.raf);
      Session.raf = null;
      this.activityComplete("Storm weathered! Satellites went to safe mode, the grid was warned, and the crew moved to shelter. Space weather is dangerous, but it is forecastable \u2014 that is what saves the hardware.");
    }
  },

  /* ---- activity 9: EVA checklist order (level 9) ---- */
  actOrder() {
    const steps = [
      { id:"prebreathe", t:"Pre-breathe pure oxygen to purge nitrogen" },
      { id:"suit",       t:"Put on the suit and check the seals" },
      { id:"tether",     t:"Clip both safety tethers to the station" },
      { id:"depress",    t:"Depressurise the airlock" },
      { id:"hatch",      t:"Open the outer hatch and step outside" }
    ];
    Session.api.orderSteps = steps;
    Session.api.orderPtr = 0;
    const shuffled = steps.slice().sort(() => Math.random() - 0.5);
    return `<div class="order-list" id="orderList">
      ${shuffled.map(s => `<button class="order-item" id="or-${s.id}" onclick="app.tapOrder('${s.id}')">
        <span class="num">?</span><span>${s.t}</span></button>`).join("")}
    </div>
    <p style="font-size:.8rem;color:var(--ink-faint);margin-top:12px">
      Progress: <b id="orderCount" style="color:var(--mint)">0</b> / 5 steps in the right order.
    </p>`;
  },
  init_order() { /* state set in actOrder */ },
  tapOrder(id) {
    if (Session.activityDone) return;
    const steps = Session.api.orderSteps || [];
    const want = steps[Session.api.orderPtr];
    const el = $("#or-" + id);
    if (!el || el.classList.contains("done")) return;
    if (want && id === want.id) {
      el.classList.add("done");
      const num = $(".num", el);
      if (num) num.textContent = Session.api.orderPtr + 1;
      Sound.tone(480 + Session.api.orderPtr * 80, "sine", 0.12, 0.055);
      Session.api.orderPtr++;
      const c = $("#orderCount");
      if (c) c.textContent = Session.api.orderPtr;
      if (Session.api.orderPtr >= steps.length) {
        this.activityComplete("Checklist complete. Pre-breathe, suit up, tether on, depressurise, then open the hatch \u2014 in that order, every single time. Order is what keeps a spacewalk safe.");
      }
    } else {
      el.classList.add("bad");
      Sound.wrong();
      setTimeout(() => el.classList.remove("bad"), 400);
      UI.toast("Not yet \u2014 think about what has to happen before that step.", "coral");
    }
  },

  /* ---- activity 10: pick the essentials (levels 10 & 14) ---- */
  actPick() {
    const st = Session.stage;
    const sets = {
      10: {
        need: 3,
        items: [
          { id:"engine",  ico:"🔥", t:"Rocket engine",      sub:"Throws mass backwards to make thrust", ok:true },
          { id:"fuel",    ico:"⛽", t:"Fuel and oxidiser",  sub:"Burns without needing air",            ok:true },
          { id:"nozzle",  ico:"🔔", t:"Expanding nozzle",   sub:"Speeds up the exhaust gas",            ok:true },
          { id:"wings",   ico:"✈️", t:"Aircraft wings",     sub:"Need air to make lift",                ok:false },
          { id:"prop",    ico:"🌀", t:"Propeller",          sub:"Pushes against air",                   ok:false },
          { id:"sail",    ico:"⛵", t:"Sailing mast",       sub:"Needs wind",                           ok:false }
        ]
      },
      14: {
        need: 3,
        items: [
          { id:"air",     ico:"💨", t:"Sealed habitat with air", sub:"Pressure and breathable atmosphere", ok:true },
          { id:"water",   ico:"💧", t:"Water supply",            sub:"Drink, grow food, make oxygen",      ok:true },
          { id:"power",   ico:"🔋", t:"Power source",            sub:"Solar or nuclear, for everything",   ok:true },
          { id:"flag",    ico:"🚩", t:"A big flag",              sub:"Nice, but not life support",         ok:false },
          { id:"sofa",    ico:"🛋️", t:"Comfy sofa",              sub:"Luxury, not survival",               ok:false },
          { id:"guitar",  ico:"🎸", t:"A guitar",                sub:"Good for morale, not for breathing", ok:false }
        ]
      }
    };
    const set = sets[st.id] || sets[10];
    Session.api.pickSet = set;
    Session.api.picked = {};
    return `<div class="pick-grid" id="pickGrid">
      ${set.items.map(it => `<button class="pick-card" id="pk-${it.id}" onclick="app.tapPick('${it.id}')">
        <span class="ico">${it.ico}</span><span>${it.t}<small>${it.sub}</small></span></button>`).join("")}
    </div>
    <p style="font-size:.8rem;color:var(--ink-faint);margin-top:12px">
      Selected: <b id="pickCount" style="color:var(--mint)">0</b> / ${set.need} essentials.
    </p>`;
  },
  init_pick() { /* state set in actPick */ },
  tapPick(id) {
    if (Session.activityDone) return;
    const set = Session.api.pickSet;
    const it = set.items.find(x => x.id === id);
    const el = $("#pk-" + id);
    if (!it || !el || el.classList.contains("on")) return;
    if (!it.ok) {
      el.classList.add("bad");
      Sound.wrong();
      setTimeout(() => el.classList.remove("bad"), 400);
      UI.toast("That one is not essential \u2014 look for what keeps the machine or the crew alive.", "coral");
      return;
    }
    el.classList.add("on");
    Sound.tone(560, "sine", 0.1, 0.05);
    Session.api.picked[id] = true;
    const n = Object.keys(Session.api.picked).length;
    const c = $("#pickCount");
    if (c) c.textContent = n;
    if (n >= set.need) {
      const msg = Session.stage.id === 14
        ? "Base stocked. Air, water and power are the three things a Mars colony cannot do without \u2014 everything else is comfort."
        : "That is a working rocket. Engine, propellant and a nozzle to accelerate the exhaust \u2014 wings and propellers are useless where there is no air.";
      this.activityComplete(msg);
    }
  },

  /* ---- activity 11: telescope focus (level 13) ---- */
  actFocus() {
    return `<div class="focus-stage">
        <div class="focus-target" id="focusTarget">${ART.scene("galaxy")}</div>
        <div class="focus-read">
          <span>Focus <b id="focusVal" style="color:var(--amber)">0%</b></span>
          <span id="focusState">blurry \u2014 keep turning</span>
        </div>
      </div>
      <div style="margin-top:16px">
        <input class="range" id="focusRange" type="range" min="0" max="100" value="0" aria-label="Telescope focus"
               oninput="app.onFocus(this.value)">
        <div class="thrust-read"><span>Focus knob</span><span>Sharp window: <b>62 \u2013 78%</b></span></div>
      </div>`;
  },
  init_focus() { Session.api.focusHold = 0; },
  onFocus(val) {
    const v = Number(val);
    const t = $("#focusTarget");
    const fv = $("#focusVal");
    const fs = $("#focusState");
    if (fv) fv.textContent = v + "%";
    const sharp = v >= 62 && v <= 78;
    if (t) {
      const blur = Math.abs(v - 70) / 70;
      t.style.filter = `blur(${(blur * 7).toFixed(2)}px) brightness(${(1.25 - blur * 0.5).toFixed(2)})`;
      t.style.transform = `scale(${(1 + (1 - blur) * 0.12).toFixed(3)})`;
    }
    if (fs) {
      fs.textContent = sharp ? "sharp and clear ✓" : (v < 62 ? "blurry — keep turning" : "over-focused — back it off");
      fs.style.color = sharp ? "var(--mint)" : "var(--coral)";
    }
    if (sharp && !Session.activityDone) {
      Session.api.focusHold = (Session.api.focusHold || 0) + 1;
      if (Session.api.focusHold >= 3) {
        this.activityComplete("Sharp! A telescope collects light with a wide mirror and focuses it to a point. Get the focus right and a faint galaxy 50 million light-years away resolves into stars.");
      }
    } else {
      Session.api.focusHold = 0;
    }
  },

  /* Retry the current activity from scratch. */
  retryActivity() {
    Session.cleanup();
    Session.activityDone = false;
    Session.phase = "activity";
    this.render();
  },

  /* ---------------- quiz ---------------- */
  /* Shuffle the answer options for a question, once per render pass, so the
     correct answer lands in a different position every time. The shuffled
     order is remembered per question index, so re-rendering the same question
     (e.g. after a hint) does not reshuffle it under the child's finger. */
  orderFor(qIndex) {
    const st = Session.stage;
    if (!st) return [];
    const q = st.quiz[qIndex];
    if (!q) return [];
    if (!Session.order[qIndex]) {
      const idx = q.options.map((_, i) => i);
      for (let i = idx.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
      }
      Session.order[qIndex] = idx;
    }
    return Session.order[qIndex];
  },

  renderQuiz() {
    const st = Session.stage;
    const q = st.quiz[Session.qIndex];
    const total = st.quiz.length;
    const answered = !!Session.answered[Session.qIndex];
    const order = this.orderFor(Session.qIndex);

    $("#missionBody").innerHTML = `
      <div class="quiz-wrap" style="border-top:0;padding-top:0;margin-top:0">
        <div class="quiz-top">
          <h4>Mission quiz</h4>
          <span class="quiz-step">Question ${Session.qIndex + 1} of ${total}</span>
        </div>
        <p class="q-text">${esc(q.q)}</p>
        <div class="q-options" id="qOptions">
          ${order.map((origIdx, dispIdx) => `<button class="q-option" data-i="${dispIdx}" data-orig="${origIdx}" data-answered="0" onclick="app.answer(${dispIdx})">
            <span class="ltr">${"ABCD"[dispIdx]}</span><span>${esc(q.options[origIdx])}</span>
          </button>`).join("")}
        </div>
        <div class="quiz-tools">
          <button class="btn btn-ghost btn-sm" id="hintBtn" onclick="app.showHint()">💡 Need a hint?</button>
          <span style="font-size:.76rem;color:var(--ink-faint)">
            ${Session.practice ? "Practice run · no new stars" : "First try = " + QUIZ_POINTS + " stars"}
          </span>
        </div>
        <div id="hintSlot"></div>
        <div id="answerSlot"></div>
      </div>
    `;

    $("#missionFoot").innerHTML = `
      <button class="btn btn-ghost btn-sm" onclick="app.backToActivity()">← Activity</button>
      <span style="margin-left:auto;font-size:.76rem;color:var(--ink-faint)">
        Score so far: <b style="color:var(--mint)">${Session.correct}</b> / ${total}
      </span>
    `;
    $("#hintBtn").style.display = answered ? "none" : "";
  },

  showHint() {
    const q = Session.stage.quiz[Session.qIndex];
    const slot = $("#hintSlot");
    if (!slot) return;
    Session.hintShown = true;
    slot.innerHTML = `<div class="hint-box"><b>Astro says:</b> ${esc(q.hint)}</div>`;
    const btn = $("#hintBtn");
    if (btn) btn.style.display = "none";
    Sound.tone(620, "sine", 0.1, 0.05);
    Pip.say(q.hint, "help", true);
  },

  answer(dispIdx) {
    /* HARD LOCK #1 — the DOM itself refuses a second answer. */
    const options = $("#qOptions");
    if (!options || options.dataset.locked === "1") return;
    const q = Session.stage.quiz[Session.qIndex];
    if (Session.answered[Session.qIndex]) return;
    Session.answered[Session.qIndex] = true;
    options.dataset.locked = "1";

    const buttons = $$(".q-option", options);
    buttons.forEach(b => { b.dataset.answered = "1"; b.disabled = true; });

    /* The button carries the ORIGINAL option index, so scoring is unaffected
       by the shuffle. */
    const chosenBtn = buttons[dispIdx];
    const origIdx = chosenBtn ? Number(chosenBtn.dataset.orig) : dispIdx;
    const isCorrect = origIdx === q.correct;
    if (chosenBtn) chosenBtn.classList.add(isCorrect ? "correct" : "wrong");
    if (!isCorrect) {
      const rightBtn = buttons.find(b => Number(b.dataset.orig) === q.correct);
      if (rightBtn) { rightBtn.classList.add("correct"); rightBtn.classList.remove("dim"); }
    }

    /* HARD LOCK #2 — a question pays out at most once, ever.
       Two conditions must BOTH be new: not wrong before in this run,
       and never scored before in any earlier run (persisted key). */
    let earned = 0;
    const key = Session.stage.id + ":" + Session.qIndex;
    if (isCorrect) {
      Session.correct++;
      Session.scored[Session.qIndex] = true;
      const alreadyPaid = !!Store.state.scoredQuestions[key];
      if (!Session.practice && !Session.firstTryWrong[Session.qIndex] && !alreadyPaid) {
        Store.state.scoredQuestions[key] = true;
        Store.save();
        earned = QUIZ_POINTS;
        Session.earnedThisRun += QUIZ_POINTS;
      }
    } else {
      Session.firstTryWrong[Session.qIndex] = true;
      Session.scored[Session.qIndex] = false;
    }

    const slot = $("#answerSlot");
    if (slot) {
      slot.innerHTML = `<div class="explain ${isCorrect ? "" : "bad"}">
        <h5>${isCorrect ? "Correct!" : "Not quite — here is the answer"}</h5>
        <p>${esc(q.explain)}</p>
      </div>`;
    }

    if (earned > 0) {
      Award.points(earned, "correct answer");
      Sound.success();
    } else if (isCorrect) {
      Sound.success();
      Sound.tone(880, "sine", 0.1, 0.05);
    } else {
      Sound.wrong();
    }

    /* Astro reacts in context */
    if (isCorrect) {
      const lines = [
        "Yes! That is exactly it. " + q.explain,
        "Nailed it, Cadet. " + q.explain,
        "Perfect answer. " + q.explain
      ];
      Pip.say(lines[Math.floor(Math.random() * lines.length)], "cheer", false);
    } else {
      Pip.say("Good try — now you know it. " + q.explain, "help", false);
    }

    const foot = $("#missionFoot");
    if (foot) {
      const last = Session.qIndex === Session.stage.quiz.length - 1;
      foot.innerHTML = `<span style="margin-left:auto;font-size:.76rem;color:var(--ink-faint)">
        Score: <b style="color:var(--mint)">${Session.correct}</b> / ${Session.stage.quiz.length}</span>
        <button class="btn btn-primary btn-sm" onclick="app.nextQuestion()">${last ? "See my result →" : "Next question →"}</button>`;
    }
    const hintBtn = $("#hintBtn");
    if (hintBtn) hintBtn.style.display = "none";
  },

  nextQuestion() {
    Sound.click();
    const st = Session.stage;
    if (Session.qIndex < st.quiz.length - 1) {
      Session.qIndex++;
      this.render();
      $("#missionBody").scrollTop = 0;
    } else {
      Session.phase = "result";
      this.render();
    }
  },

  backToActivity() {
    Session.cleanup();
    Session.phase = "activity";
    Session.activityDone = false;
    this.render();
  },

  /* ---------------- result ---------------- */
  renderResult() {
    if (Session.resultShown) return;
    Session.resultShown = true;
    const st = Session.stage;
    const total = st.quiz.length;
    const score = Session.correct;
    const pct = Math.round((score / total) * 100);
    const prevBest = Store.state.stageStars[st.id] || 0;
    const best = Math.max(prevBest, score);
    const wasComplete = Store.state.completed.includes(st.id);

    Store.state.stageStars[st.id] = best;
    Store.state.stageAttempts[st.id] = (Store.state.stageAttempts[st.id] || 0) + 1;
    Store.save();

    let bonus = 0;
    if (!wasComplete) {
      const res = Award.completeStage(st);
      bonus = res.bonus;
      Session.earnedThisRun += bonus;
    } else {
      /* A finished mission never pays the completion bonus again, but a
         practice run still pays a small training stipend so a cadet can
         keep working towards the expensive gear. */
      bonus = Award.practiceStipend();
      Session.earnedThisRun += bonus;
    }
    Trophies.check(false);
    UI.syncHUD();

    const praise = pct === 100
      ? "A perfect score. Astro is doing loops around the room."
      : pct >= 66 ? "Strong work — one small gap to close."
      : "Mission finished. Read the explanations, then run it again for a better score.";

    const nextStage = Progress.nextStage();
    const newlyDone = !wasComplete;

    $("#missionBody").innerHTML = `
      <div class="result">
        <div class="medal">${ART.medal(st.hue)}</div>
        <span class="eyebrow">${newlyDone ? "Mission complete" : "Practice complete"}</span>
        <h3 style="margin-top:12px">${esc(st.title)}</h3>
        <p>${esc(praise)}</p>
        <div class="result-stats">
          <div class="result-stat"><b>${score}/${total}</b><span>Correct</span></div>
          <div class="result-stat"><b>${pct}%</b><span>Score</span></div>
          <div class="result-stat"><b>${Session.earnedThisRun > 0 ? "+" + Session.earnedThisRun : "0"}</b><span>${Session.earnedThisRun > 0 ? "New stars" : "No new stars"}</span></div>
        </div>
        <div style="max-width:520px;margin:18px auto 0;text-align:left">
          <div class="explain">
            <h5>${newlyDone ? "What you unlocked" : "Replay note"}</h5>
            <p>${newlyDone
              ? `Mission ${st.id} is in the log, and Mission ${Math.min(STAGES.length, st.id + 1)} is now open. Your best score is saved.`
              : `You already collected the stars for this mission, so the completion bonus does not pay again — but you earned a ${PRACTICE_STIPEND}-star training stipend for the practice. Your best score is kept.`}</p>
          </div>
        </div>
      </div>
    `;

    $("#missionFoot").innerHTML = `
      <button class="btn btn-ghost btn-sm" onclick="app.closeMission()">Back to path</button>
      <button class="btn btn-ghost btn-sm" onclick="app.replayMission()">↺ Replay</button>
      <span style="margin-left:auto;display:flex;gap:8px">
        ${newlyDone ? `<button class="btn btn-mint btn-sm" onclick="app.go('cadet')">Spend stars →</button>` : ""}
        ${nextStage ? `<button class="btn btn-primary btn-sm" onclick="app.openMission(${nextStage.id})">Next mission →</button>`
          : `<button class="btn btn-primary btn-sm" onclick="app.go('trophies')">🏆 See trophies</button>`}
      </span>
    `;

    if (newlyDone) {
      UI.confetti();
      Sound.fanfare();
      Pip.say(`${st.title} complete! Score ${score} out of ${total}. ${nextStage ? "Mission " + nextStage.id + " is open — " + nextStage.title + "." : "You have finished every mission in the academy."}`, "cheer", true);
    } else {
      Sound.success();
      Pip.say(`Practice run done — ${score} out of ${total}. Your best stays at ${best}.`, "help", true);
    }
  },

  replayMission() {
    const id = Session.stage.id;
    Session.cleanup();
    this.open(id);
  }
};

function sound_open() { Sound.tone(660, "sine", 0.1, 0.05); }
/*@@END_JS_MISSION@@*/
/* ============================================================
   6. ASTRO — the mission buddy (rule-based, offline, kid-safe)
   ============================================================ */
const Pip = {
  open: false,
  history: [],
  pendingHint: false,

  /* ---- knowledge base ---- */
  topics: [
    {
      id: "constellation",
      keys: ["constellation", "big dipper", "dipper", "polaris", "north star", "star pattern", "ursa", "stargaz"],
      answer: "A constellation is a pattern of stars that people agreed on — like the Big Dipper, which is seven bright stars in Ursa Major. Find the two stars at the end of the bowl, follow them five times further, and you land on Polaris, the North Star.",
      hintFor: 1,
      action: { label: "Open Mission 1", view: "missions" }
    },
    {
      id: "rocket",
      keys: ["rocket", "thrust", "launch", "newton", "fuel", "escape velocity", "blast off", "blastoff"],
      answer: "A rocket pushes hot gas down, and the gas pushes the rocket up — that is Newton's third law. It carries its own oxygen so it can burn fuel in space where there is no air at all.",
      hintFor: 2,
      action: { label: "Open Mission 2", view: "missions" }
    },
    {
      id: "orbit",
      keys: ["orbit", "orbiting", "perigee", "apogee", "transfer", "hohmann", "satellite", "navigation", "navigate"],
      answer: "An orbit is a permanent fall. If you go sideways fast enough — about 7.8 km per second near Earth — the ground curves away as fast as you drop, so you keep circling. Go faster and your orbit grows into a big oval; too fast and you leave for good.",
      hintFor: 5,
      action: { label: "Open Mission 5", view: "missions" }
    },
    {
      id: "gravity",
      keys: ["gravity", "weightless", "zero g", "microgravity", "float", "floating"],
      answer: "Gravity never switches off. Astronauts float because the station and everything in it are falling around Earth together — nothing presses on anything, so nothing stays put. Gravity up there is still about 90% of what you feel on the ground.",
      hintFor: 4,
      action: { label: "Open Mission 4", view: "missions" }
    },
    {
      id: "life",
      keys: ["eat", "eating", "food", "sleep", "sleeping", "toilet", "bathroom", "water", "drink", "exercise"],
      answer: "Food is often freeze-dried and rehydrated, drinks come in pouches with straws, and sleeping bags are strapped to the wall. Astronauts exercise about two hours a day so their bones and muscles do not weaken without gravity.",
      hintFor: 4,
      action: { label: "Open Mission 4", view: "missions" }
    },
    {
      id: "missioncontrol",
      keys: ["mission control", "capcom", "flight director", "apollo 13", "teamwork", "communication", "radio", "headset"],
      answer: "In Mission Control each desk owns one system, and one person — the CAPCOM — is the only voice that talks to the crew, so messages never overlap. That is why Apollo 13 could be solved by a room full of people talking clearly instead of all at once.",
      hintFor: 6,
      action: { label: "Open Mission 6", view: "missions" }
    },
    {
      id: "moon",
      keys: ["moon", "apollo", "armstrong", "aldrin", "lunar", "landing", "footprint"],
      answer: "Twelve people walked on the Moon between 1969 and 1972. The first was Neil Armstrong, on 20 July 1969. Their footprints will last for millions of years, because the Moon has no wind or rain to erase them.",
      hintFor: 7,
      action: { label: "Open Mission 7", view: "missions" }
    },
    {
      id: "sun",
      keys: ["sun", "solar", "star is", "hot"],
      answer: "The Sun is a star — a ball of super-hot gas holding 99.8% of the solar system's mass. Its light takes about 8 minutes and 20 seconds to reach Earth, and the core is around 15 million °C.",
      planet: "sun",
      action: { label: "Open the Sun's file", view: "planets" }
    },
    {
      id: "earth",
      keys: ["earth", "home planet", "blue marble"],
      answer: "Earth is our home and the only world we know with liquid oceans, breathable air and life. About 71% of the surface is water, and we sit at just the right distance from the Sun for water to stay liquid.",
      planet: "earth",
      action: { label: "Open Earth's file", view: "planets" }
    },
    {
      id: "mars",
      keys: ["mars", "red planet", "olympus"],
      answer: "Mars is red because of rusty iron dust. It has the tallest volcano we know of, Olympus Mons, about 22 km high — roughly two and a half Everests. Robots are exploring it right now.",
      planet: "mars",
      action: { label: "Open Mars's file", view: "planets" }
    },
    {
      id: "jupiter",
      keys: ["jupiter", "great red spot", "biggest planet", "largest planet"],
      answer: "Jupiter is the biggest planet — more than 1,300 Earths would fit inside. Its Great Red Spot is a storm wider than Earth that has been spinning for at least 150 years.",
      planet: "jupiter",
      action: { label: "Open Jupiter's file", view: "planets" }
    },
    {
      id: "saturn",
      keys: ["saturn", "ring", "rings", "titan"],
      answer: "Saturn's rings are billions of pieces of ice and rock — about 280,000 km wide but mostly only ten metres thick. Saturn is also less dense than water, so in a giant bath it would float.",
      planet: "saturn",
      action: { label: "Open Saturn's file", view: "planets" }
    },
    {
      id: "icegiants",
      keys: ["uranus", "neptune", "ice giant", "sideways"],
      answer: "Uranus rolls around the Sun on its side, tipped over by nearly 98°, with 42-year seasons. Neptune is the windiest world we know — gusts over 2,000 km/h — and it was found by maths before anyone saw it through a telescope.",
      planet: "uranus",
      action: { label: "Open Uranus's file", view: "planets" }
    },
    {
      id: "mercury",
      keys: ["mercury", "closest planet", "smallest planet"],
      answer: "Mercury is the smallest planet and the closest to the Sun. It races around at about 47 km per second, and because it has almost no air, it swings from 430 °C in the day to -180 °C at night.",
      planet: "mercury",
      action: { label: "Open Mercury's file", view: "planets" }
    },
    {
      id: "venus",
      keys: ["venus", "hottest planet", "backwards planet"],
      answer: "Venus is the hottest planet, around 465 °C, because its thick carbon-dioxide clouds trap heat. It also spins backwards, so on Venus the Sun would rise in the west — and one spin takes longer than its whole year.",
      planet: "venus",
      action: { label: "Open Venus's file", view: "planets" }
    },
    {
      id: "solarsystem",
      keys: ["solar system", "how many planets", "planets are there", "eight planets", "order of planets"],
      answer: "Eight planets, in order from the Sun: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune. The first four are small and rocky, the next two are giant gas balls, and the last two are icy giants.",
      action: { label: "Open planet explorer", view: "planets" }
    },
    {
      id: "stars",
      keys: ["star", "stars", "galaxy", "milky way", "how many stars"],
      answer: "Stars are huge balls of glowing gas. Our Sun is one of roughly 100–400 billion stars in the Milky Way, and the nearest star to us after the Sun is about 4.2 light-years away — so far that light takes over four years to get here.",
      action: { label: "Open planet explorer", view: "planets" }
    },
    {
      id: "blackhole",
      keys: ["black hole", "blackhole", "neutron star", "supernova"],
      answer: "A black hole is a place where gravity is so strong that not even light escapes. A teaspoon of neutron-star material would weigh about six billion tonnes on Earth — space really does not do things by halves.",
      action: { label: "See fun facts", view: "planets" }
    },
    {
      id: "help",
      keys: ["help", "what can you do", "how do i play", "how does this work", "stuck", "confused", "what now"],
      answer: "Three kinds of help: I can explain space words, give you a hint on the current question, or open the right screen for you. Try \"hint\", \"what is an orbit\", or \"show me Mars\".",
      chips: true
    },
    {
      id: "encourage",
      keys: ["i can't", "i cant", "hard", "difficult", "give up", "bored", "sad", "tired"],
      answer: "Every astronaut got things wrong first — Apollo 13 went wrong in the middle of the mission and the team still brought everyone home. Take the hint, read the explanation, and try again. Nothing here is timed.",
      chips: true
    },
    {
      id: "points",
      keys: ["star", "points", "how many points", "buy", "shop", "outfit", "suit", "spend"],
      answer: "You earn 1 star for each new lesson card, 4 for a correct first-try answer, 2 for logging a new world, and a 15-star bonus the first time you finish a mission. Replays pay a small 3-star training stipend. Spend it all in \"My Cadet\" on suits, helmets, visors, hats, packs, boots, gloves, capes, pets, badges and trails \u2014 the legendary ones cost a lot, so keep flying!",
      action: { label: "Open my cadet", view: "cadet" }
    }
  ],

  jokes: [
    "Why did the astronaut take a pencil to space? Because pens need gravity to work!",
    "I asked the Moon for a snack. It said sorry, it had gone off — as in, it has no atmosphere.",
    "My rocket has a problem: every time I count down from 10, it launches at 4. I have terrible timing.",
    "Space is silent, which is honestly the only reason I am still allowed on this crew."
  ],

  /* ---- UI ---- */
  mount() {
    $("#pipForm").addEventListener("submit", e => {
      e.preventDefault();
      const input = $("#pipInput");
      const text = input.value.trim();
      if (!text) return;
      input.value = "";
      this.ask(text);
    });
    $("#pipChips").innerHTML = [
      ["What is an orbit?", "What is an orbit?"],
      ["Hint", "hint"],
      ["Tell me a joke", "tell me a joke"],
      ["What can you do?", "what can you do"]
    ].map(([label, send]) => `<button class="chip" onclick="app.askPip('${send.replace(/'/g, "\\'")}')">${label}</button>`).join("");

    this.push("pip", this.welcome());
    this.renderChips();
  },

  welcome() {
    const s = Store.state;
    const next = Progress.nextStage();
    if (!s.name) return "Hi there! I'm Astro, your space buddy. Once you have a cadet name, we can start Mission 1 together.";
    if (s.completed.length >= 7) return `Look at that, ${s.name} — all seven missions done. Ask me anything about the planets, or ask for a joke. I know a lot of jokes.`;
    if (s.completed.length === 0) return `Hi ${s.name}! I'm Astro. Mission 1 is open — poetry in the sky, honestly. Tap the first mission and I will talk you through it.`;
    return `Welcome back, ${s.name}. Mission ${next ? next.id : 7} — ${next ? next.title : "the Moon"} — is ready when you are. Want a hint, or just a chat?`;
  },

  toggle(force) {
    this.open = force === undefined ? !this.open : force;
    const panel = $("#pipPanel");
    const btn = $("#pipLauncher");
    if (!panel) return;
    panel.hidden = !this.open;
    document.body.classList.toggle("pip-open", this.open);
    btn.setAttribute("aria-expanded", String(this.open));
    if (this.open) {
      setTimeout(() => $("#pipInput").focus({ preventScroll: true }), 120);
      if (!this.history.length) this.push("pip", this.welcome());
    }
  },

  push(who, text, typing) {
    const log = $("#pipLog");
    if (!log) return;
    if (typing) {
      const t = document.createElement("div");
      t.className = "msg pip typing";
      t.id = "pipTyping";
      t.innerHTML = "<i></i><i></i><i></i>";
      log.appendChild(t);
      log.scrollTop = log.scrollHeight;
      return;
    }
    const el = document.createElement("div");
    el.className = "msg " + (who === "me" ? "me" : "pip");
    el.textContent = text;
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    this.history.push({ who, text });
  },

  removeTyping() {
    const t = $("#pipTyping");
    if (t) t.remove();
  },

  renderChips() {
    const box = $("#pipChips");
    if (!box) return;
    const chips = this.contextChips();
    box.innerHTML = chips.map(c => `<button class="chip" onclick="app.askPip('${c.replace(/'/g, "\\'")}')">${c}</button>`).join("");
  },

  contextChips() {
    if (Session.stage && Session.phase === "quiz") {
      return ["Hint please", "Why does that happen?", "Tell me a joke"];
    }
    if (Session.stage) return ["Explain that again", "What is the next step?", "Tell me a joke"];
    return ["What is an orbit?", "Show me Mars", "How do I earn stars?"];
  },

  /* ---- the actual conversation ---- */
  ask(raw) {
    const text = String(raw).trim();
    if (!text) return;
    Store.state.pipAsked++;
    Store.save();
    if (Store.state.pipAsked === 10) Trophies.check(false);

    this.push("me", text);
    this.push("pip", "", true);
    Sound.click();

    const delay = 380 + Math.min(900, text.length * 9);
    setTimeout(() => {
      this.removeTyping();
      const reply = this.reply(text);
      this.push("pip", reply.text);
      if (reply.say) Talk.say(reply.text);
      this.renderChips();
      if (reply.run) setTimeout(reply.run, 260);
    }, delay);
  },

  reply(text) {
    const t = text.toLowerCase();

    /* quiz hint has priority when a quiz is live */
    if (Session.stage && Session.phase === "quiz" && /hint|help|clue|stuck|answer|don'?t know|no idea/.test(t)) {
      const q = Session.stage.quiz[Session.qIndex];
      if (q) {
        return { text: `No problem — here is a nudge, not the answer: ${q.hint}`, say: false };
      }
    }

    if (/^(hint|hint please|i need a hint)$/.test(t)) {
      if (Session.stage && Session.phase === "quiz") {
        const q = Session.stage.quiz[Session.qIndex];
        return { text: `Here is your nudge: ${q.hint} You have got this.` };
      }
      const next = Progress.nextStage();
      return { text: next ? `Open Mission ${next.id} and I will walk you through the first card.${next.id === 1 ? " Tap the mission card, then \"Next card\"." : ""}` : "All missions are done — try the planet explorer for a new favourite fact." };
    }

    if (/joke|funny|laugh/.test(t)) {
      const j = this.jokes[Math.floor(Math.random() * this.jokes.length)];
      return { text: j };
    }

    if (/thank|thanks|you'?re (great|awesome|the best)|love you/.test(t)) {
      return { text: "Aw, thanks! Now go collect some stars — I have my eye on a new helmet." };
    }

    if (/^(hi|hello|hey|yo|good morning|good evening|hola)\b/.test(t)) {
      return { text: `Hello! ${this.welcome()}` };
    }

    if (/who are you|what are you|your name/.test(t)) {
      return { text: "I'm Astro — a small helper robot with one big job: keeping you unstuck. I know the missions, the planets and an unreasonable number of space jokes." };
    }

    if (/my name is |call me /.test(t)) {
      const m = text.match(/my name is ([a-z0-9 _-]{1,18})/i) || text.match(/call me ([a-z0-9 _-]{1,18})/i);
      if (m) {
        const nm = m[1].trim().replace(/\b\w/g, c => c.toUpperCase());
        Store.state.name = nm;
        Store.save();
        UI.syncHUD();
        return { text: `Nice to meet you, ${nm}! I have written that into your cadet file.`, run: () => UI.renderMissions() };
      }
    }

    /* navigation requests */
    const navMap = [
      { re: /show me (the )?(planets|planet explorer)|open planets/, view: "planets", say: "Opening the planet explorer." },
      { re: /show me (my )?(cadet|outfits|shop|wardrobe)|open (the )?(shop|cadet)/, view: "cadet", say: "Opening your cadet wardrobe." },
      { re: /show me (the )?trophies|my (badges|trophies)|achievements/, view: "trophies", say: "Here is the trophy cabinet." },
      { re: /show me (the )?missions|go (to )?missions|home/, view: "missions", say: "Back to the training path." }
    ];
    for (const n of navMap) {
      if (n.re.test(t)) {
        return { text: n.say, run: () => { if (this.open) this.toggle(false); UI.go(n.view); } };
      }
    }
    if (/show me (mars|jupiter|saturn|earth|venus|mercury|neptune|uranus|the sun)/.test(t)) {
      const m = t.match(/show me (?:the )?(mars|jupiter|saturn|earth|venus|mercury|neptune|uranus|sun)/);
      if (m) {
        const id = m[1] === "sun" ? "sun" : m[1];
        return { text: `Opening ${m[1] === "sun" ? "the Sun" : m[1][0].toUpperCase() + m[1].slice(1)} for you.`, run: () => { if (this.open) this.toggle(false); UI.go("planets"); setTimeout(() => app.openPlanet(id), 420); } };
      }
    }
    if (/open mission (\d)/.test(t)) {
      const id = Number(t.match(/open mission (\d)/)[1]);
      if (STAGES.some(s => s.id === id) && Progress.unlocked(id)) {
        return { text: `Opening Mission ${id}.`, run: () => { if (this.open) this.toggle(false); app.openMission(id); } };
      }
      return { text: `Mission ${id} is still locked — finish the one before it and it will open right up.` };
    }

    /* knowledge topics — score by keyword hits */
    let best = null, bestScore = 0;
    const words = t.split(/[^a-z0-9 ]/).filter(Boolean);
    this.topics.forEach(topic => {
      let score = 0;
      topic.keys.forEach(k => {
        if (t.includes(k)) score += k.split(" ").length * 2 + 1;
      });
      if (score > bestScore) { bestScore = score; best = topic; }
    });

    if (best && bestScore >= 2) {
      const extra = best.action && best.action.view && best.action.view !== "missions"
        ? ` Want me to open that for you? Ask "open ${best.action.label.toLowerCase().replace(/^open (the )?/, "")}".`
        : "";
      const run = best.action ? () => { if (this.open) this.toggle(false); UI.go(best.action.view); if (best.planet) setTimeout(() => app.openPlanet(best.planet), 420); } : null;
      return { text: best.answer + extra, run };
    }

    /* gentle fallback that offers a real next step */
    if (t.includes("?")) {
      return { text: `Hmm, that one is past my training manual. I am best at orbits, rockets, planets, the Moon and how missions work. Try asking "why do astronauts float?" — or tap a suggestion below.` };
    }
    return { text: `I caught "${text.slice(0, 40)}" — but my space-brain is not sure what to do with it. Ask me about a planet, a mission, or type "hint" if a question has you stuck.` };
  },

  /* one-liners used by the mission engine */
  say(lines, mood, speak) {
    const text = Array.isArray(lines) ? lines[Math.floor(Math.random() * lines.length)] : lines;
    if (this.open) this.push("pip", text);
    if (speak && Talk.enabled) Talk.say(text);
  }
};
/* ============================================================
   7. APP CONTROLLER
   ============================================================ */
function speakNow(text) {
  if (!("speechSynthesis" in window)) { UI.toast("This browser cannot read aloud.", "coral"); return; }
  Talk.unlock();
  Talk.enabled = true;
  Store.state.settings.voice = true;
  Store.save();
  app.syncToggles();
  Talk.say(text, { rate: 0.95 });
}

const app = {
  planetIndex: 0,

  /* ---------- boot ---------- */
  init() {
    const saved = Store.load();
    if (saved) {
      Store.state = saved;
    } else {
      Store.state = DEFAULT_STATE();
      Store.save();
    }

    Sound.enabled = Store.state.settings.sound !== false;
    Talk.init();
    Talk.enabled = !!Store.state.settings.voice;
    document.body.classList.toggle("calm", !!Store.state.settings.calm);

    this.syncToggles();
    UI.syncHUD();
    UI.renderMissions();
    Pip.mount();
    this.starfield();
    this.bind();
    Trophies.check(true);

    if (!Store.state.name) {
      this.openSetup();
    } else {
      // Astro stays docked as a launcher on every visit — the child opens the chat
      // when they want it, so it never sits on top of lesson text.
      Pip.toggle(false);
    }
  },

  bind() {
    $$(".tab").forEach(t => t.addEventListener("click", () => UI.go(t.dataset.view)));
    $("#btnSound").addEventListener("click", () => this.toggleSound());
    $("#btnVoice").addEventListener("click", () => this.toggleVoice());
    $("#btnSettings").addEventListener("click", () => this.openSettings());
    $("#pipLauncher").addEventListener("click", () => Pip.toggle());
    $("#tgSound").addEventListener("click", () => this.toggleSound());
    $("#tgVoice").addEventListener("click", () => this.toggleVoice());
    $("#tgCalm").addEventListener("click", () => this.toggleCalm());
    $("#btnRename").addEventListener("click", () => this.rename());
    $("#btnReset").addEventListener("click", () => this.resetAll());
    $("#planetPrev").addEventListener("click", () => this.stepPlanet(-1));
    $("#planetNext").addEventListener("click", () => this.stepPlanet(1));
    $("#planetRead").addEventListener("click", () => this.readPlanet());
    $("#btnStart").addEventListener("click", () => this.completeSetup());
    $("#cadetName").addEventListener("keydown", e => { if (e.key === "Enter") this.completeSetup(); });

    $$(".overlay").forEach(ov => {
      ov.addEventListener("click", e => { if (e.target === ov) this.closeOverlay(ov.id); });
    });

    document.addEventListener("keydown", e => {
      if (e.key !== "Escape") return;
      const open = $$(".overlay.is-open");
      if (open.length) this.closeOverlay(open[open.length - 1].id);
      else if (Pip.open) Pip.toggle(false);
    });

    window.addEventListener("resize", () => {
      const c = $("#starfield");
      if (c) { c.width = window.innerWidth; c.height = window.innerHeight; }
    });
  },

  closeOverlay(id) {
    if (id === "missionOverlay") return this.closeMission();
    if (id === "planetSheet") return this.closePlanet();
    if (id === "settingsModal") return this.closeSettings();
    if (id === "setupModal") return;
    UI.close(id);
  },

  /* ---------- setup ---------- */
  openSetup() {
    const grantable = ["suit_classic", "suit_ember", "suit_forest", "suit_nebula"];
    const wrap = $("#starterColors");
    wrap.innerHTML = grantable.map((id, i) => {
      const s = SUITS.find(x => x.id === id);
      return `<button class="swatch ${i === 0 ? "is-active" : ""}" data-suit="${id}" title="${s.name}"
        style="background:linear-gradient(145deg,${s.colors.body},${s.colors.trim})"
        onclick="app.pickStarter('${id}')" aria-label="Choose ${s.name}"></button>`;
    }).join("");
    this.pickedSuit = grantable[0];
    $("#setupAvatar").innerHTML = ART.cadet({ suit: this.pickedSuit, helmet: "helm_bubble", badge: "badge_none", label: "New cadet" });
    UI.open("setupModal");
    setTimeout(() => $("#cadetName").focus({ preventScroll: true }), 300);
  },

  pickStarter(id) {
    this.pickedSuit = id;
    $$("#starterColors .swatch").forEach(b => b.classList.toggle("is-active", b.dataset.suit === id));
    $("#setupAvatar").innerHTML = ART.cadet({ suit: id, helmet: "helm_bubble", badge: "badge_none", label: "New cadet" });
    Sound.click();
  },

  completeSetup() {
    const raw = $("#cadetName").value.trim();
    const name = (raw || "Cadet").slice(0, 18);
    const s = Store.state;
    s.name = name;
    if (this.pickedSuit && !s.owned.includes(this.pickedSuit)) {
      s.owned.push(this.pickedSuit);
      s.equipped.suit = this.pickedSuit;
    }
    Store.save();
    UI.close("setupModal");
    UI.syncHUD();
    UI.renderMissions();
    UI.toast(`Welcome aboard, ${name}!`, "mint");
    Sound.fanfare();
    Pip.toggle(false);
  },

  /* ---------- navigation ---------- */
  go(view) { UI.go(view); },
  togglePip(force) { Pip.toggle(force); },
  askPip(text) { Pip.toggle(true); Pip.ask(text); },

  /* ---------- mission bridges (called from inline handlers) ---------- */
  openMission(id) { Pip.toggle(false); Mission.open(id); },
  closeMission() { Mission.close(); },
  lessonNext() { Mission.lessonNext(); },
  lessonPrev() { Mission.lessonPrev(); },
  speakCard() { Mission.speakCard(); },
  lessonPrevFromActivity() { Mission.lessonPrevFromActivity(); },
  startQuiz() { Mission.startQuiz(); },
  showHint() { Mission.showHint(); },
  answer(i) { Mission.answer(i); },
  nextQuestion() { Mission.nextQuestion(); },
  replayMission() { Mission.replayMission(); },
  backToActivity() { Mission.backToActivity(); },
  lockedTap(id) { UI.lockedTap(id); },
  tapConstStar(i) { Mission.tapConstStar(i); },
  onThrust(v) { Mission.onThrust(v); },
  tapSystem(id) { Mission.tapSystem(id); },
  catchItem(el) { Mission.catchItem(el); },
  onOrbit(v) { Mission.onOrbit(v); },
  tapComms(a, b, c) { Mission.tapComms(a, b, c); },
  landerBurn() { Mission.landerBurn(); },
  landerReset() { Mission.landerReset(); },
  tapShield(id) { Mission.tapShield(id); },
  tapOrder(id) { Mission.tapOrder(id); },
  tapPick(id) { Mission.tapPick(id); },
  onFocus(v) { Mission.onFocus(v); },
  retryActivity() { Mission.retryActivity(); },

  /* ---------- planets ---------- */
  openPlanet(id) {
    const all = [SUN_INFO].concat(PLANETS);
    const idx = all.findIndex(p => p.id === id);
    this.planetIndex = idx < 0 ? 0 : idx;
    const p = all[this.planetIndex];

    Store.state.planetsSeen[p.id] = true;
    Store.save();
    Trophies.check(false);

    this._fillPlanet(p);
    UI.open("planetSheet");
    Sound.tone(520, "sine", 0.12, 0.05);
    if (Talk.enabled) speakNow(p.name + ". " + p.blurb);
  },

  _fillPlanet(p) {
    $("#planetBody").innerHTML = `
      <div class="planet-hero">
        <div class="planet-big"><div class="pv">${ART.planet(p, 260)}</div></div>
        <div>
          <div class="planet-type">${esc(p.type)}</div>
          <h2 class="planet-name">${esc(p.name)}</h2>
          <p class="planet-blurb">${esc(p.blurb)}</p>
        </div>
      </div>

      <div class="stat-grid">
        ${Object.keys(p.stats).map(k => `<div class="stat-cell"><span>${esc(k)}</span><b>${esc(p.stats[k])}</b></div>`).join("")}
      </div>

      <div class="sec-head" style="margin:22px 0 10px">
        <div><h2 style="font-size:1.05rem">Things that surprised me</h2></div>
      </div>
      <div class="fact-list">
        ${p.facts.map(([title, body]) => `<div class="fact"><b>✦</b><div><b style="display:block;color:var(--amber);margin-bottom:2px">${esc(title)}</b>${esc(body)}</div></div>`).join("")}
      </div>

      <div style="margin-top:18px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" onclick="app.askPip('tell me about ${p.id === "sun" ? "the sun" : p.name.toLowerCase()}')">💬 Ask Astro about it</button>
        ${p.id !== "sun" ? `<button class="btn btn-ghost btn-sm" onclick="app.askPip('what is an orbit')">🛰 How does it stay in orbit?</button>` : ""}
      </div>
    `;
    $("#planetPrev").disabled = this.planetIndex === 0;
    $("#planetNext").disabled = this.planetIndex === ([SUN_INFO].concat(PLANETS).length - 1);
    $("#planetRead").textContent = "🔊 Read to me";
  },

  closePlanet() {
    UI.close("planetSheet");
    if (UI.view === "planets") UI.renderPlanets();
    if (UI.view === "missions") UI.renderMissions();
    UI.syncHUD();
  },

  stepPlanet(dir) {
    const all = [SUN_INFO].concat(PLANETS);
    const next = this.planetIndex + dir;
    if (next < 0 || next >= all.length) return;
    this.openPlanet(all[next].id);
    Sound.click();
  },

  readPlanet() {
    const all = [SUN_INFO].concat(PLANETS);
    const p = all[this.planetIndex];
    if (!p) return;
    const text = `${p.name}. ${p.blurb} ${p.facts.map(f => f[1]).join(" ")}`;
    speakNow(text);
    Sound.click();
  },

  planetTour() {
    this.openPlanet("sun");
    UI.toast("Use Next → to fly outward from the Sun.", "mint");
  },

  /* ---------- shop ---------- */
  setShopTab(key) { UI.shopTab = key; Sound.click(); UI.renderCadet(); },

  buyItem(id) {
    const res = Shop.buy(id);
    if (res.ok) {
      UI.toast(res.msg, "mint");
    } else {
      UI.toast(res.msg, "coral");
      Sound.wrong();
      if (res.short) Pip.say("Not enough stars yet — each correct answer is worth ten. You will get there in one mission.", "help", false);
    }
    UI.renderCadet();
    UI.syncHUD();
  },

  equipItem(id) {
    if (Shop.equip(id)) {
      UI.toast("Outfit equipped.", "mint");
      UI.renderCadet();
      UI.syncHUD();
    }
  },

  /* ---------- settings ---------- */
  openSettings() {
    $("#renameInput").value = Store.state.name || "";
    UI.open("settingsModal");
    this.syncToggles();
  },
  closeSettings() { UI.close("settingsModal"); },

  syncToggles() {
    const st = Store.state.settings;
    const set = (el, on) => { if (el) el.classList.toggle("on", !!on); };
    set($("#tgSound"), st.sound);
    set($("#tgVoice"), st.voice);
    set($("#tgCalm"), st.calm);
    const vb = $("#btnVoice");
    if (vb) {
      vb.textContent = st.voice ? "🔊" : "🔈";
      vb.classList.toggle("is-on", !!st.voice);
      vb.setAttribute("aria-pressed", String(!!st.voice));
      vb.title = st.voice ? "Astro is reading aloud — tap to mute" : "Tap to let Astro read aloud";
    }
    const b = $("#btnSound");
    if (b) {
      b.textContent = st.sound ? "🔊" : "🔇";
      b.setAttribute("aria-pressed", String(!!st.sound));
    }
  },

  toggleSound() {
    const st = Store.state.settings;
    st.sound = !st.sound;
    Sound.enabled = st.sound;
    Store.save();
    this.syncToggles();
    if (st.sound) Sound.success();
  },

  toggleVoice() {
    const st = Store.state.settings;
    st.voice = !st.voice;
    Talk.enabled = st.voice;
    Store.save();
    this.syncToggles();
    if (st.voice) {
      Talk.unlock();
      speakNow("Voice on. I will read the cards out for you.");
      UI.toast("Astro will read each card aloud.", "mint");
    } else {
      Talk.stop();
      UI.toast("Voice off.", "coral");
    }
    if (UI.view === "cadet") UI.renderCadet();
  },

  toggleCalm() {
    const st = Store.state.settings;
    st.calm = !st.calm;
    Store.save();
    document.body.classList.toggle("calm", st.calm);
    this.syncToggles();
  },

  rename() {
    const raw = $("#renameInput").value.trim();
    if (!raw) { UI.toast("Type a name first.", "coral"); return; }
    Store.state.name = raw.slice(0, 18);
    Store.save();
    UI.toast("Name saved.", "mint");
    UI.renderMissions();
    if (UI.view === "cadet") UI.renderCadet();
    UI.syncHUD();
  },

  resetAll() {
    if (!window.confirm("Reset all progress? Stars, missions and outfits will be cleared on this device.")) return;
    Store.reset();
    window.location.reload();
  },

  /* ---------- starfield ---------- */
  starfield() {
    const canvas = $("#starfield");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;
    const calm = Store.state.settings.calm;

    const layers = [
      { n: Math.min(90, Math.round(w / 16)), size: 0.9, sp: 0.05, a: 0.35 },
      { n: Math.min(60, Math.round(w / 22)), size: 1.4, sp: 0.11, a: 0.55 },
      { n: Math.min(34, Math.round(w / 34)), size: 2.1, sp: 0.2, a: 0.85 }
    ];
    const stars = [];
    layers.forEach(L => {
      for (let i = 0; i < L.n; i++) {
        stars.push({
          x: Math.random() * w, y: Math.random() * h,
          r: L.size * (0.6 + Math.random() * 0.8),
          sp: L.sp * (0.6 + Math.random() * 0.9),
          a: L.a * (0.6 + Math.random() * 0.5),
          tw: Math.random() * Math.PI * 2,
          hue: Math.random() > 0.82 ? "79,227,255" : (Math.random() > 0.9 ? "255,200,87" : "220,235,255")
        });
      }
    });

    let t = 0;
    const draw = () => {
      t += 0.012;
      ctx.clearRect(0, 0, w, h);
      stars.forEach(s => {
        const tw = calm ? 1 : 0.72 + 0.28 * Math.sin(t * 1.6 + s.tw);
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${s.hue},${(s.a * tw).toFixed(3)})`;
        ctx.fill();
        if (!calm) {
          s.y += s.sp;
          if (s.y > h + 2) { s.y = -2; s.x = Math.random() * w; }
        }
      });
      requestAnimationFrame(draw);
    };
    draw();

    window.addEventListener("resize", () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    });
  }
};

window.app = app;
/* A small read/write handle on the internals, handy for debugging and for
   checking the scoring guards from the console. */
window.AstroCadet = {
  Store, Session, Mission, Award, Progress, Shop, Talk, Sound, UI, Trophies, Pip,
  STAGES, PLANETS, COSMETIC_TABS, SUITS, HELMET_LIST: HELMETS, VISORS, HATS,
  BACKPACKS, BOOTS, GLOVES, CAPES, PETS, BADGES, TRAILS, RARITY,
  QUIZ_POINTS, LESSON_POINTS, STAGE_BONUS, PLANET_POINTS, PRACTICE_STIPEND,
  DEFAULT_STATE, SAVE_KEY
};
window.addEventListener("DOMContentLoaded", () => {
  if (window.AstroAuth && !AstroAuth.ready()) { AstroAuth.show(); return; }
  app.init();
  if (window.AstroAuth) AstroAuth.afterInit();
});
;
(function(){
"use strict";
const $x=(s,r=document)=>r.querySelector(s);
const $$x=(s,r=document)=>Array.from(r.querySelectorAll(s));
const safe=(v)=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function state(){return window.AstroCadet&&AstroCadet.Store.state}
function save(){try{AstroCadet.Store.save();AstroCadet.UI.syncHUD()}catch(e){}}
function notify(msg){try{AstroCadet.UI.toast(msg)}catch(e){let n=document.createElement('div');n.className='toast';n.textContent=msg;document.body.appendChild(n);setTimeout(()=>n.remove(),2500)}}
function awardOnce(key,amount,label){
 const s=state();if(!s)return false;
 s.extraRewards=s.extraRewards||{};
 if(s.extraRewards[key])return false;
 s.extraRewards[key]=true;s.stars=(s.stars||0)+amount;s.earnedTotal=(s.earnedTotal||0)+amount;save();
 notify('⭐ +'+amount+' Stars — '+label);return true;
}
function addTab(label,view){
 const nav=$x('.tabs');if(!nav||$x('[data-extra-view="'+view+'"]'))return;
 const b=document.createElement('button');b.className='tab';b.dataset.extraView=view;b.textContent=label;nav.appendChild(b);
 b.addEventListener('click',()=>showExtra(view));
}
function addView(id){
 let el=document.createElement('section');el.id='extra-'+id;el.className='extra-view';el.dataset.extraView=id;$x('#app').appendChild(el);return el;
}
function showExtra(id){
 $$x('.view').forEach(x=>x.classList.remove('is-active'));
 $$x('.extra-view').forEach(x=>x.classList.toggle('active',x.id==='extra-'+id));
 $$x('.tabs .tab').forEach(x=>x.classList.toggle('is-active',x.dataset.extraView===id));
 if(id==='cinema')renderCinema(); if(id==='lab')renderLab(); if(id==='about')renderAbout();
}
const cinemaItems=[
 {id:'rocket-basics',title:'How Do We Launch Things Into Space?',desc:'A friendly introduction to rockets, fuel, gravity, and how spacecraft leave Earth.',videoUrl:'https://spaceplace.nasa.gov/review/launching-into-space/how-do-we-launch-things-into-space_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/launching-into-space/en/',category:'Rockets',audience:'kids',ageLabel:'6–13',icon:'🚀',source:'NASA Space Place',quiz:'What gives a rocket the push it needs to lift off?',opts:['Thrust from its engines','Wings like an airplane','Light from the Moon'],correct:0},
 {id:'solar-eclipse',title:'What Is a Solar Eclipse?',desc:'Discover what happens when the Moon moves between the Sun and Earth.',videoUrl:'https://spaceplace.nasa.gov/review/eclipse-snap/what-is-a-solar-eclipse_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/eclipse-snap/en/',category:'Sun & Earth',audience:'kids',ageLabel:'6–13',icon:'🌞',source:'NASA Space Place',quiz:'What moves between the Sun and Earth during a solar eclipse?',opts:['The Moon','Mars','A satellite'],correct:0},
 {id:'earth-water',title:'How Much Water Is on Earth?',desc:'Explore oceans, ice, groundwater, and why water makes our planet special.',videoUrl:'https://spaceplace.nasa.gov/review/water/how-much-water-is-on-earth_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/water/en/',category:'Earth science',audience:'kids',ageLabel:'6–13',icon:'🌍',source:'NASA Space Place',quiz:'About how much of Earth’s surface is covered by water?',opts:['71%','10%','Almost 100%'],correct:0},
 {id:'planet-moons',title:'How Many Moons Does Each Planet Have?',desc:'Take a tour of the moons orbiting planets across our solar system.',videoUrl:'https://spaceplace.nasa.gov/review/how-many-moons/our-moon-isnt-the-only-moon_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/how-many-moons/en/',category:'Solar system',audience:'kids',ageLabel:'6–13',icon:'🌙',source:'NASA Space Place',quiz:'Which planet has just one natural moon?',opts:['Earth','Jupiter','Mars'],correct:0},
 {id:'blue-sky',title:'Why Is the Sky Blue?',desc:'A colorful explanation of sunlight, the atmosphere, and scattering.',videoUrl:'https://spaceplace.nasa.gov/review/blue-sky/why-is-the-sky-blue_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/blue-sky/en/',category:'Earth science',audience:'kids',ageLabel:'6–13',icon:'🌈',source:'NASA Space Place',quiz:'Why does the sky usually look blue?',opts:['Air scatters blue light more','The oceans reflect blue paint','The Sun only makes blue light'],correct:0},
 {id:'aurora',title:'What Is an Aurora?',desc:'Find out how the Sun and Earth’s magnetic field create glowing sky displays.',videoUrl:'https://spaceplace.nasa.gov/review/aurora/what-is-an-aurora_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/aurora/en/',category:'Sun & Earth',audience:'kids',ageLabel:'8–13',icon:'✨',source:'NASA Space Place',quiz:'What helps guide charged particles toward the polar regions?',opts:['Earth’s magnetic field','Ocean currents','The Moon’s light'],correct:0},
 {id:'nebula-kids',title:'What Is a Nebula?',desc:'Meet giant clouds of gas and dust where stars can form.',videoUrl:'https://spaceplace.nasa.gov/review/nebula/what-is-a-nebula_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/nebula/en/',category:'Stars & galaxies',audience:'kids',ageLabel:'9–13',icon:'🌌',source:'NASA Space Place',quiz:'What is a nebula mainly made of?',opts:['Gas and dust','Liquid water','Solid metal'],correct:0},
 {id:'oort-cloud',title:'Where Does the Solar System End?',desc:'Travel far beyond the planets and learn about the distant Oort Cloud.',videoUrl:'https://spaceplace.nasa.gov/review/oort-cloud/where-does-the-solar-system-end_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/oort-cloud/en/',category:'Solar system',audience:'kids',ageLabel:'9–13',icon:'☄️',source:'NASA Space Place',quiz:'What icy objects may come from the Oort Cloud?',opts:['Some comets','Volcanoes','Stars'],correct:0},
 {id:'exoplanets-kids',title:'Searching for Other Planets Like Ours',desc:'Learn how scientists look for planets orbiting stars beyond our Sun.',videoUrl:'https://spaceplace.nasa.gov/review/exoplanet-snap/searching-for-other-planets-like-ours_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/exoplanet-snap/en/',category:'Planets beyond',audience:'kids',ageLabel:'10–13',icon:'🪐',source:'NASA Space Place',quiz:'What is an exoplanet?',opts:['A planet orbiting another star','A moon of Earth','A kind of asteroid'],correct:0},
 {id:'solar-fusion',title:'Where Does the Sun’s Energy Come From?',desc:'A deeper look at the Sun’s core and the nuclear fusion that powers it.',videoUrl:'https://spaceplace.nasa.gov/review/sun-heat/where-does-the-suns-energy-come-from_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/sun-heat/en/',category:'Astrophysics',audience:'advanced',ageLabel:'14+',icon:'☀️',source:'NASA Space Place',quiz:'Which process releases energy in the Sun’s core?',opts:['Nuclear fusion','Evaporation','Friction with space'],correct:0},
 {id:'black-holes',title:'What Is a Black Hole?',desc:'Explore extreme gravity, the event horizon, and what makes black holes unusual.',videoUrl:'https://spaceplace.nasa.gov/review/black-holes/what-is-a-black-hole_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/black-holes/en/',category:'Astrophysics',audience:'advanced',ageLabel:'14+',icon:'🕳️',source:'NASA Space Place',quiz:'What is the event horizon?',opts:['The boundary beyond which light cannot escape','The edge of the solar system','The surface of a star'],correct:0},
 {id:'solar-system-formation',title:'How Did the Solar System Form?',desc:'Follow the science of a collapsing cloud of gas and dust becoming the Sun and planets.',videoUrl:'https://spaceplace.nasa.gov/review/solar-system-formation/the-solar-systems-formation_1280x720.mp4',pageUrl:'https://spaceplace.nasa.gov/solar-system-formation/en/',category:'Planetary science',audience:'advanced',ageLabel:'14+',icon:'🪐',source:'NASA Space Place',quiz:'About how long ago did our solar system begin forming?',opts:['4.6 billion years ago','4.6 million years ago','46 thousand years ago'],correct:0},
 {id:'nebula-advanced',title:'Nebulae and Star Formation',desc:'Go deeper into how gravity gathers interstellar gas and dust to begin forming stars.',videoUrl:'https://spaceplace.nasa.gov/review/nebula/what-is-a-nebula_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/nebula/en/',category:'Astrophysics',audience:'advanced',ageLabel:'14+',icon:'🌠',source:'NASA Space Place',quiz:'What can gravity do inside a nebula?',opts:['Pull gas and dust into denser clumps','Turn gas directly into planets instantly','Stop stars from forming'],correct:0},
 {id:'exoplanets-advanced',title:'How Scientists Search for Exoplanets',desc:'Learn about the transit method and how tiny changes in starlight reveal distant worlds.',videoUrl:'https://spaceplace.nasa.gov/review/exoplanet-snap/searching-for-other-planets-like-ours_1920x1080.mp4',pageUrl:'https://spaceplace.nasa.gov/exoplanet-snap/en/',category:'Planetary science',audience:'advanced',ageLabel:'14+',icon:'🔭',source:'NASA Space Place',quiz:'What can happen to a star’s brightness when a planet transits in front of it?',opts:['It dims slightly','It disappears forever','It changes into a planet'],correct:0}
];
let selectedCinemaId=cinemaItems[0].id;
let cinemaSearch='';
let cinemaCategory='All';
let cinemaAudience='kids';

function cinemaPlayer(){
 const v=cinemaItems.find(x=>x.id===selectedCinemaId)||cinemaItems[0];
 const player=$x('#cinema-player');if(!player)return;
 player.innerHTML=`<div class="cinema-now-playing">
  <div class="cinema-player-frame">
   <video class="cinema-native-video" controls playsinline preload="metadata" poster="" aria-label="${safe(v.title)}">
    <source src="${v.videoUrl}" type="video/mp4">
    Your browser does not support HTML5 video.
   </video>
  </div>
  <div class="cinema-player-meta">
   <span class="cinema-eyebrow">NOW PLAYING · ${safe(v.category)} · ${safe(v.ageLabel)}</span>
   <h3>${safe(v.title)}</h3><p>${safe(v.desc)}</p>
   <small>Video source: ${safe(v.source)} · <a href="${v.pageUrl}" target="_blank" rel="noopener noreferrer">NASA lesson and transcript</a></small>
   <button class="extra-btn cinema-quiz-launch" onclick="AstroExtra.quizVideo('${v.id}')">🧠 Take this video’s quiz</button>
   <div id="video-quiz-${v.id}"></div>
   <p class="cinema-player-note">If playback does not start, check your internet connection or try another NASA video.</p>
  </div>
 </div>`;
 const video=player.querySelector('video');
 if(video){
  video.addEventListener('error',function(){
   const note=player.querySelector('.cinema-player-note');
   if(note)note.innerHTML='This video could not load right now. <a href="'+v.pageUrl+'" target="_blank" rel="noopener noreferrer">Open the official NASA lesson</a>.';
  },{once:true});
 }
}
function cinemaGrid(){
 const grid=$x('#cinema-grid');if(!grid)return;
 const q=cinemaSearch.trim().toLowerCase();
 const shown=cinemaItems.filter(v=>(cinemaAudience==='all'||v.audience===cinemaAudience)
  &&(cinemaCategory==='All'||v.category===cinemaCategory)
  &&(!q||(v.title+' '+v.desc+' '+v.category+' '+v.ageLabel).toLowerCase().includes(q)));
 grid.innerHTML=shown.length?shown.map(v=>`<button type="button" class="cinema-video-card ${v.id===selectedCinemaId?'is-selected':''}" onclick="AstroExtra.playCinema('${v.id}')" aria-pressed="${v.id===selectedCinemaId}">
  <span class="cinema-thumb cinema-thumb-art"><span class="cinema-thumb-icon" aria-hidden="true">${v.icon}</span><span class="cinema-play" aria-hidden="true">▶</span><span class="cinema-age">${safe(v.ageLabel)}</span></span>
  <span class="cinema-card-copy"><small>${safe(v.category)}</small><b>${safe(v.title)}</b><span>${safe(v.desc)}</span></span>
 </button>`).join(''):'<p class="cinema-empty">No videos match this selection. Try another age group or search term.</p>';
}
function renderCinema(){
 const el=$x('#extra-cinema');if(!el)return;
 const categories=['All',...new Set(cinemaItems.filter(v=>cinemaAudience==='all'||v.audience===cinemaAudience).map(v=>v.category))];
 el.innerHTML=`<div class="extra-hero cinema-hero">
  <div>🎬 ASTRO CINEMA</div><h2>NASA science films for every curious mind</h2>
  <p>Choose an age group, watch official NASA Space Place videos right here, and test what you learned. The videos use NASA-hosted MP4 files, so the YouTube Error 153 player issue is avoided.</p>
  <div class="cinema-hero-stats"><span>🎞️ ${cinemaItems.length} learning picks</span><span>🛰️ Official NASA sources</span><span>⭐ Video quizzes</span></div>
 </div>
 <section class="cinema-feature" aria-label="Selected video">
  <div class="cinema-section-heading"><div><small>ASTRO CINEMA THEATER</small><h2>Now showing</h2></div><span class="cinema-live-dot">● PLAYS INSIDE ASTRO JR</span></div>
  <div id="cinema-player"></div>
 </section>
 <section class="cinema-library">
  <div class="cinema-section-heading"><div><small>VIDEO LIBRARY</small><h2>Choose your next discovery</h2></div><span class="cinema-count">${cinemaItems.length} videos</span></div>
  <div class="cinema-tools">
   <label class="cinema-age-label" for="cinema-audience">Choose an age group</label>
   <select id="cinema-audience" class="cinema-audience" onchange="AstroExtra.audienceCinema(this.value)">
    <option value="kids" ${cinemaAudience==='kids'?'selected':''}>Kids · up to 13 years</option>
    <option value="advanced" ${cinemaAudience==='advanced'?'selected':''}>Older learners · 14+</option>
    <option value="all" ${cinemaAudience==='all'?'selected':''}>Show all videos</option>
   </select>
   <input id="cinema-search" type="search" placeholder="Search rockets, planets, black holes…" aria-label="Search videos" oninput="AstroExtra.filterCinema(this.value)">
   <div class="cinema-categories">${categories.map(c=>`<button type="button" class="cinema-filter ${c===cinemaCategory?'active':''}" onclick="AstroExtra.categoryCinema('${safe(c)}')">${safe(c)}</button>`).join('')}</div>
  </div>
  <div class="cinema-video-grid" id="cinema-grid"></div>
 </section>
 <p class="cinema-footnote">All videos are played from NASA Space Place MP4 files inside this page. An internet connection is required. NASA lesson pages include explanations and transcripts.</p>
 <p class="cinema-source-note">Sources: <a href="https://spaceplace.nasa.gov/menu/videos/" target="_blank" rel="noopener noreferrer">NASA Space Place video library</a>. Content is presented for educational use with source attribution.</p>`;
 cinemaPlayer();cinemaGrid();
}
function playCinema(id){if(!cinemaItems.some(v=>v.id===id))return;selectedCinemaId=id;cinemaPlayer();cinemaGrid();$x('#cinema-player')?.scrollIntoView({behavior:'smooth',block:'nearest'});}
function filterCinema(value){cinemaSearch=String(value||'');cinemaGrid();}
function categoryCinema(value){
 cinemaCategory=value;
 const tools=$x('.cinema-categories');
 if(tools)$$x('button',tools).forEach(b=>b.classList.toggle('active',b.textContent===value));
 cinemaGrid();
}
function audienceCinema(value){
 cinemaAudience=['kids','advanced','all'].includes(value)?value:'kids';
 cinemaCategory='All';
 const categories=['All',...new Set(cinemaItems.filter(v=>cinemaAudience==='all'||v.audience===cinemaAudience).map(v=>v.category))];
 const holder=$x('.cinema-categories');
 if(holder)holder.innerHTML=categories.map(c=>`<button type="button" class="cinema-filter ${c===cinemaCategory?'active':''}" onclick="AstroExtra.categoryCinema('${safe(c)}')">${safe(c)}</button>`).join('');
 const available=cinemaItems.filter(v=>cinemaAudience==='all'||v.audience===cinemaAudience);
 if(!available.some(v=>v.id===selectedCinemaId)){selectedCinemaId=available[0].id;cinemaPlayer();}
 const count=$x('.cinema-count');if(count)count.textContent=available.length+' videos';
 cinemaGrid();
}
function quizVideo(id){
 const v=cinemaItems.find(x=>x.id===id);if(!v)return;
 const target=$x('#video-quiz-'+id);if(target.dataset.done==='1'){target.innerHTML='<p>You already completed this video quiz. Great memory, cadet!</p>';return}
 target.innerHTML=`<div class="extra-card"><b>${v.quiz}</b><div class="quiz-options">${v.opts.map((o,i)=>`<button class="extra-btn" onclick="AstroExtra.answerVideo('${id}',${i})">${safe(o)}</button>`).join('')}</div><p id="video-feedback-${id}" aria-live="polite"></p></div>`;
}
function answerVideo(id,i){
 const v=cinemaItems.find(x=>x.id===id);const t=$x('#video-quiz-'+id);if(!v||!t||t.dataset.done==='1')return;
 if(i===v.correct){t.dataset.done='1';$x('#video-feedback-'+id).textContent=window.AstroLanguage&&AstroLanguage.get()==='ar'?'إجابة صحيحة! لقد ربحت 5 نجوم.':'Correct! You earned 5 Stars.';awardOnce('cinema-'+id,5,'AstroCinema quiz');$$x('button',t).forEach(b=>b.disabled=true)}
 else{$x('#video-feedback-'+id).textContent='Not quite — watch again and have another try.'}
}
const puzzles=[
 {id:'gravity',emoji:'🪂',title:'Gravity Detective',desc:'A dropped tool and a feather fall together in a vacuum. Why?',q:'What is true when there is no air resistance?',opts:['Heavier things always fall faster','Objects accelerate equally under gravity','Gravity disappears'],a:1,stars:4},
 {id:'orbit',emoji:'🛰️',title:'Orbit Builder',desc:'A satellite keeps falling around Earth instead of straight down.',q:'What keeps a satellite in orbit?',opts:['Gravity bends its forward motion','There is no gravity in space','It has invisible wings'],a:0,stars:4},
 {id:'light',emoji:'🌈',title:'Light Lab',desc:'White light contains many colours.',q:'What can a prism do to white light?',opts:['Turn it into sound','Separate it into colours','Make it heavier'],a:1,stars:4}
];
function renderLab(){
 const el=$x('#extra-lab');if(!el)return;
 const s=state();const day=new Date().toISOString().slice(0,10);
 el.innerHTML=`<div class="extra-hero"><div>🧪 CADET TRAINING LAB</div><h2>Earn Stars by getting curious</h2><p>Daily challenge, science puzzles, and a quick planet discovery. Rewards are saved and each challenge pays only once.</p><button class="extra-btn" onclick="AstroExtra.daily()">🌟 Claim daily challenge</button> <button class="extra-btn" onclick="AstroExtra.discovery()">🪐 Discover a planet</button></div><div class="extra-grid">${puzzles.map(p=>`<article class="extra-card"><div style="font-size:2rem">${p.emoji}</div><h3>${p.title}</h3><p>${p.desc}</p><b>${p.q}</b><div class="quiz-options">${p.opts.map((o,i)=>`<button class="extra-btn" onclick="AstroExtra.puzzle('${p.id}',${i})">${safe(o)}</button>`).join('')}</div><p id="puzzle-feedback-${p.id}" aria-live="polite"></p></article>`).join('')}<article class="extra-card"><h3>🏅 Achievements</h3><p>Keep exploring to build your explorer streak.</p><div id="extra-achievements"></div></article></div>
 <div class="extra-card simulation-card"><div class="pill">INTERACTIVE SIMULATION</div><h3>🪐 Gravity & Orbit Simulator</h3>
 <p>Change the planet's gravity and see how strongly it pulls a satellite. Increase gravity to tighten the orbit; decrease it to loosen the pull.</p>
 <label for="gravity-slider">Gravity strength: <b id="gravity-value">50%</b></label>
 <input id="gravity-slider" class="sim-slider" type="range" min="10" max="100" value="50" oninput="AstroExtra.simulateGravity(this.value)">
 <div class="sim-stage"><div class="sim-planet">🌍</div><div class="sim-orbit" id="sim-orbit"><span class="sim-satellite">🛰️</span></div></div>
 <p id="gravity-explanation" class="sim-explanation" aria-live="polite">At 50%, gravity provides a balanced pull that bends the satellite's path around Earth.</p>
 </div>`;
 const ach=s&&s.extraRewards||{};$x('#extra-achievements').innerHTML=Object.keys(ach).filter(k=>ach[k]).map(k=>'🏅 '+safe(k.replace(/-/g,' '))).join('<br>')||'Your first badge is waiting!';
}
function simulateGravity(value){
 const v=Math.max(10,Math.min(100,Number(value)||50));
 const orbit=$x('#sim-orbit'),read=$x('#gravity-value'),ex=$x('#gravity-explanation');
 if(!orbit||!read||!ex)return;
 const size=220-(v*1.25);
 orbit.style.width=size+'px';orbit.style.height=size+'px';
 orbit.style.animationDuration=Math.max(2.2,8-(v*.055))+'s';
 read.textContent=v+'%';
 ex.textContent=v>=70?'High gravity: the pull is stronger, so the satellite needs more forward speed to stay in a stable orbit.':v<=30?'Low gravity: the pull is weaker, so the satellite follows a wider path and may drift away.':'Balanced gravity: the pull bends the satellite’s forward motion into an orbit around Earth.';
}
function daily(){
 const s=state();if(!s)return;const key='daily-'+new Date().toISOString().slice(0,10);
 if((s.extraRewards||{})[key]){notify('Daily challenge already claimed. Come back tomorrow!');return}
 const answer=prompt('Daily science challenge: Which planet is famous for its rings?\\n1) Mars   2) Saturn   3) Mercury');
 if(answer===null)return;
 if(['2','saturn'].includes(answer.trim().toLowerCase()))awardOnce(key,7,'Daily science challenge');
 else notify('Good try! Hint: it is a gas giant with bright rings. Try again!');
}
function discovery(){
 const s=state();if(!s)return;
 const planets=(window.AstroCadet.PLANETS||[]);const fresh=planets.filter(p=>!(s.extraDiscoveries||[]).includes(p.id));
 if(!fresh.length){notify('You discovered every planet in this bonus log!');return}
 const p=fresh[Math.floor(Math.random()*fresh.length)];s.extraDiscoveries=s.extraDiscoveries||[];s.extraDiscoveries.push(p.id);save();
 awardOnce('discovery-'+p.id,3,p.name+' discovery');alert(p.name+': '+p.blurb);
}
function puzzle(id,i){
 const p=puzzles.find(x=>x.id===id);if(!p)return;const f=$x('#puzzle-feedback-'+id);
 if(i===p.a){f.textContent=window.AstroLanguage&&AstroLanguage.get()==='ar'?'أحسنت يا محقق العلوم!':'Correct, science detective!';awardOnce('puzzle-'+id,p.stars,p.title);$$x('button',f.parentElement).forEach(b=>b.disabled=true)}
 else f.textContent=window.AstroLanguage&&AstroLanguage.get()==='ar'?'ليس تمامًا. فكّر في الدليل العلمي وحاول مرة أخرى.':'Not quite. Think about the science clue and try again.';
}
function aiAnswer(q){
 const text=String(q||'').toLowerCase().trim();
 const facts=[
  [/\b(hello|hi|hey|good morning|good evening)\b/,'Hello, cadet! 🚀 I’m Astro, your curious space buddy. Ask me about science, space, school topics, or everyday questions. What shall we explore?'],
  [/\b(your name|who are you|what are you)\b/,'I’m Astro, the friendly guide aboard Astro Jr! I can explain ideas, share space facts, help you think through a question, and give you a mini-quiz.'],
  [/\b(gravity|gravitation|weight)\b/,'Gravity is the attraction between objects that have mass. It keeps planets moving around the Sun and keeps us on the ground. The Moon’s surface gravity is about one-sixth of Earth’s.'],
  [/\b(orbit|satellite)\b/,'An orbit is the curved path one object follows around another. A satellite keeps moving forward while gravity continually bends its path, so it keeps falling around Earth instead of straight down.'],
  [/\b(black hole)\b/,'A black hole is a region of space where gravity is so strong that, past its event horizon, even light cannot escape. Scientists study black holes by observing their effects on nearby matter and light.'],
  [/\b(sun|solar energy|sunlight)\b/,'The Sun is a star at the center of our Solar System. It releases energy through nuclear fusion in its core, giving Earth much of the light and warmth needed for life.'],
  [/\b(mars|red planet)\b/,'Mars is a rocky planet often called the Red Planet because iron-rich minerals in its dust have rusted. It has giant volcanoes, polar ice, and evidence that liquid water once flowed on its surface.'],
  [/\b(moon|lunar|moon phases)\b/,'The Moon is Earth’s natural satellite. Its phases happen because, as it orbits Earth, we see different portions of its half-lit side. The Moon does not make its own light; it reflects sunlight.'],
  [/\b(planet|solar system)\b/,'Our Solar System has eight planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune. They all orbit the Sun. Pluto is classified as a dwarf planet.'],
  [/\b(rocket|how do rockets work)\b/,'A rocket pushes hot exhaust backward. The exhaust pushes the rocket forward in the opposite direction. That is why rockets can work in space without needing air to push against.'],
  [/\b(star|stars|constellation)\b/,'A star is a huge, glowing ball of hot gas (plasma) that produces energy in its core. Our Sun is the closest star to Earth. Other stars look tiny because they are extremely far away.'],
  [/\b(galaxy|milky way)\b/,'A galaxy is a huge collection of stars, gas, dust, and dark matter held together by gravity. Our Solar System is inside the Milky Way galaxy.'],
  [/\b(comet|asteroid|meteor)\b/,'Asteroids are rocky objects that orbit the Sun. Comets contain ice, dust, and rock and can grow glowing comas and tails near the Sun. A meteor is the streak of light made when a space rock enters an atmosphere.'],
  [/\b(light|rainbow|colour|color)\b/,'Visible white light is made of different colors. A prism can bend the colors by different amounts and spread them into a rainbow.'],
  [/\b(aurora|northern lights)\b/,'Auroras are colorful lights in the sky. They happen when charged particles from space interact with gases in Earth’s upper atmosphere, guided by Earth’s magnetic field.'],
  [/\b(exoplanet)\b/,'An exoplanet is a planet that orbits a star beyond our Solar System. Astronomers often find them by noticing a star dim slightly when a planet passes in front of it.'],
  [/\b(quiz|test me|question me)\b/,'Mini-quiz time, cadet! 🌟 Which planet is famous for its beautiful rings? A) Mars  B) Saturn  C) Mercury. Type A, B, or C and I’ll check your answer.'],
  [/\b(thank you|thanks)\b/,'You’re welcome, cadet! Keep asking questions — curiosity is your superpower. ✨'],
  [/\b(help|explain|how do i learn)\b/,'Absolutely! Tell me the topic and I’ll break it into small, clear steps, give you an example, and check your understanding.']
 ];
 for(const [pattern,answer] of facts){if(pattern.test(text))return answer;}
 if(/\b(what|why|how|when|where|who|can|does|do|is|are|explain|tell me)\b/.test(text)){
  return 'That’s a thoughtful question, cadet! I don’t have a live AI brain connected in this browser-only version, so I may not know the exact answer yet. I can still help you explore it: try adding a little context or splitting it into smaller questions. For open-ended answers on any topic, connect a secure AI service through your own server using ASTROCADET_AI_ENDPOINT — never put a private API key in this file.';
 }
 return 'I’m listening, cadet! 🚀 I can chat about space and science, help explain a school topic, or make a mini-quiz. For a question outside my built-in guide, Astro needs a secure AI service connected through a backend.';
}
async function askPip(q){
 const log=$x('#pipLog');if(!log)return;
 const row=(who,txt)=>{const d=document.createElement('div');d.className='pip-msg '+who;d.textContent=txt;log.appendChild(d);log.scrollTop=log.scrollHeight};
 row('cadet',q);const s=state();if(s){s.pipAsked=(s.pipAsked||0)+1;save()}
 let answer='';
 const endpoint=window.ASTROCADET_AI_ENDPOINT || "";
 if(endpoint){try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q,level:s&&s.learningLevel||'curious explorer'})});if(!r.ok)throw Error('AI endpoint unavailable');const d=await r.json();answer=d.answer||d.reply||''}catch(e){answer=aiAnswer(q)+' (Offline fallback — the AI service could not be reached.)'}}
 else answer=aiAnswer(q);
 if(window.AstroLanguage && AstroLanguage.get()==='ar') answer=AstroLanguage.translate(answer);
 row('pip',answer);
 if(s&&/quiz me|quick quiz/i.test(q))setTimeout(()=>{const ans=prompt('Astro quiz: Which planet is called the Red Planet?');if(ans&&/mars/i.test(ans))awardOnce('pip-quiz-'+new Date().toISOString().slice(0,10),3,'Astro quiz')},50);
}
function initPip(){
 const form=$x('#pipForm');if(!form||form.dataset.extraBound)return;form.dataset.extraBound='1';
 form.addEventListener('submit',e=>{e.preventDefault();const i=$x('#pipInput');const q=i.value.trim();if(q){i.value='';askPip(q)}});
}
let game=null;
function openLunarRescue(){
 const overlay=$x('#missionOverlay');$x('#missionKicker').textContent='MISSION 07 · SPECIAL SIMULATOR';$x('#missionTitle').textContent='Lunar Rescue';
 $x('#lessonDots').innerHTML='';
 const body=$x('#missionBody');$x('#missionFoot').innerHTML='<button class="btn btn-ghost" onclick="app.closeMission()">Close simulator</button><button class="btn btn-primary" onclick="AstroExtra.startLander()">↻ Restart flight</button>';
 body.innerHTML=`<div class="extra-hero"><h2>🌕 Lunar Rescue</h2><p>Bring the rescue lander down safely. Use short engine burns to reduce speed, keep fuel for the final approach, and touch down below 3 m/s.</p><label for="lander-difficulty">Difficulty</label> <select id="lander-difficulty" class="extra-btn" onchange="AstroExtra.startLander()"><option value="easy">Cadet · gentle gravity</option><option value="normal" selected>Pilot · balanced</option><option value="expert">Commander · tight fuel</option></select></div><div class="game-hud"><div class="game-meter">ALTITUDE<b id="lander-alt">1200 m</b></div><div class="game-meter">SPEED<b id="lander-speed">18 m/s</b></div><div class="game-meter">FUEL<b id="lander-fuel">100%</b></div></div><div class="lander-stage" id="lander-stage"><div style="position:absolute;top:12px;left:12px;color:#b9d7ff">MISSION CONTROL · MOON</div><div class="lander-ship" id="lander-ship" style="top:22px">🚀<div class="lander-flame" id="lander-flame">🔥</div></div><div class="lander-moon"></div><div id="lander-pad" style="position:absolute;bottom:44px;left:43%;width:14%;height:5px;background:#5ff0b6;box-shadow:0 0 12px #5ff0b6"></div></div><p id="lander-message" aria-live="polite">Astro: Short burns are safer than waiting until the last second.</p><div class="lander-controls"><button class="extra-btn" onclick="AstroExtra.burn(-1)">↖ LEFT</button><button class="extra-btn" onclick="AstroExtra.burn(1)">🔥 BURN</button><button class="extra-btn" onclick="AstroExtra.burn(0)">RIGHT ↗</button></div><p><small>Keyboard: Space = burn, ← / → = steer. On mobile, tap the controls.</small></p>`;
 overlay.classList.add('is-open');overlay.setAttribute('aria-hidden','false');startLander();
}
function startLander(){
 if(game&&game.timer)clearInterval(game.timer);
 const diff=$x('#lander-difficulty')?.value||'normal';
 game={alt:1200,speed:diff==='easy'?13:diff==='expert'?24:18,fuel:diff==='easy'?100:diff==='expert'?72:86,x:50,thrust:diff==='easy'?3:diff==='expert'?1.7:2.4,gravity:diff==='easy'?.45:diff==='expert'?.9:.65,done:false,diff,timer:null,bonus:false};
 updateGame();game.timer=setInterval(tick,350);
}
function updateGame(){
 if(!game)return;
 const a=$x('#lander-alt'),s=$x('#lander-speed'),f=$x('#lander-fuel'),ship=$x('#lander-ship');if(!a||!ship)return;
 a.textContent=Math.max(0,Math.round(game.alt))+' m';s.textContent=Math.max(0,game.speed).toFixed(1)+' m/s';f.textContent=Math.round(game.fuel)+'%';
 ship.style.top=(18+(1-game.alt/1200)*185)+'px';ship.style.left=game.x+'%';
 const msg=$x('#lander-message');if(msg&&game.fuel<20)msg.textContent='Astro: Fuel is low! Use small burns and aim for a gentle touchdown.';
}
function tick(){
 if(!game||game.done)return;
 game.speed=Math.max(0,game.speed+game.gravity);game.alt-=game.speed*0.35;
 if(game.alt<=0){
  game.alt=0;game.done=true;clearInterval(game.timer);
  const safe=game.speed<=3.2&&game.fuel>=0&&game.x>30&&game.x<70;
  const msg=$x('#lander-message');
  if(safe){msg.textContent='🌟 Touchdown! Rescue team is safe. '+(game.fuel>=20?'Bonus objective complete: 20% fuel remaining!':'Safe landing medal earned!');awardOnce('lunar-rescue-'+game.diff,game.diff==='expert'?18:game.diff==='normal'?15:12,'Lunar Rescue');awardOnce('lunar-medal-'+game.diff,0,'Lunar Rescue medal');if(game.fuel>=20)awardOnce('lunar-bonus-'+game.diff,5,'Fuel saver bonus')}
  else msg.textContent='Astro: The landing was too rough or off the pad. Restart and burn earlier in short bursts.';
  return;
 }
 updateGame();
}
function burn(dir){
 if(!game||game.done)return;
 if(dir===0){game.x=Math.min(82,game.x+4);game.bonus=true;return}
 if(dir===-1){game.x=Math.max(18,game.x-4);game.bonus=true;return}
 if(game.fuel<=0){$x('#lander-message').textContent='Astro: No fuel left. Restart and use shorter burns.';return}
 game.fuel=Math.max(0,game.fuel-7);game.speed=Math.max(0,game.speed-game.thrust*2.8);
 $x('#lander-flame').style.display='block';setTimeout(()=>{const flame=$x('#lander-flame');if(flame)flame.style.display='none'},180);
 updateGame();
}
function keyGame(e){if(!$x('#missionOverlay')?.classList.contains('is-open')||!game)return;if(e.code==='Space'){e.preventDefault();burn(1)}else if(e.key==='ArrowLeft')burn(-1);else if(e.key==='ArrowRight')burn(0)}
function missionOverride(){
 if(!window.app||!window.AstroCadet)return;
 const original=app.openMission.bind(app);
 app.openMission=function(id){if(Number(id)===7){if(window.Pip&&Pip.toggle)Pip.toggle(false);openLunarRescue();return}original(id)};
 const oldClose=app.closeMission.bind(app);
 app.closeMission=function(){if(game&&game.timer)clearInterval(game.timer);game=null;oldClose()};
}

function renderContact(){
 const el=$x('#extra-contact');if(!el||el.dataset.rendered)return;
 el.dataset.rendered='1';
 el.innerHTML=`<div class="extra-hero"><div>✉️ MISSION CONTROL</div><h2>Contact Us</h2><p>Have a question, idea, or need help with Astro Jr? Send a message to our team.</p></div>
 <div class="contact-layout"><form class="astro-contact-form" id="astroContactForm" action="https://formspree.io/f/xkjrojzo" method="POST">
  <label for="astroContactName">Name</label><input id="astroContactName" name="name" type="text" maxlength="80" autocomplete="name" required placeholder="Your name">
  <input id="astroContactEmail" name="email" type="hidden" value="">
  <label for="astroContactSubject">Subject / Issue Type</label><select id="astroContactSubject" name="subject" required><option value="">Choose a topic</option><option>General question</option><option>Bug or technical issue</option><option>Account or progress help</option><option>Suggestion or feedback</option><option>Other</option></select>
  <label for="astroContactMessage">Message</label><textarea id="astroContactMessage" name="message" rows="6" maxlength="3000" required placeholder="Tell us how we can help…"></textarea>
  <input type="text" name="_gotcha" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-5000px" />
  <input type="hidden" name="_subject" value="New Astro Jr Contact Us message">
  <button class="extra-btn contact-submit" id="astroContactSubmit" type="submit">Send message ✨</button>
  <p class="contact-note" id="astroContactStatus" role="status" aria-live="polite">Your message will be sent securely through our contact form.</p>
 </form><aside class="contact-aside"><div class="contact-orbit" aria-hidden="true">🪐</div><h3>Mission Control is listening</h3><p>We welcome questions, ideas, and friendly feedback from our young explorers.</p><a href="mailto:astronautjr.space@gmail.com">astronautjr.space@gmail.com</a></aside></div>`;
 const form=$x('#astroContactForm');
 const accountEmail=window.AstroAuth&&AstroAuth.currentEmail?AstroAuth.currentEmail():"";
 const emailField=$x('#astroContactEmail');if(emailField)emailField.value=accountEmail;
 if(form&&!form.dataset.bound){form.dataset.bound='1';form.addEventListener('submit',async e=>{
  e.preventDefault();
  const status=$x('#astroContactStatus'),button=$x('#astroContactSubmit');
  if(!form.reportValidity())return;
  const originalText=button.textContent;
  button.disabled=true;button.textContent='Sending…';status.textContent='Sending your message…';status.style.color='';
  try{
   const response=await fetch(form.action,{method:'POST',body:new FormData(form),headers:{'Accept':'application/json'}});
   if(response.ok){status.textContent='✓ Message sent successfully! Thank you for contacting Astro Jr.';status.style.color='#38c98a';form.reset();if(emailField)emailField.value=accountEmail;}
   else{
    let data={};try{data=await response.json()}catch(_error){}
    const detail=data.errors?.map(error=>error.message).filter(Boolean).join(' ');
    throw new Error(detail||'The message could not be sent. Please try again.');
   }
  }catch(error){status.textContent='✕ '+(error.message||'Something went wrong. Please check your connection and try again.');status.style.color='#ff7777';}
  finally{button.disabled=false;button.textContent=originalText;}
 });}
}
function renderAbout(){
 const el=$x('#extra-about');if(!el||el.dataset.rendered)return;
 el.dataset.rendered='1';
 el.innerHTML=`<div class="extra-hero"><div>🌟 OUR STORY</div><h2>About Us</h2><p>Meet the young team behind Astro Jr.</p></div>
 <div class="extra-card about-card"><div class="about-orbit">🚀</div><h3>Our mission is to make space easier to explore</h3>
 <p>We are a team of four members: Omar Hassan, Ziad Walid, Philopater Hanna, and Samer Samir. We are 16 years old, students in the first year of secondary school at STEM Minya. We created this project to help children understand space.</p>
 <p>Through missions, videos, quizzes, and hands-on simulations, we hope to make learning about the universe exciting, friendly, and accessible to every young explorer.</p>
 <div class="about-team"><span>👨‍🚀 Omar Hassan</span><span>👨‍🚀 Ziad Walid</span><span>👨‍🚀 Philopater Hanna</span><span>👨‍🚀 Samer Samir</span></div></div>`;
}
function install(){
 if(!window.AstroCadet||!window.app){setTimeout(install,60);return}
 addTab('🎬 AstroCinema','cinema');addTab('🧪 Training Lab','lab');addTab('✉️ Contact Us','contact');addTab('ℹ️ About Us','about');
 addView('cinema');addView('lab');addView('contact');addView('about');renderContact();renderAbout();
 initPip();missionOverride();
 const s=state();if(s){s.version=4;s.extraRewards=s.extraRewards||{};save()}
 // Astro can be opened by existing UI; bind capture so this enhanced tutor owns new questions.
 const form=$x('#pipForm');if(form&&!form.dataset.extraCapture){form.dataset.extraCapture='1';form.addEventListener('submit',e=>{e.preventDefault();e.stopImmediatePropagation();const i=$x('#pipInput');const q=i.value.trim();if(q){i.value='';askPip(q)}},true)}
 document.addEventListener('keydown',keyGame);
 // Switching back to any original section hides the added screens.
 const nav=$x('.tabs'); if(nav) nav.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){$$x('.extra-view').forEach(v=>v.classList.remove('active'));$$x('.tabs .tab').forEach(t=>t.classList.toggle('is-active',t===b));}});
}
window.AstroExtra={quizVideo,answerVideo,playCinema,filterCinema,categoryCinema,audienceCinema,daily,discovery,puzzle,askPip,startLander,burn,simulateGravity};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(install,0));else setTimeout(install,0);
})();

;
/* Astronaut Jr — language switcher (Arabic / English).
   English text in the page is the source. Add more lines to DICT to translate more. */
(function () {
  "use strict";
  const EMAIL = "astronautjr.space@gmail.com";
  // English source text mapped to Arabic translations
  const DICT = {
    "Space Academy":["أكاديمية الفضاء","Academia Espacial"],
    "stars":["نجوم","estrellas"],
    "Space Trainee":["متدرب فضاء","Aprendiz espacial"],
    "Missions":["المهام","Misiones"],
    "Planets":["الكواكب","Planetas"],
    "My Cadet":["رائدي","Mi cadete"],
    "Trophies":["الكؤوس","Trofeos"],
    "Settings":["الإعدادات","Ajustes"],
    "Contact us":["تواصل معنا","Contáctanos"],
    "Stars you have earned":["النجوم التي ربحتها","Estrellas que has ganado"],
    "Astro reads aloud":["أسترو يقرأ بصوت عالٍ","Astro lee en voz alta"],
    "Sound effects":["المؤثرات الصوتية","Efectos de sonido"],
    "Planet file":["ملف الكوكب","Ficha del planeta"],
    "Explorer notes":["ملاحظات المستكشف","Notas del explorador"],
    "Previous":["السابق","Anterior"],"Next":["التالي","Siguiente"],
    "Read to me":["اقرأ لي","Léeme"],
    "Cadet registration":["تسجيل الرائد","Registro de cadete"],
    "Welcome to the Academy":["أهلاً بك في الأكاديمية","Bienvenido a la Academia"],
    "Your cadet name":["اسم الرائد الخاص بك","Tu nombre de cadete"],
    "Pick your first suit colour":["اختر لون بدلتك الأولى","Elige el color de tu primer traje"],
    "Everything you earn — stars, missions, outfits — is saved on this device.":["كل ما تربحه — النجوم والمهام والأزياء — يُحفظ على هذا الجهاز.","Todo lo que ganes — estrellas, misiones, trajes — se guarda en este dispositivo."],
    "Start training":["ابدأ التدريب","Empezar entrenamiento"],
    "Cadet console":["لوحة الرائد","Consola del cadete"],
    "Little beeps and rewards":["أصوات صغيرة ومكافآت","Pitidos y recompensas"],
    "Speaks every lesson card and his messages":["يقرأ كل بطاقة درس ورسائله","Lee cada tarjeta de lección y sus mensajes"],
    "Calm mode":["الوضع الهادئ","Modo tranquilo"],
    "Stops floating and zoom animations":["يوقف حركات الطفو والتكبير","Detiene las animaciones de flotar y zoom"],
    "Cadet name":["اسم الرائد","Nombre del cadete"],"Save name":["حفظ الاسم","Guardar nombre"],
    "Signed in as":["مسجّل الدخول باسم","Sesión iniciada como"],"Guest":["ضيف","Invitado"],
    "Sign out":["تسجيل الخروج","Cerrar sesión"],
    "Reset all progress":["إعادة ضبط كل التقدم","Reiniciar todo el progreso"],
    "Astro-buddy · online":["صديق الفضاء · متصل","Compañero espacial · en línea"],
    "Ask Astro anything about space…":["اسأل أسترو أي شيء عن الفضاء…","Pregunta a Astro lo que quieras del espacio…"],
    "What is an orbit?":["ما هو المدار؟","¿Qué es una órbita?"],"Hint":["تلميح","Pista"],
    "Tell me a joke":["احكِ لي نكتة","Cuéntame un chiste"],"What can you do?":["ماذا تستطيع أن تفعل؟","¿Qué puedes hacer?"],
    "Sign in":["تسجيل الدخول","Iniciar sesión"],"Create account":["إنشاء حساب","Crear cuenta"],
    "Welcome back, cadet!":["أهلاً بعودتك أيها الرائد!","¡Bienvenido de nuevo, cadete!"],
    "Sign in to pick up your training where you left off.":["سجّل الدخول لتكمل تدريبك من حيث توقفت.","Inicia sesión para seguir tu entrenamiento donde lo dejaste."],
    "Join the Academy!":["انضم إلى الأكاديمية!","¡Únete a la Academia!"],
    "Create your cadet ID to save your stars, outfits and missions.":["أنشئ هويتك لتحفظ نجومك وأزياءك ومهامك.","Crea tu identificación para guardar tus estrellas, trajes y misiones."],
    "Username or email":["اسم المستخدم أو البريد","Usuario o correo"],
    "Email (optional)":["البريد الإلكتروني (اختياري)","Correo (opcional)"],"Email address (required)":["عنوان البريد الإلكتروني (مطلوب)","Correo electrónico (obligatorio)"],
    "Secret code":["الرمز السري","Código secreto"],"Your secret code":["رمزك السري","Tu código secreto"],
    "Repeat secret code":["أعد الرمز السري","Repite el código secreto"],"Type it once more":["اكتبه مرة أخرى","Escríbelo otra vez"],
    "Keep me signed in on this device":["أبقني مسجّلاً على هذا الجهاز","Mantener sesión en este dispositivo"],
    "or":["أو","o"],"Play as guest":["العب كضيف","Jugar como invitado"],
    "Accounts are saved on this device only, so ask a grown-up to help you remember your secret code.":["الحسابات تُحفظ على هذا الجهاز فقط، فاطلب من شخص بالغ مساعدتك في تذكّر رمزك السري.","Las cuentas se guardan solo en este dispositivo; pide a un adulto que te ayude a recordar tu código secreto."],
    "Training path":["مسار التدريب","Ruta de entrenamiento"],"Mission quiz":["اختبار المهمة","Cuestionario de la misión"],
    "Start the quiz":["ابدأ الاختبار","Empezar el cuestionario"],"Hands-on":["تطبيق عملي","Práctica"],
    "Activity complete":["اكتمل النشاط","Actividad completada"],"Back to path":["العودة للمسار","Volver a la ruta"],
    "Score":["النتيجة","Puntuación"],"Correct":["صحيح","Correcto"],"Planet":["الكوكب","Planeta"],
    "Diameter":["القطر","Diámetro"],"Distance":["المسافة","Distancia"],"Moons":["الأقمار","Lunas"],"Year":["السنة","Año"],
    "Our star":["نجمنا","Nuestra estrella"],"The Sun":["الشمس","El Sol"],
    "Wardrobe":["الخزانة","Armario"],"Cadet wardrobe":["خزانة الرائد","Armario del cadete"],
    "Equipped":["مُرتدى","Equipado"],"Wear it":["ارتدِه","Ponértelo"],"Starter kit":["الطقم الأول","Kit inicial"],
    "Spend stars":["أنفق النجوم","Gastar estrellas"],"Stars now":["النجوم الآن","Estrellas ahora"],
    "Stars to spend":["نجوم للإنفاق","Estrellas para gastar"],"Stars earned all-time":["كل النجوم المربوحة","Estrellas ganadas en total"],
    "Current rank":["الرتبة الحالية","Rango actual"],"Missions done":["المهام المنجزة","Misiones completadas"],
    "Worlds logged":["العوالم المسجّلة","Mundos registrados"],"Mission record":["سجل المهام","Registro de misiones"],
    "Trophy cabinet":["خزانة الكؤوس","Vitrina de trofeos"],"All trophies":["كل الكؤوس","Todos los trofeos"],
    "Explore planets":["استكشف الكواكب","Explorar planetas"],"Planet explorer":["مستكشف الكواكب","Explorador de planetas"],
    "Take the tour":["ابدأ الجولة","Hacer el recorrido"],"Replay":["إعادة","Repetir"],"See trophies":["شاهد الكؤوس","Ver trofeos"],
    "Need a hint?":["تحتاج تلميحاً؟","¿Necesitas una pista?"],"Ask Astro for a tip":["اطلب نصيحة من أسترو","Pide un consejo a Astro"],
    "Back to missions":["العودة إلى المهام","Volver a las misiones"],"Next mission":["المهمة التالية","Siguiente misión"],
    "Open the planet explorer":["افتح مستكشف الكواكب","Abrir el explorador de planetas"],
    "Start with Earth":["ابدأ بالأرض","Empezar por la Tierra"],"Log more planets":["سجّل المزيد من الكواكب","Registrar más planetas"],
    "Read the cards again":["اقرأ البطاقات مرة أخرى","Leer las tarjetas otra vez"],"Back":["رجوع","Atrás"],"Activity":["النشاط","Actividad"],
    "Astro says:":["أسترو يقول:","Astro dice:"],"Astro's note:":["ملاحظة أسترو:","Nota de Astro:"],
    "Mercury":["عطارد","Mercurio"],"Venus":["الزهرة","Venus"],"Earth":["الأرض","Tierra"],"Mars":["المريخ","Marte"],
    "Jupiter":["المشتري","Júpiter"],"Saturn":["زحل","Saturno"],"Uranus":["أورانوس","Urano"],"Neptune":["نبتون","Neptuno"],
    "Early Stargazers":["أوائل مراقبي النجوم","Primeros observadores de estrellas"],
    "Rocket Pioneers":["رواد الصواريخ","Pioneros de los cohetes"],"Spacecraft Pilot":["طيار المركبة الفضائية","Piloto de nave espacial"],
    "Living in Orbit":["العيش في المدار","Vivir en órbita"],"Space Navigation & Orbits":["الملاحة الفضائية والمدارات","Navegación espacial y órbitas"],
    "Mission Control & Teamwork":["مركز التحكم والعمل الجماعي","Control de misión y trabajo en equipo"],
    "The Moon Landing":["الهبوط على القمر","El alunizaje"],"Space Weather & Solar Storms":["طقس الفضاء والعواصف الشمسية","Clima espacial y tormentas solares"],
    "Spacewalks & EVA":["السير في الفضاء","Paseos espaciales"],"Rocket Engineering":["هندسة الصواريخ","Ingeniería de cohetes"],
    "Satellites & GPS":["الأقمار الصناعية وGPS","Satélites y GPS"],"Living in Zero Gravity":["العيش في انعدام الجاذبية","Vivir sin gravedad"],
    "Deep Space & Telescopes":["الفضاء العميق والتلسكوبات","Espacio profundo y telescopios"],
    "Mars Colonization":["استيطان المريخ","Colonización de Marte"],"Becoming an Astronaut":["كيف تصبح رائد فضاء","Cómo ser astronauta"],
    "Questions, ideas or a problem? We would love to hear from you.":["أسئلة أو أفكار أو مشكلة؟ يسعدنا أن نسمع منك.","¿Preguntas, ideas o un problema? Nos encantará saber de ti."],
    "Email":["البريد الإلكتروني","Correo"],"Phone":["الهاتف","Teléfono"],
    "Send a complaint":["إرسال شكوى","Enviar una queja"],"Your name":["اسمك","Tu nombre"],"Your email":["بريدك الإلكتروني","Tu correo"],
    "Describe the problem or complaint":["اشرح المشكلة أو الشكوى","Describe el problema o la queja"],
    "Send complaint":["إرسال الشكوى","Enviar queja"],
    "All rights reserved.":["جميع الحقوق محفوظة.","Todos los derechos reservados."],
    "Training Lab":["مختبر التدريب","Laboratorio de entrenamiento"],
    "Contact Us":["اتصل بنا","Contáctanos"],"About Us":["من نحن","Sobre nosotros"],
    "OUR STORY":["قصتنا","NUESTRA HISTORIA"],"Meet the young team behind Astro Jr.":["تعرّف على الفريق الشاب وراء أسترو جونيور.","Conoce al joven equipo detrás de Astro Jr."],
    "Our mission is to make space easier to explore":["مهمتنا جعل استكشاف الفضاء أسهل","Nuestra misión es hacer que explorar el espacio sea más fácil"],
    "We are a team of four members: Omar Hassan, Ziad Walid, Philopater Hanna, and Samer Samir. We are 16 years old, students in the first year of secondary school at STEM Minya. We created this project to help children understand space.":["نحن فريق مكوّن من أربعة أعضاء: عمر حسن، زياد وليد، فيلوباتير حنا، وسامر سمير. نبلغ 16 عامًا، وندرس في الصف الأول الثانوي بمدرسة STEM المنيا. أنشأنا هذا المشروع لمساعدة الأطفال على فهم الفضاء.","Somos un equipo de cuatro integrantes: Omar Hassan, Ziad Walid, Philopater Hanna y Samer Samir. Tenemos 16 años y estudiamos el primer año de secundaria en STEM Minya. Creamos este proyecto para ayudar a los niños a comprender el espacio."],
    "Through missions, videos, quizzes, and hands-on simulations, we hope to make learning about the universe exciting, friendly, and accessible to every young explorer.":["من خلال المهام ومقاطع الفيديو والاختبارات والمحاكاة العملية، نأمل أن نجعل تعلم الكون ممتعًا وسهلًا ومتاحًا لكل مستكشف صغير.","Con misiones, videos, cuestionarios y simulaciones prácticas, esperamos que aprender sobre el universo sea emocionante, cercano y accesible para cada joven explorador."],
    "INTERACTIVE SIMULATION":["محاكاة تفاعلية","SIMULACIÓN INTERACTIVA"],"Gravity & Orbit Simulator":["محاكي الجاذبية والمدار","Simulador de gravedad y órbita"],
    "Change the planet's gravity and see how strongly it pulls a satellite. Increase gravity to tighten the orbit; decrease it to loosen the pull.":["غيّر جاذبية الكوكب وشاهد مدى قوة جذب القمر الصناعي. زد الجاذبية لتضييق المدار، أو قلّلها لإضعاف قوة الجذب.","Cambia la gravedad del planeta y observa cuánto atrae al satélite. Aumenta la gravedad para estrechar la órbita; redúcela para debilitar la atracción."],
    "Gravity strength:":["قوة الجاذبية:","Fuerza de gravedad:"],
    "At 50%, gravity provides a balanced pull that bends the satellite's path around Earth.":["عند 50٪، توفر الجاذبية قوة متوازنة تجعل مسار القمر الصناعي ينحني حول الأرض.","Al 50 %, la gravedad ejerce una atracción equilibrada que curva la trayectoria del satélite alrededor de la Tierra."],
    "High gravity: the pull is stronger, so the satellite needs more forward speed to stay in a stable orbit.":["جاذبية مرتفعة: قوة الجذب أكبر، لذلك يحتاج القمر الصناعي إلى سرعة أمامية أكبر ليبقى في مدار مستقر.","Gravedad alta: la atracción es mayor, por lo que el satélite necesita más velocidad hacia adelante para mantener una órbita estable."],
    "Low gravity: the pull is weaker, so the satellite follows a wider path and may drift away.":["جاذبية منخفضة: قوة الجذب أضعف، لذلك يتبع القمر الصناعي مسارًا أوسع وقد يبتعد.","Gravedad baja: la atracción es más débil, por lo que el satélite sigue una trayectoria más amplia y puede alejarse."],
    "Balanced gravity: the pull bends the satellite’s forward motion into an orbit around Earth.":["جاذبية متوازنة: تجعل قوة الجذب حركة القمر الصناعي الأمامية تنحني لتكوّن مدارًا حول الأرض.","Gravedad equilibrada: la atracción curva el movimiento hacia adelante del satélite y forma una órbita alrededor de la Tierra."],
    "Name":["الاسم","Nombre"],"Subject / Issue Type":["الموضوع / نوع المشكلة","Asunto / tipo de problema"],
    "Message":["الرسالة","Mensaje"],"Send message ✨":["إرسال الرسالة ✨","Enviar mensaje ✨"],
    "Have a question, idea, or need help with Astro Jr? Send a message to our team.":["هل لديك سؤال أو فكرة أو تحتاج إلى مساعدة في أسترو جونيور؟ أرسل رسالة إلى فريقنا.","¿Tienes una pregunta, idea o necesitas ayuda con Astro Jr? Envía un mensaje a nuestro equipo."],
    "Mission Control is listening":["مركز التحكم يستمع إليك","Control de misión te escucha"],
    "We welcome questions, ideas, and friendly feedback from our young explorers.":["نرحب بأسئلة مستكشفينا الصغار وأفكارهم وآرائهم.","Damos la bienvenida a las preguntas, ideas y comentarios de nuestros jóvenes exploradores."],
    "Email is required to create an account.":["البريد الإلكتروني مطلوب لإنشاء حساب.","El correo electrónico es obligatorio para crear una cuenta."],
    "Earn Stars by getting curious":["اكسب النجوم بالفضول والاستكشاف","Gana estrellas con tu curiosidad"],
    "Daily challenge, science puzzles, and a quick planet discovery. Rewards are saved and each challenge pays only once.":["تحدٍ يومي وألغاز علمية واكتشاف سريع لكوكب. تُحفظ المكافآت ويُمنح كل تحدٍ مرة واحدة فقط.","Desafío diario, acertijos científicos y un rápido descubrimiento planetario. Las recompensas se guardan y cada desafío se paga una sola vez."],
    "Gravity Detective":["محقق الجاذبية","Detective de la gravedad"],"Orbit Builder":["مصمم المدار","Constructor de órbitas"],"Light Lab":["مختبر الضوء","Laboratorio de luz"],
    "Correct, science detective!":["أحسنت يا محقق العلوم!","¡Correcto, detective científico!"],
    "Not quite. Think about the science clue and try again.":["ليس تمامًا. فكّر في الدليل العلمي وحاول مرة أخرى.","No exactamente. Piensa en la pista científica e inténtalo de nuevo."],
    "Your message will be sent securely through our contact form.":["ستُرسل رسالتك بأمان عبر نموذج التواصل.","Tu mensaje se enviará de forma segura a través de nuestro formulario."],
    "Sending your message…":["جارٍ إرسال رسالتك…","Enviando tu mensaje…"],
    "✓ Message sent successfully! Thank you for contacting Astro Jr.":["✓ تم إرسال الرسالة بنجاح! شكرًا لتواصلك مع أسترو جونيور.","✓ ¡Mensaje enviado correctamente! Gracias por contactar con Astro Jr."],
    "Mission Control is listening":["مركز التحكم يستمع إليك","Control de misión te escucha"],
    "Missions": ["المهام",""], "Planets": ["الكواكب",""], "My Cadet": ["رائدي",""],
    "Astro Cinema": ["سينما أسترو",""], "Cinema": ["السينما",""],
    "All": ["الكل",""], "Rockets": ["الصواريخ",""], "Sun & Earth": ["الشمس والأرض",""],
    "Earth science": ["علوم الأرض",""], "Solar system": ["النظام الشمسي",""],
    "Stars & galaxies": ["النجوم والمجرات",""], "Planets beyond": ["كواكب خارج النظام الشمسي",""],
    "Astrophysics": ["الفيزياء الفلكية",""], "Planetary science": ["علوم الكواكب",""],
    "NOW PLAYING": ["يُعرض الآن",""], "Video source:": ["مصدر الفيديو:",""],
    "NASA lesson and transcript": ["درس ناسا والنص المكتوب",""],
    "Your browser does not support HTML5 video.": ["متصفحك لا يدعم تشغيل فيديو HTML5.",""],
    "Choose an age group, watch official NASA Space Place videos right here, and test what you learned. The videos use NASA-hosted MP4 files, so the YouTube Error 153 player issue is avoided.": ["اختر الفئة العمرية، وشاهد فيديوهات ناسا التعليمية هنا، ثم اختبر ما تعلمته. تُشغَّل الفيديوهات من ملفات MP4 المستضافة لدى ناسا لتجنب مشكلة YouTube Error 153.",""],
    "How Do We Launch Things Into Space?": ["كيف نطلق الأشياء إلى الفضاء؟",""],
    "A friendly introduction to rockets, fuel, gravity, and how spacecraft leave Earth.": ["مقدمة مبسطة عن الصواريخ والوقود والجاذبية وكيف تغادر المركبات الفضائية الأرض.",""],
    "What gives a rocket the push it needs to lift off?": ["ما الذي يمنح الصاروخ قوة الدفع اللازمة للإقلاع؟",""],
    "Thrust from its engines": ["قوة الدفع الناتجة عن محركاته",""], "Wings like an airplane": ["أجنحة مثل الطائرة",""], "Light from the Moon": ["ضوء القمر",""],
    "What Is a Solar Eclipse?": ["ما هو كسوف الشمس؟",""], "Discover what happens when the Moon moves between the Sun and Earth.": ["اكتشف ما يحدث عندما يمر القمر بين الشمس والأرض.",""],
    "What moves between the Sun and Earth during a solar eclipse?": ["ما الذي يمر بين الشمس والأرض أثناء كسوف الشمس؟",""], "The Moon": ["القمر",""],
    "How Much Water Is on Earth?": ["ما كمية المياه الموجودة على الأرض؟",""], "Explore oceans, ice, groundwater, and why water makes our planet special.": ["استكشف المحيطات والجليد والمياه الجوفية، وتعرّف لماذا تجعل المياه كوكبنا مميزًا.",""],
    "About how much of Earth’s surface is covered by water?": ["ما النسبة التقريبية من سطح الأرض التي تغطيها المياه؟",""],
    "How Many Moons Does Each Planet Have?": ["كم قمرًا لكل كوكب؟",""], "Take a tour of the moons orbiting planets across our solar system.": ["تعرّف على الأقمار التي تدور حول كواكب نظامنا الشمسي.",""],
    "Which planet has just one natural moon?": ["أي كوكب له قمر طبيعي واحد فقط؟",""],
    "Why Is the Sky Blue?": ["لماذا تبدو السماء زرقاء؟",""], "A colorful explanation of sunlight, the atmosphere, and scattering.": ["شرح مبسط لضوء الشمس والغلاف الجوي وتشتت الضوء.",""],
    "Why does the sky usually look blue?": ["لماذا تبدو السماء زرقاء عادةً؟",""], "Air scatters blue light more": ["يشتت الهواء الضوء الأزرق بدرجة أكبر",""],
    "What Is an Aurora?": ["ما الشفق القطبي؟",""], "Find out how the Sun and Earth’s magnetic field create glowing sky displays.": ["اكتشف كيف تُنتج الشمس والمجال المغناطيسي للأرض أضواء الشفق في السماء.",""],
    "What helps guide charged particles toward the polar regions?": ["ما الذي يساعد في توجيه الجسيمات المشحونة نحو المناطق القطبية؟",""], "Earth’s magnetic field": ["المجال المغناطيسي للأرض",""],
    "What Is a Nebula?": ["ما السديم؟",""], "Meet giant clouds of gas and dust where stars can form.": ["تعرّف على سحب هائلة من الغاز والغبار يمكن أن تتكوّن فيها النجوم.",""], "What is a nebula mainly made of?": ["ممّ يتكوّن السديم بشكل أساسي؟",""], "Gas and dust": ["الغاز والغبار",""],
    "Where Does the Solar System End?": ["أين ينتهي النظام الشمسي؟",""], "Travel far beyond the planets and learn about the distant Oort Cloud.": ["انطلق إلى ما وراء الكواكب وتعرّف على سحابة أورت البعيدة.",""], "What icy objects may come from the Oort Cloud?": ["ما الأجسام الجليدية التي قد تأتي من سحابة أورت؟",""], "Some comets": ["بعض المذنبات",""],
    "Searching for Other Planets Like Ours": ["البحث عن كواكب أخرى تشبه كوكبنا",""], "Learn how scientists look for planets orbiting stars beyond our Sun.": ["تعرّف على كيفية بحث العلماء عن كواكب تدور حول نجوم غير الشمس.",""], "What is an exoplanet?": ["ما الكوكب الخارجي؟",""], "A planet orbiting another star": ["كوكب يدور حول نجم آخر",""],
    "Where Does the Sun’s Energy Come From?": ["من أين تأتي طاقة الشمس؟",""], "A deeper look at the Sun’s core and the nuclear fusion that powers it.": ["نظرة أعمق إلى لب الشمس والاندماج النووي الذي يمدها بالطاقة.",""], "Which process releases energy in the Sun’s core?": ["أي عملية تطلق الطاقة في لب الشمس؟",""], "Nuclear fusion": ["الاندماج النووي",""],
    "What Is a Black Hole?": ["ما الثقب الأسود؟",""], "Explore extreme gravity, the event horizon, and what makes black holes unusual.": ["استكشف الجاذبية الشديدة وأفق الحدث وما يجعل الثقوب السوداء مميزة.",""], "What is the event horizon?": ["ما أفق الحدث؟",""], "The boundary beyond which light cannot escape": ["الحد الذي لا يستطيع الضوء الإفلات بعد تجاوزه",""],
    "How Did the Solar System Form?": ["كيف تكوّن النظام الشمسي؟",""], "Follow the science of a collapsing cloud of gas and dust becoming the Sun and planets.": ["تعرّف على كيفية انهيار سحابة من الغاز والغبار وتحوّلها إلى الشمس والكواكب.",""], "About how long ago did our solar system begin forming?": ["منذ كم سنة تقريبًا بدأ تكوّن نظامنا الشمسي؟",""], "4.6 billion years ago": ["منذ 4.6 مليار سنة",""],
    "Nebulae and Star Formation": ["السدم وتكوّن النجوم",""], "Go deeper into how gravity gathers interstellar gas and dust to begin forming stars.": ["تعمّق في فهم كيفية تجميع الجاذبية للغاز والغبار بين النجوم لبدء تكوّن النجوم.",""], "What can gravity do inside a nebula?": ["ماذا يمكن أن تفعل الجاذبية داخل السديم؟",""], "Pull gas and dust into denser clumps": ["تجمع الغاز والغبار في كتل أكثر كثافة",""],
    "How Scientists Search for Exoplanets": ["كيف يبحث العلماء عن الكواكب الخارجية؟",""], "Learn about the transit method and how tiny changes in starlight reveal distant worlds.": ["تعرّف على طريقة العبور وكيف تكشف التغيرات الصغيرة في ضوء النجوم عن عوالم بعيدة.",""], "What can happen to a star’s brightness when a planet transits in front of it?": ["ماذا يحدث لسطوع النجم عندما يمر كوكب أمامه؟",""], "It dims slightly": ["يخفت قليلًا",""],
    "Correct!": ["إجابة صحيحة!",""], "Incorrect!": ["إجابة خاطئة!",""], "Try again": ["حاول مرة أخرى",""], "Correct! You earned 5 Stars.": ["إجابة صحيحة! لقد ربحت 5 نجوم.",""],
    "Correct! You earned 5 Stars.": ["إجابة صحيحة! لقد ربحت 5 نجوم.",""], "Good try! Hint: it is a gas giant with bright rings. Try again!": ["محاولة جيدة! تلميح: إنه عملاق غازي له حلقات لامعة. حاول مرة أخرى!",""],
    "Daily challenge already claimed. Come back tomorrow!": ["لقد أكملت تحدي اليوم بالفعل. عُد غدًا!",""], "You discovered every planet in this bonus log!": ["لقد اكتشفت جميع الكواكب في سجل المكافآت هذا!",""], "Your first badge is waiting!": ["شارتك الأولى في انتظارك!",""],
    "Gravity Detective": ["محقق الجاذبية",""], "Orbit Builder": ["مصمم المدارات",""], "Light Lab": ["مختبر الضوء",""], "Achievements": ["الإنجازات",""], "Keep exploring to build your explorer streak.": ["واصل الاستكشاف لبناء سلسلة إنجازاتك.",""],
    "INTERACTIVE SIMULATION": ["محاكاة تفاعلية",""], "Gravity & Orbit Simulator": ["محاكي الجاذبية والمدار",""], "Change the planet's gravity and see how strongly it pulls a satellite. Increase gravity to tighten the orbit; decrease it to loosen the pull.": ["غيّر جاذبية الكوكب ولاحظ قوة جذب القمر الصناعي. زد الجاذبية لتضييق المدار، وقلّلها لتوسيع المدار.",""], "Gravity strength:": ["قوة الجاذبية:",""],
    "High gravity: the pull is stronger, so the satellite needs more forward speed to stay in a stable orbit.": ["جاذبية مرتفعة: قوة الجذب أكبر، لذلك يحتاج القمر الصناعي إلى سرعة أمامية أكبر ليبقى في مدار مستقر.",""], "Low gravity: the pull is weaker, so the satellite follows a wider path and may drift away.": ["جاذبية منخفضة: قوة الجذب أضعف، لذلك يتبع القمر الصناعي مسارًا أوسع وقد يبتعد.",""], "Balanced gravity: the pull bends the satellite’s forward motion into an orbit around Earth.": ["جاذبية متوازنة: تجعل قوة الجذب حركة القمر الصناعي تنحني لتكوّن مدارًا حول الأرض.",""],
    "Hello, cadet! 🚀 I’m Astro, your curious space buddy. Ask me about science, space, school topics, or everyday questions. What shall we explore?": ["مرحبًا أيها المستكشف! 🚀 أنا أسترو، صديقك الفضولي في الفضاء. اسألني عن العلوم أو الفضاء أو موضوعات الدراسة أو أي سؤال يومي. ماذا نكتشف اليوم؟",""],
    "I’m Astro, the friendly guide aboard Astro Jr! I can explain ideas, share space facts, help you think through a question, and give you a mini-quiz.": ["أنا أسترو، مرشدك الودود في أسترو جونيور! أستطيع شرح الأفكار ومشاركة معلومات عن الفضاء ومساعدتك في التفكير والإجابة عن اختبار قصير.",""],
    "Gravity is the attraction between objects that have mass. It keeps planets moving around the Sun and keeps us on the ground. The Moon’s surface gravity is about one-sixth of Earth’s.": ["الجاذبية هي قوة التجاذب بين الأجسام التي لها كتلة. إنها تُبقي الكواكب في مداراتها حول الشمس وتُبقينا على سطح الأرض. جاذبية سطح القمر تساوي نحو سدس جاذبية الأرض.",""],
    "An orbit is the curved path one object follows around another. A satellite keeps moving forward while gravity continually bends its path, so it keeps falling around Earth instead of straight down.": ["المدار هو المسار المنحني الذي يسلكه جسم حول جسم آخر. يستمر القمر الصناعي في الحركة إلى الأمام بينما تغيّر الجاذبية اتجاه مساره باستمرار، فيظل يدور حول الأرض بدلًا من السقوط مباشرةً.",""],
    "A black hole is a region of space where gravity is so strong that, past its event horizon, even light cannot escape. Scientists study black holes by observing their effects on nearby matter and light.": ["الثقب الأسود منطقة في الفضاء تكون جاذبيتها شديدة جدًا، بحيث لا يستطيع الضوء الإفلات بعد تجاوز أفق الحدث. يدرس العلماء الثقوب السوداء من خلال ملاحظة تأثيرها في المادة والضوء المحيطين بها.",""],
    "The Sun is a star at the center of our Solar System. It releases energy through nuclear fusion in its core, giving Earth much of the light and warmth needed for life.": ["الشمس نجم يقع في مركز نظامنا الشمسي. تطلق الطاقة من خلال الاندماج النووي في لبها، وتمنح الأرض قدرًا كبيرًا من الضوء والدفء اللازمين للحياة.",""],
    "Mars is a rocky planet often called the Red Planet because iron-rich minerals in its dust have rusted. It has giant volcanoes, polar ice, and evidence that liquid water once flowed on its surface.": ["المريخ كوكب صخري يُسمى غالبًا الكوكب الأحمر بسبب تأكسد المعادن الغنية بالحديد في غباره. ويضم براكين ضخمة وجليدًا قطبيًا وأدلة على جريان المياه السائلة على سطحه قديمًا.",""],
    "The Moon is Earth’s natural satellite. Its phases happen because, as it orbits Earth, we see different portions of its half-lit side. The Moon does not make its own light; it reflects sunlight.": ["القمر هو التابع الطبيعي للأرض. تحدث أطواره لأننا نرى أجزاء مختلفة من نصفه المضاء أثناء دورانه حول الأرض. لا يصدر القمر ضوءًا من نفسه، بل يعكس ضوء الشمس.",""],
    "Our Solar System has eight planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune. They all orbit the Sun. Pluto is classified as a dwarf planet.": ["يتكوّن نظامنا الشمسي من ثمانية كواكب: عطارد والزهرة والأرض والمريخ والمشتري وزحل وأورانوس ونبتون. تدور جميعها حول الشمس، ويُصنّف بلوتو كوكبًا قزمًا.",""],
    "A rocket pushes hot exhaust backward. The exhaust pushes the rocket forward in the opposite direction. That is why rockets can work in space without needing air to push against.": ["يدفع الصاروخ الغازات الساخنة إلى الخلف، فتدفع هذه الغازات الصاروخ إلى الأمام في الاتجاه المعاكس. لذلك تستطيع الصواريخ العمل في الفضاء دون الحاجة إلى هواء تدفع نفسها ضده.",""],
    "A star is a huge, glowing ball of hot gas (plasma) that produces energy in its core. Our Sun is the closest star to Earth. Other stars look tiny because they are extremely far away.": ["النجم كرة هائلة متوهجة من الغاز الساخن (البلازما) تنتج الطاقة في لبها. شمسنا أقرب النجوم إلى الأرض، وتبدو النجوم الأخرى صغيرة لأنها بعيدة جدًا.",""],
    "A galaxy is a huge collection of stars, gas, dust, and dark matter held together by gravity. Our Solar System is inside the Milky Way galaxy.": ["المجرة تجمع هائل من النجوم والغاز والغبار والمادة المظلمة تربط بينها الجاذبية. يقع نظامنا الشمسي داخل مجرة درب التبانة.",""],
    "Astro is listening!": ["أسترو يستمع إليك!",""], "Mini-quiz time, cadet! 🌟 Which planet is famous for its beautiful rings? A) Mars  B) Saturn  C) Mercury. Type A, B, or C and I’ll check your answer.": ["حان وقت الاختبار القصير! 🌟 أي كوكب يشتهر بحلقاته الجميلة؟ أ) المريخ  ب) زحل  ج) عطارد. اكتب أ أو ب أو ج وسأتحقق من إجابتك.",""],
    "You’re welcome, cadet! Keep asking questions — curiosity is your superpower. ✨": ["على الرحب والسعة! واصل طرح الأسئلة، فالفضول هو قوتك الخارقة. ✨",""], "Absolutely! Tell me the topic and I’ll break it into small, clear steps, give you an example, and check your understanding.": ["بالتأكيد! أخبرني بالموضوع وسأقسمه إلى خطوات صغيرة وواضحة، وأقدم مثالًا، ثم أتحقق من فهمك.",""],
    "That’s a thoughtful question, cadet! I don’t have a live AI brain connected in this browser-only version, so I may not know the exact answer yet. I can still help you explore it: try adding a little context or splitting it into smaller questions. For open-ended answers on any topic, connect a secure AI service through your own server using ASTROCADET_AI_ENDPOINT — never put a private API key in this file.": ["هذا سؤال رائع! لا يتصل هذا الإصدار الذي يعمل داخل المتصفح وحده بخدمة ذكاء اصطناعي مباشرة، لذلك قد لا أعرف الإجابة الدقيقة دائمًا. يمكنني مساعدتك في الاستكشاف؛ أضف بعض التفاصيل أو قسّم السؤال إلى أسئلة أصغر. للحصول على إجابات مفتوحة في أي موضوع، اربط خدمة ذكاء اصطناعي آمنة عبر خادمك باستخدام ASTROCADET_AI_ENDPOINT، ولا تضع مفتاح API سريًا داخل هذا الملف.",""],
    "I’m listening, cadet! 🚀 I can chat about space and science, help explain a school topic, or make a mini-quiz. For a question outside my built-in guide, Astro needs a secure AI service connected through a backend.": ["أنا أستمع إليك! 🚀 يمكنني التحدث عن الفضاء والعلوم وشرح موضوع دراسي أو إعداد اختبار قصير. للإجابة عن سؤال خارج المعلومات المدمجة، يحتاج أسترو إلى ربط خدمة ذكاء اصطناعي آمنة من خلال خادم خلفي.",""]
  };
  DICT["This opens your email app with a ready message to "+EMAIL+"."]=["سيفتح هذا تطبيق البريد برسالة جاهزة إلى "+EMAIL+".","Esto abre tu app de correo con un mensaje listo para "+EMAIL+"."];

  const IDX = { en:-1, ar:0 };
  const SKIP = { SCRIPT:1, STYLE:1, CANVAS:1, NOSCRIPT:1 };
  const ATTRS = ["placeholder","title","aria-label"];
  let lang = "en", busy = false, queued = false;
  try { const v = localStorage.getItem("aj-lang"); if (IDX[v] !== undefined) lang = v; else if (v === "es") lang = "en"; } catch (e) {}

  function pick(s) {                       // translate a string, or return it unchanged
    const e = DICT[s]; return e && e[IDX[lang]] ? e[IDX[lang]] : null;
  }
  function translate(src) {
    if (lang === "en") return src;
    const t = src.trim(); if (!t) return src;
    const lead = src.match(/^\s*/)[0], tail = src.match(/\s*$/)[0];
    const cached = translatedCache.get(t);
    if (cached) return lead + cached + tail;
    let r = pick(t);
    if (!r) {                              // ignore leading/trailing emoji, arrows and symbols
      const m = t.match(/^([^A-Za-z]*)([A-Za-z].*?)([^A-Za-z0-9.?!…'’):]*)$/);
      if (m) { const c = pick(m[2]); if (c) r = m[1] + c + m[3]; }
    }
    return r ? lead + r + tail : src;
  }
  function doText(n) {
    const known = n.__out !== undefined && n.data === n.__out;
    const src = known ? n.__src : n.data;
    const out = translate(src);
    n.__src = src; n.__out = out;
    if (n.data !== out) n.data = out;
  }
  function doAttrs(el) {
    el.__a = el.__a || {};
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const cur = el.getAttribute(a), rec = el.__a[a];
      const src = rec && rec.out === cur ? rec.src : cur;
      let out = lang === "en" ? src : (pick(src.trim()) || src);
      el.__a[a] = { src, out };
      if (cur !== out) el.setAttribute(a, out);
    }
  }
  function walk(root) {
    if (root.nodeType === 3) { if (!SKIP[root.parentNode && root.parentNode.nodeName]) doText(root); return; }
    if (root.nodeType !== 1 || SKIP[root.nodeName]) return;
    doAttrs(root);
    for (let c = root.firstChild; c; c = c.nextSibling) walk(c);
  }
  // Translate every remaining visible English text/label, including content
  // created later by missions, quizzes, activities, and Pip. The built-in
  // dictionary is used first; this online fallback covers the long lesson text.
  const translatedCache = new Map();
  try { Object.entries(JSON.parse(localStorage.getItem("aj-ar-cache") || "{}")).forEach(([k,v]) => translatedCache.set(k,v)); } catch (_) {}
  let fallbackQueue = new Set(), fallbackBusy = false;
  const hasEnglish = s => /[A-Za-z]{2}/.test(s) && !/^https?:\/\//i.test(s);
  function queueFallback(root) {
    if (lang !== "ar" || !root) return;
    const addText = n => {
      if (!n || !n.isConnected || !n.parentNode || SKIP[n.parentNode.nodeName]) return;
      if (n.parentElement && /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|CODE|PRE)$/i.test(n.parentElement.tagName)) return;
      const src = n.__src !== undefined ? n.__src : n.data;
      if (!src || !hasEnglish(src.trim()) || pick(src.trim()) || translatedCache.has(src.trim())) return;
      fallbackQueue.add({ node:n, src, kind:"text" });
    };
    const addAttr = el => {
      if (!el || !el.isConnected) return;
      for (const a of ATTRS) {
        if (!el.hasAttribute(a)) continue;
        const rec = el.__a && el.__a[a];
        const src = rec ? rec.src : el.getAttribute(a);
        if (src && hasEnglish(src.trim()) && !pick(src.trim()) && !translatedCache.has(src.trim())) fallbackQueue.add({ node:el, src, kind:a });
      }
    };
    if (root.nodeType === 3) addText(root);
    else if (root.nodeType === 1) {
      addAttr(root);
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n; while ((n = walker.nextNode())) addText(n);
      root.querySelectorAll && root.querySelectorAll("*").forEach(addAttr);
    }
    pumpFallback();
  }
  async function pumpFallback() {
    if (fallbackBusy || lang !== "ar") return;
    fallbackBusy = true;
    try {
      while (fallbackQueue.size && lang === "ar") {
        const batch = [...fallbackQueue].slice(0, 5);
        batch.forEach(x => fallbackQueue.delete(x));
        await Promise.all(batch.map(async x => {
          const key = x.src.trim();
          try {
            let out = translatedCache.get(key);
            if (!out) {
              const url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=" + encodeURIComponent(key);
              const res = await fetch(url);
              if (!res.ok) throw new Error("translation unavailable");
              const data = await res.json();
              out = Array.isArray(data[0]) ? data[0].map(part => part[0] || "").join("") : "";
              if (!out) return;
              translatedCache.set(key, out);
              try { localStorage.setItem("aj-ar-cache", JSON.stringify(Object.fromEntries(translatedCache))); } catch (_) {}
            }
            if (lang !== "ar" || !x.node.isConnected) return;
            if (x.kind === "text") {
              const current = x.node.__src !== undefined ? x.node.__src : x.node.data;
              if (current === x.src) { x.node.__src = x.src; x.node.__out = out; x.node.data = x.src.replace(/^\s*/, "") === key ? x.src.replace(key, out) : out; }
            } else {
              const rec = x.node.__a && x.node.__a[x.kind];
              if (rec && rec.src === x.src) { rec.out = out; x.node.setAttribute(x.kind, out); }
            }
          } catch (_) { /* Keep original text if the device is offline. */ }
        }));
      }
    } finally { fallbackBusy = false; }
  }
  function run(roots) {
    busy = true;
    try { roots.forEach(walk); }
    finally { obs.takeRecords(); busy = false; }
    if (lang === "ar") roots.forEach(queueFallback);
  }

  // Translate every visible English string that is not already in DICT.
  // This is a real online translation fallback, not a partial word replacement.
  const cache = new Map();
  try {
    const saved = JSON.parse(localStorage.getItem("aj-ar-cache-v2") || "{}");
    Object.entries(saved).forEach(([k,v]) => { if (typeof v === "string" && v) cache.set(k,v); });
  } catch (_) {}
  let queue = new Map(), pumping = false;
  const isEnglish = s => /[A-Za-z]{2}/.test(s) && !/^https?:\/\//i.test(s);
  const ignored = el => !el || /^(SCRIPT|STYLE|NOSCRIPT|CANVAS|CODE|PRE|TEXTAREA)$/i.test(el.tagName);

  function rememberText(node) {
    if (!node || !node.isConnected || !node.parentElement || ignored(node.parentElement)) return;
    const src = node.__src !== undefined ? node.__src : node.data;
    const key = (src || "").trim();
    if (!key || !isEnglish(key) || pick(key) || cache.has(key)) return;
    queue.set(node, {node, src, key, kind:"text"});
  }
  function rememberAttr(el) {
    if (!el || !el.isConnected || ignored(el)) return;
    for (const attr of ATTRS) {
      if (!el.hasAttribute(attr)) continue;
      const rec = el.__a && el.__a[attr];
      const src = rec ? rec.src : el.getAttribute(attr);
      const key = (src || "").trim();
      if (!key || !isEnglish(key) || pick(key) || cache.has(key)) continue;
      queue.set(el, {node:el, src, key, kind:attr});
    }
  }
  function collect(root) {
    if (!root || lang !== "ar") return;
    if (root.nodeType === 3) rememberText(root);
    else if (root.nodeType === 1 && !ignored(root)) {
      rememberAttr(root);
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) rememberText(node);
      if (root.querySelectorAll) root.querySelectorAll("*").forEach(rememberAttr);
    }
    pump();
  }
  async function translateOnline(text) {
    const q = encodeURIComponent(text);
    const urls = [
      "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=" + q,
      "https://api.mymemory.translated.net/get?q=" + q + "&langpair=en%7Car"
    ];
    for (const url of urls) {
      try {
        const response = await fetch(url, {method:"GET", mode:"cors", cache:"force-cache"});
        if (!response.ok) continue;
        const data = await response.json();
        let result = "";
        if (Array.isArray(data) && Array.isArray(data[0])) result = data[0].map(part => part[0] || "").join("");
        else if (data && data.responseData) result = data.responseData.translatedText || "";
        result = result.replace(/&amp;/g,"&").replace(/&#39;/g,"'").trim();
        if (result && /[\u0600-\u06FF]/.test(result)) return result;
      } catch (_) {}
    }
    return "";
  }
  function applyTranslation(item, result) {
    const {node, src, key, kind} = item;
    if (!result || lang !== "ar" || !node.isConnected) return;
    if (kind === "text") {
      const current = node.__src !== undefined ? node.__src : node.data;
      if (current === src || current === key) {
        const lead = (src.match(/^\s*/) || [""])[0];
        const tail = (src.match(/\s*$/) || [""])[0];
        node.__src = src;
        node.__out = lead + result + tail;
        node.data = node.__out;
      }
    } else {
      node.__a = node.__a || {};
      const rec = node.__a[kind];
      if (!rec || rec.src === src || node.getAttribute(kind) === src) {
        node.__a[kind] = {src, out:result};
        node.setAttribute(kind, result);
      }
    }
  }
  async function pump() {
    if (pumping || lang !== "ar") return;
    pumping = true;
    try {
      while (queue.size && lang === "ar") {
        const batch = [...queue.values()].slice(0, 3);
        batch.forEach(item => queue.delete(item.node));
        await Promise.all(batch.map(async item => {
          let result = cache.get(item.key);
          if (!result) {
            result = await translateOnline(item.key);
            if (result) {
              cache.set(item.key, result);
              try { localStorage.setItem("aj-ar-cache-v2", JSON.stringify(Object.fromEntries(cache))); } catch (_) {}
            }
          }
          applyTranslation(item, result);
        }));
      }
    } finally { pumping = false; }
  }

  const pending = new Set();
  const obs = new MutationObserver(records => {
    if (busy) return;
    records.forEach(record => pending.add(record.target));
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      const roots = [...pending]; pending.clear();
      busy = true;
      try { roots.forEach(root => { if (root.nodeType === 3) doText(root); else if (root.nodeType === 1) walk(root); }); }
      finally { obs.takeRecords(); busy = false; }
      if (lang === "ar") roots.forEach(collect);
    });
  });

  function setLang(l) {
    if (l !== "ar" && l !== "en") l = "en";
    lang = l;
    try { localStorage.setItem("aj-lang", l); } catch (e) {}
    document.documentElement.lang = l;
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
    document.querySelectorAll(".langs button").forEach(b => {
      const on = b.dataset.lang === l;
      b.classList.toggle("on", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    // Restore original English first, then apply known Arabic and translate all remaining text.
    run([document.body]);
    if (l === "ar") collect(document.body);
    if (window.AstroCadet && AstroCadet.Talk) AstroCadet.Talk.voice = AstroCadet.Talk.pickVoice();
  }
  window.AstroLanguage = { get: () => lang, translate, set: setLang };
  document.addEventListener("click", event => {
    const button = event.target.closest && event.target.closest(".langs button[data-lang]");
    if (button) setLang(button.dataset.lang);
  });

  // complaint form -> opens the email app addressed to the complaints inbox
  const form = document.getElementById("complaintForm");
  if (form) form.addEventListener("submit", e => {
    e.preventDefault();
    const n = document.getElementById("cpName").value.trim();
    const f = document.getElementById("cpEmail").value.trim();
    const t = document.getElementById("cpText").value.trim();
    const subj = { en:"Complaint from ", ar:"شكوى من " }[lang] + n;
    location.href = "mailto:" + EMAIL + "?subject=" + encodeURIComponent(subj) +
      "&body=" + encodeURIComponent(t + "\n\n" + n + "\n" + f);
  });

  const y = document.getElementById("copyYear"); if (y) y.textContent = new Date().getFullYear();
  obs.observe(document.body, { childList:true, subtree:true, characterData:true, attributes:true, attributeFilter:ATTRS });
  setLang(lang);
})();
