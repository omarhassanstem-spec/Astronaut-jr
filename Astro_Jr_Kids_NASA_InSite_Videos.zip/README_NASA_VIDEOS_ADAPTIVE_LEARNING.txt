Astro Jr — NASA Planet Cinema + Adaptive Learning
================================================

What changed
------------
1. AstroCinema now has one real NASA-published video for each of the eight planets.
   The videos are embedded in the Astro Jr player using YouTube's privacy-enhanced
   embed domain (youtube-nocookie.com). Selecting a planet does not navigate away
   from Astro Jr. Video delivery still requires the network to permit YouTube embeds.

2. Each planet video has a three-question understanding check. Results set a
   planet-specific learning level:
     - 0–1 correct: Starter Explorer
     - 2 correct: Space Explorer
     - 3 correct: Young Scientist
   The level is saved separately for each planet and used by the Planet Academy
   guide on later visits.

3. Cadet age can be entered during first setup, in Settings, or in AstroCinema.
   Age is only a starting scaffold (4–7, 8–10, 11–13, 14–18). Actual topic level
   is refined by the child's answers, not age alone.

4. Mission lessons also show a learning-coach hint. The starting hint uses age;
   after a mission quiz, the best score for that mission adjusts the hint level:
     - 0–1 correct: step-by-step support
     - 2 correct: connect ideas and explain changes
     - 3 correct: predict, compare evidence, explain causes

5. Age and learning levels are stored in the browser's local save data only.
   They are not added to the Formspree sign-in notification payload.

NASA video sources
------------------
- Mercury — MESSENGER: The Mission to Mercury (NASA Video)
  https://www.youtube.com/watch?v=bAwj8jwUbTo
- Venus — Venus: The Mysterious Planet (NASA Goddard)
  https://science.nasa.gov/resource/venus-the-mysterious-planet/
- Earth — Seeing Earth as Only NASA Can (NASA)
  https://www.youtube.com/watch?v=iTHUUjTA-LI
- Mars — Watch NASA's Perseverance Rover Land (NASA)
  https://science.nasa.gov/resource/watch-nasas-perseverance-rover-land/
- Jupiter — Shallow Lightning on Jupiter (NASA/JPL/Juno)
  https://science.nasa.gov/resource/shallow-lightning-on-jupiter/
- Saturn — NASA at Saturn: Cassini's Grand Finale (NASA JPL)
  https://www.youtube.com/watch?v=xrGAQCq9BMU
- Uranus — Have We Been to Uranus? We Asked a NASA Expert (NASA)
  https://www.youtube.com/watch?v=tzNAWw9EerQ
- Neptune — Voyager's Last Encounter (NASA/JPL archival video)
  https://ntrs.nasa.gov/citations/19940014484

Learning design notes
---------------------
This is a research-informed formative learning scaffold, not a validated
psychometric test, IQ test, diagnosis, or definitive measurement of a child's
ability. Age bands are practical starting points, not fixed developmental rules.
Children vary widely within the same age group and across subject areas.
Use ongoing evidence from mission quizzes and planet-specific checks to tune
explanations. For a fuller classroom-grade assessment, add teacher/parent
observation, verbal explanation, drawings, and repeated checks over time.

Research basis
--------------
- National Academies, Taking Science to School: age-appropriate learning is not
  determined by age alone; prior experience and instruction matter.
  https://www.nationalacademies.org/read/11625/chapter/13
- National Academies, Science and Engineering in Preschool Through Elementary
  Grades: formative assessment should let children show understanding in
  multiple ways and build on their existing ideas.
  https://www.nationalacademies.org/read/26215/chapter/12
- NAEYC: observe, document, and assess each child's development and learning
  using developmentally, culturally, and linguistically responsive methods.
  https://www.naeyc.org/resources/position-statements/dap/assessing-development

Validation
----------
- JavaScript syntax check: passed with Node.js.
- HTML parsing and duplicate-ID check: passed.
- NASA video IDs: eight unique planet-specific embeds configured.
- Browser playback: not fully verified in this environment. Actual playback
  depends on YouTube availability, browser privacy settings, and network policy.


ERROR 153 FIX
==============
AstroCinema YouTube embeds now use:
- A document-level Referrer-Policy of strict-origin-when-cross-origin.
- The same referrerpolicy on each NASA YouTube iframe.
- The standard youtube.com embed endpoint and the hosted page origin parameter.
- A clear local-preview notice if the site is opened with file:// instead of HTTP(S).

IMPORTANT DEPLOYMENT NOTE
-------------------------
YouTube Error 153 occurs when the embed request has no HTTP Referer (or equivalent
client identification). Deploy the site on its real HTTPS domain. Do not test
YouTube embeds by double-clicking index.html or using a preview environment that
strips referrers. The included _headers file is for Netlify/Cloudflare Pages-style
static hosting; vercel.json is for Vercel; .htaccess is for Apache hosting.

If the hosting provider or CDN overrides Referrer-Policy with no-referrer or
same-origin, change that host-level rule to strict-origin-when-cross-origin.
A browser-only code change cannot force a Referer header when the browser,
WebView, or hosting environment suppresses it.


ASTROCINEMA: NATIVE NASA VIDEO UPDATE
====================================
- Replaced all eight planet YouTube iframe embeds with native HTML5 video players.
- Video files are served directly from NASA's Scientific Visualization Studio (SVS).
- Added English caption tracks where NASA provides VTT captions.
- Added an optional browser text-to-speech button for the adaptive explanation.
- Existing non-planet NASA Space Place MP4 lessons continue using the same in-site HTML5 player.
- The planet-video playback path no longer uses YouTube and therefore does not use the YouTube embed flow that produced Error 153.

Note: Videos stream from NASA's own media servers, but remain inside the Astro Jr page.
A live deployment/network test is still required to confirm playback on the production domain.


FINAL PLAYBACK ARCHITECTURE NOTE
================================
Correction to any earlier README text: AstroCinema no longer embeds or depends on
YouTube for the eight planet films. Each planet film uses a direct NASA SVS media
asset in a native HTML5 <video> element. The other NASA Space Place videos also
continue to use native HTML5 video with direct MP4 assets. The word "YouTube" in
one NASA SVS asset filename is only part of NASA's downloadable asset filename;
the asset is fetched directly from svs.gsfc.nasa.gov, not from YouTube.

The native player supports controls, inline playback, poster images, available
NASA English VTT caption tracks, WebM first with MP4 fallback where available,
and a browser read-aloud button for the adaptive planet explanation.
Error 153 is specific to the YouTube embedded-player route and is no longer
part of the AstroCinema planet-video playback path.

Some NASA planet assets are visualizations rather than full narrated lessons.
Astro Jr therefore presents its age/understanding-adaptive explanation alongside
the NASA footage. Captions are provided only for planets for which the selected
NASA SVS asset includes a caption file.
